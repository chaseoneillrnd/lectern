---
id: stack.app
title: Inside the app
type: drilldown
rung: practitioner
pins:
  lectern: 0.2.0
  python: '3.12'
  haystack-ai: 3.4.0
  tilt: 0.37.8
captures:
- inside
objective: 'Follow a question through the app''s code: how it starts and indexes, how it retrieves and prompts, and how it streams the answer back.'
checkpoint_seed: Only the top three passages reach the prompt, so a fact in the fourth cannot reach the answer.
component: app
prerequisites:
- stack.map
---

## where  layout=map  title="Where the app sits"
This lesson opens up the app, the box in the middle of the Map.
It is a Flask server with three routes: the page you ask from, a health check, and an endpoint that streams answers. ^app-routes
[A question comes in from your browser, goes out to both model servers, and the answer streams back]{trace=browser>app>embedder>app>llm>app>browser}. ^app-trip-ask ^app-trip-models ^app-trip-pipeline ^app-ndjson
First, how the app gets ready. Then one question, all the way through its code.

## startup  layout=code  src=stack:app/rag/server.py  show=28-35  lang=python  title="Getting ready"
As soon as the app loads, it starts [this function]{lines=28-29} on a thread of its own. ^app-thread ^app-ready
[It tries to index the docs up to a hundred and twenty times]{lines=30-32}, because the embedder may still be loading its model. ^app-retry
[Once a try succeeds]{lines=32-35}, it records how many chunks it indexed, and stops. ^app-count ^app-count-docs

## retry  layout=code  src=stack:app/rag/server.py  show=36-41  lang=python  title="When a try fails"
[A failed try keeps its innermost error]{lines=37-39}, because that is the one that names the real problem. ^app-root-cause
[Then it waits]{lines=41}: two seconds at first, then one second more each time, up to ten. ^app-backoff ^app-retry

## health  layout=code  src=stack:app/rag/server.py  show=52-65  lang=python  title="The health check"
[Until then, the health check answers five oh three]{lines=54-55}, with the last error it saw. ^app-503 ^app-fail-log
[After, it reports healthy, with the chunk count]{lines=56}. ^app-ok
[A question that comes in too early]{lines=64-65} gets a five oh three as well. ^app-ask-early
Docker Compose and Tilt both wait on this check, so neither calls the app ready before it can answer. ^app-ready ^app-healthcheck
Each failed try logs its error, so if the check stays at five oh three, the app's logs say why. ^app-fail-log ^app-log-level ^app-503

## up  layout=cast  capture=inside  title="Start it by hand"
Now start the stack [with Docker Compose alone]{play=up}, without Tilt. ^app-compose
Compose starts the app's container only after both model servers report healthy. ^app-depends ^app-order
Here, the command returned once all three reported healthy. ^app-compose ^app-order ^app-wait
[Then ask the health check yourself]{play=health}.
It reports healthy, with nine chunks indexed. ^app-health-run

## indexing  layout=code  src=stack:app/rag/pipelines.py  show=66-73  lang=python  title="How the docs are indexed"
Those nine chunks come from the indexing pipeline: five parts in a row. ^app-health-run ^app-index-parts ^app-index-connect
[The converter]{lines=66} reads each Markdown file into a document. ^app-converter ^app-glob
[The cleaner]{lines=67-69} deletes every heading line by default, and keeps the blank lines. ^app-cleaner ^app-headings-default
[The splitter]{lines=70-71} cuts at those blank lines, and by default, each passage becomes one chunk. ^app-splitter ^app-split-default
[The embedder]{lines=72} turns each chunk into a vector, and [the writer]{lines=73} stores it, by default in the app's memory. ^app-embed-write ^app-store
Four lines below these wire the parts in that order. ^app-index-connect
Each of those defaults is a setting in your .env file. ^app-knobs-env

## ask  layout=cast  capture=inside  title="Ask it by hand"
[Now post a question straight to the answer endpoint]{play=ask}, the same call your browser makes when you press Ask. ^app-ask-cmd ^app-trip-ask ^app-ask-tag ^app-ask-button
The answer comes back as a stream of JSON lines. ^app-ndjson ^app-token-run
Each token gets a line of its own, sent the moment the model writes it. ^app-token-run ^app-on-chunk ^app-callback ^app-stream
The last line lists the sources, each with its file, its text, and its score. ^app-sources-run ^app-scores-run ^app-cache-run ^app-sources-event
[The top source]{mark="0.735"} holds the answer: a drop of more than two points in answer faithfulness blocks the deploy. ^app-sources-run
And its score beats [the next one]{mark="0.732"} by only three thousandths. ^app-scores-run
Your browser's page shows each file and its text, but leaves the score out. ^app-page-sources

## events  layout=code  src=stack:app/rag/server.py  show=66-79  lang=python  title="How the answer streams"
Here is how the endpoint builds that stream.
[Each token the model writes]{lines=68-70} goes onto a queue, as an event of its own. ^app-on-chunk ^app-queue
[When the answer is done]{lines=75-76}, the sources follow as one more event. ^app-sources-event
[If anything fails]{lines=78-79}, an error event goes on instead. ^app-error-event
A separate thread does this work, while the response reads the queue, and sends each event as one line of JSON. ^app-worker ^app-stream

## sources  layout=code  src=stack:app/rag/pipelines.py  show=120-132  lang=python  title="Where the sources come from"
[The ask function runs the query pipeline]{lines=120}. ^app-ask-fn
[Your question goes in twice]{lines=121}: to the embedder, to find passages, and to the prompt, to be answered. ^app-twice ^app-query-embedding ^app-prompt-llm
[It also keeps the cutoff's output]{lines=122}: the retriever's top chunks, three by default, minus any that score under a minimum. ^app-keep-cutoff ^app-cutoff ^app-cutoff-rule ^app-topk-default
There is no minimum by default, so all three pass. ^app-cutoff-default ^app-cutoff-rule
[If none is left]{lines=123-126}, it answers that the docs do not say, and the model never runs. ^app-no-context ^app-no-context-text ^app-cutoff-rule
[Each source]{lines=130-131} carries its file name, its text, and the score the retriever gave it. ^app-source-fields
So the sources are what the model was given, not what it used. ^app-source-fields ^app-given
Here, a passage about the cache came back too. ^app-cache-run

## prompt  layout=code  src=stack:app/rag/pipelines.py  show=29-35  lang=python  title="The prompt"
[The system message]{lines=30-32} tells the model to answer only from the context. ^app-system
And when the context does not hold the answer, it is told to say so. ^app-system
[The user message]{lines=33-34} lists each passage it was given, then your question. ^app-user ^app-given
So by default, the model sees the top three passages, and never the whole docs folder of nine. ^app-top3 ^app-topk-default ^app-retriever-topk ^app-given ^app-health-run

## swap  layout=code  src=stack:app/rag/pipelines.py  show=38-44  lang=python  title="Swapping in Titan"
[One setting picks which embedder the app builds]{lines=38-39}. ^app-switch ^app-setting
[Set it to titan, and the app embeds with Amazon Titan, on Bedrock]{lines=40-42}. ^app-titan-embed
[Otherwise, it builds Haystack's OpenAI embedder]{lines=43-44}, pointed at the local server. ^app-local-embed ^app-openai-import ^app-trip-models
The embedder for questions, just below this one, reads the same setting and names the same model. ^app-same
So passages and questions are turned into vectors by the same model. ^app-titan-embed ^app-local-embed ^app-same
A second setting makes the same choice for the generator. ^app-llm-switch
Titan costs money per call, and the demo does not even install it. ^app-titan-cost

## stop  layout=cast  capture=inside  title="Stop it"
When you are done, [run docker compose down]{play=down}: here it stopped and removed all three containers, and then the network. ^app-down-run

## check  layout=checkpoint  card="Only the top three passages reach the prompt."
> ask: A fact sits in the fourth closest passage. Can the answer use it?
> answer: No: by default, only the three closest passages reach the prompt. ^app-top3 ^app-topk-default ^app-retriever-topk ^app-given
> A setting in your .env file raises that number. ^app-topk-env ^app-topk-compose ^app-top3
