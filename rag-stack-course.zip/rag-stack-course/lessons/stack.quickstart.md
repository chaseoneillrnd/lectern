---
id: stack.quickstart
title: Run the stack
type: quickstart
rung: practitioner
pins:
  lectern: 0.2.0
  python: '3.12'
  haystack-ai: 3.4.0
  tilt: 0.37.8
captures:
- quickstart
- tour
- stop
objective: Run the stack on your machine, ask it a question, and prove the whole system works.
needs:
- Docker with Compose v2 or newer, running
- Tilt 0.35 or newer
- Python 3.10 or newer
- About 3 GB of free disk and 4 GB of free memory
- Ports 5000 and 10350 free
- Behind a TLS-inspecting proxy, its CA certificate as a PEM file, one certificate or a whole bundle
checkpoint_seed: Every resource in Tilt is green, so the stack works.
---

## runs  layout=map  title="What you will run"
The stack answers questions about a folder of docs. ^qs-docs
[Your browser]{light=browser} sends each question to [the app]{light=app}. ^qs-ask-api
The app is a Flask server that runs [Haystack]{chip} pipelines. ^qs-flask ^qs-haystack
[The embedder]{light=embedder} turns text into vectors, and [the generator]{light=llm} writes each answer. ^qs-models-roles
Both are open models on your own machine, standing in for [Amazon Titan]{chip}, so the stack costs nothing to run. ^qs-titan ^qs-open
The app [indexes the docs folder]{light=index} once, when it starts. ^qs-index-once
And [Tilt]{chip} starts all of it with [one command]{light=tilt}. ^qs-tilt
You need Docker with Compose, Tilt, Python, and about three gigabytes of free disk. ^qs-needs

## setup  layout=cast  capture=quickstart  title="Set it up"
Start in a fresh clone of the stack at tag v zero point two point zero, and run every command from its folder. ^qs-tag ^qs-clone
[Copy the example settings]{play=env} into a file named .env. ^qs-cp

## settings  layout=code  src=stack:.env.example  show=1-12  lang=dotenv  title="What .env holds"
Nothing in .env is secret, because every model runs locally. ^qs-env
[The first two settings]{lines=4-7} set the app's port and how many chunks the generator gets. ^qs-settings
[Below them come the retrieval knobs]{lines=9-12}, each one commented out, so the defaults hold. ^qs-knobs
Leave them for now.

## network  layout=code  src=stack:.env.example  show=37-45  lang=dotenv  title="Edit .env if your network needs it"
[The last block]{lines=37} is only for networks that need it. ^qs-network-block
Behind a TLS-inspecting proxy, [uncomment PROXY_CA]{lines=40} and set it to the full path of your proxy's CA certificate. ^qs-proxy-ca ^qs-uncomment
The model download and the image build both trust it. ^qs-proxy-ca-models ^qs-proxy-ca-build
If Docker Hub rate-limits you, [uncomment PYTHON_IMAGE]{lines=44} too. ^qs-mirror ^qs-uncomment

## start  layout=cast  capture=quickstart  title="Start it"
[Then fetch the two models]{play=models}. ^qs-models-run
Each one is pinned to a single commit, and checked against its checksum. ^qs-models-pinned ^qs-checksum-small ^qs-checksum-large
If the connection drops, the script picks up where it stopped. ^qs-resume
Here they come to over five hundred megabytes. ^qs-checksum-small ^qs-checksum-large
If you run it again later, it finds them and skips the download. ^qs-found
[Now start everything with tilt up]{play=up}. ^qs-up ^qs-tilt
Tilt runs the two model servers and the app, builds the app's image, and serves a dashboard of its own. ^qs-tilt ^qs-groups ^qs-builds ^qs-building ^qs-up
The first start pulls the model server image and builds the app, so give it a few minutes. ^qs-first
Press space to open the dashboard in your browser, or open the address it prints. ^qs-space ^qs-up

## dashboard  layout=steps  capture=tour  title="Watch it come up"
The dashboard groups the stack's resources into app and models, beside the Tiltfile itself. ^qs-groups
[The counter at the top]{spotlight=summary} counts healthy resources, and here all five are. ^qs-count ^qs-healthy
[Smoke]{arrow=smoke} runs last, because it waits for the app, and the app waits for both models. ^qs-smoke-last ^qs-app-deps
It asks the app a real question, and passes only when the answer cites a source. ^qs-smoke
[Click the app resource to open its logs]{play=logs}.
[Here]{zoom=indexed}, it indexed nine chunks from the docs folder. ^qs-indexed
[Further down]{pan=answered}, it answered the question smoke asked, from three sources. ^qs-answered ^qs-question

## ask  layout=steps  capture=tour  from=logs  title="Ask it a question"
[The link at the top of the app's page]{arrow=links} opens the app itself. ^qs-link
[Open it]{play=app}.
[Type a question]{play=type}, here the same one the smoke check asked, about how long Orbit caches search results. ^qs-question ^qs-typed
[Press Ask]{play=ask}, and the answer streams in as the model writes it. ^qs-stream ^qs-tokens
Behind it, the app embeds your question, finds the closest chunks, and hands them to the generator. ^qs-pipeline
[The answer]{spotlight=answer} says Orbit caches search results for ten minutes. ^qs-answer
[Each source below it]{zoom=sources} names the doc it came from, so you can check the answer yourself. ^qs-sources

## stop  layout=cast  capture=stop  title="Stop it"
When you are done, stop Tilt with control C. ^qs-ctrl-c ^qs-stop-doc
Then, from the stack's folder, [tilt down]{play=down} removes the containers and the network it started. ^qs-down ^qs-down-network ^qs-stop-doc
The images and the models stay on disk, so the next start is fast. ^qs-keep

## check  layout=checkpoint  card="Smoke: one real question, end to end"
> ask: Every resource in Tilt is green. Which one proves the stack actually answers questions?
> answer: Smoke, the resource that runs last. ^qs-smoke-last ^qs-app-deps
> It asks the app a real question, and passes only when the answer cites a source. ^qs-smoke
