---
id: stack.pgvector
title: Switch to pgvector
type: recipe
rung: practitioner
pins:
  lectern: 0.2.0
  python: '3.12'
  haystack-ai: 3.4.0
  pgvector-haystack: 7.0.0
  pgvector: 0.8.7
  tilt: 0.37.8
captures:
- pgvector
- inside        # evidence only: the in-memory scores the pgvector run is compared with
objective: Move the vectors into Postgres with pgvector, read the table it builds, and measure what an HNSW index trades for its speed.
checkpoint_seed: A low ef_search answers faster, but misses true neighbors and can return fewer rows than top k asks for.
prerequisites:
- stack.embedder
---

## stores  layout=code  src=stack:app/rag/stores.py  show=1-7  lang=python  title="Where the vectors can live"
By default, the app keeps its vectors in its own memory, and compares a question with every one of them. ^pg-memory ^pg-store-default
[pgvector keeps them in Postgres instead]{lines=3-4}. ^pg-store-doc
[With exact search, it still compares every vector, so it never misses]{lines=4}. ^pg-exact-doc
[With HNSW search, it walks an approximate index]{lines=5}: fast on a large table, but it can miss a true nearest neighbor. ^pg-hnsw-doc ^pg-graph
[One more setting]{lines=6} decides how many candidates that walk keeps. ^pg-ef-doc

## switches  layout=code  src=stack:app/rag/stores.py  show=23-26  lang=python  title="Three switches"
[When the store setting is pgvector, the app builds this store]{lines=23}. ^pg-store-switch ^pg-ctor
[The search setting picks exact search or HNSW]{lines=24}. ^pg-search-switch
[ef_search goes straight to the store]{lines=26}, beside the index's own build settings. ^pg-ctor
[The table is built for one vector length]{lines=23}, and scored with cosine. ^pg-ctor ^pg-dim-default
The retriever switches with the store, and keeps the same top k. ^pg-retriever

## switch  layout=cast  capture=pgvector  title="Switch it on"
[Add three settings to your .env file]{play=switch}: the profile that starts pgvector, the store, and HNSW search. ^pg-switch-cmd ^pg-env-doc
[Then start the stack]{play=up}. ^pg-up-cmd
The profile adds a fourth service to the three you know, and the app retries its indexing until Postgres answers. ^pg-service ^pg-retry
[The new service reports healthy too]{mark="rag-demo-stack-pgvector-1 Healthy"}: Postgres, with pgvector. ^pg-up-run ^pg-service

## table  layout=cast  capture=pgvector  title="The table it builds"
[Ask Postgres to describe the table the app filled]{play=table}. ^pg-table-cmd ^pg-table-name
That is psql, the Postgres client, running inside the pgvector container. ^pg-table-cmd
[Each vector sits in one column]{mark="vector(384)"}, typed for exactly three hundred and eighty-four numbers. ^pg-vector-col
[The HNSW index]{mark="vector_cosine_ops"} is built for cosine distance, with the settings the store passed. ^pg-index-run ^pg-ctor
An index serves one distance function, so Postgres needs an index for each one you query with. ^pg-index-per-fn

## ask  layout=cast  capture=pgvector  title="Same question, new store"
[Ask the question from Inside the app again]{play=ask}. ^pg-ask-cmd ^pg-memory-cmd
This time, the retriever asks Postgres for the nearest vectors. ^pg-retriever ^pg-retriever-doc ^pg-order-by
The answer streams back token by token, as it did in Inside the app. ^pg-tokens-run ^pg-memory-tokens
[The sources]{mark="0.735"} come back in the same order, with the same scores, as when the vectors lived in memory. ^pg-ask-run ^pg-memory-run ^pg-store-default
The difference shows at scale.

## bench  layout=cast  capture=pgvector  title="A hundred thousand vectors"
[Now benchmark search on a hundred thousand vectors]{play=bench}. ^pg-bench-cmd ^pg-bench-rows
They are generated, three hundred and eighty-four numbers each, and clustered the way real embeddings cluster. ^pg-bench-doc ^pg-bench-rows
[Exact search finds every true neighbor]{mark="recall 1.000"}, in about sixty-six milliseconds a query. ^pg-exact-run ^pg-exact-readme
[Building the index]{mark="76 s"} takes over a minute. ^pg-build-run
[At an ef_search of ten]{mark="0.764"}, a query takes under two milliseconds, but misses about a quarter of the true neighbors. ^pg-ef-run
[At the default of forty]{mark="0.938"}, it finds ninety-four percent, in under four milliseconds. ^pg-ef-run ^pg-ef-default ^pg-ef-config
[At a hundred and sixty]{mark="0.990"}, it finds ninety-nine percent, in about eleven. ^pg-ef-run
So raise ef_search, and search finds more and takes longer. ^pg-ef-trade ^pg-ef-run
Lower it, and search runs faster and misses more. ^pg-ef-trade ^pg-ef-run
[The last column]{mark="rows of 100"} asks for a hundred rows, and gets no more than ef_search. ^pg-ef-run ^pg-rows-doc
So with HNSW, a top k above ef_search quietly gets fewer chunks than it asked for. ^pg-rows-doc ^pg-ef-run

## operator  layout=cast  capture=pgvector  title="Match the operator to the index"
[The last two lines show the plan Postgres picks]{mark="Index Scan using annbench_hnsw"}. ^pg-plan-run
With cosine distance, the function the index was built for, it uses the index. ^pg-plan-run
[With L two distance]{mark="Parallel Seq Scan"}, it skips the index and scans every row, like an exact search. ^pg-plan-run ^pg-exact-readme
So a query uses the index only when it asks for the distance the index was built for. ^pg-index-per-fn ^pg-plan-run
The app's store builds its index for cosine distance, and asks for cosine distance. ^pg-index-run ^pg-order-by ^pg-ctor
[Stop the stack]{play=down}, and pgvector stops with it. ^pg-down-run
To switch back, delete the three lines. ^pg-switch-back

## check  layout=checkpoint  card="A search never returns more rows than ef_search."
> ask: Top k is fifty, search is HNSW, and ef_search is forty. How many chunks can come back?
> answer: At most forty: results are limited by ef_search. ^pg-rows-doc ^pg-ef-run ^pg-ef-config
> Raise ef_search to at least top k, and every slot can fill, at the price of a slower search. ^pg-rows-doc ^pg-ef-trade
