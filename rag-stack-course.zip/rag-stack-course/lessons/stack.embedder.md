---
id: stack.embedder
title: Inside the embedder
type: drilldown
rung: practitioner
pins:
  lectern: 0.2.0
  python: '3.12'
  haystack-ai: 3.4.0
  pgvector-haystack: 7.0.0
  pgvector: 0.8.7
  tilt: 0.37.8
captures:
- vectors
objective: See what the embedder makes of a text, how two vectors are scored, and how the scores decide which chunks reach the prompt.
checkpoint_seed: A score only ranks chunks against one question. It is not a probability, so zero point seven is not seventy percent sure.
component: embedder
prerequisites:
- stack.app
---

## where  layout=map  title="Where the embedder sits"
This lesson opens up the embedder, the model server that turns text into vectors. ^emb-model
[Every chunk of the docs goes through it once, when the app starts]{trace=app>embedder>app}, and comes back as a vector. ^emb-index ^emb-index-once
Every question goes through it too, so the app can compare the question with the chunks. ^emb-question
First, what one text becomes. Then how texts are compared, and what that decides.

## vector  layout=cast  capture=vectors  title="One text, one vector"
[Start the stack]{play=up} with Docker Compose. ^emb-up-run
Here, it gave the terminal back once the app and both model servers had reported healthy. ^emb-up-healthy
[Then ask the probe what the embedder makes of a question]{play=embed}. ^emb-embed-cmd
The probe runs inside the app's container, and calls the same embedder the app calls. ^emb-embed-cmd ^emb-probe
[The question came back as three hundred and eighty-four numbers]{mark="384"}: a vector. ^emb-384-run
That count belongs to the model, so every text it embeds comes back with exactly that many. ^emb-fixed ^emb-dim-default
[The vector's length]{mark="1.000"} comes out at one. ^emb-length-run
Keep that in mind for the scores.

## compare  layout=cast  capture=vectors  title="Three ways to score"
[Now score the same question against three other texts]{play=compare}. ^emb-compare-cmd
The first says the same thing in other words.
The second rearranges the question's own words.
The third is about something else.
Each one gets three scores: cosine similarity, the dot product, and L two distance. ^emb-three
[The same question, in other words]{mark="0.824"}, scores zero point eight two. ^emb-paraphrase-run
[Its own words, rearranged to ask something else]{mark="0.950"}, score higher still. ^emb-words-run
So here, the top score went to a different question built from the same words, not to the one with the same meaning. ^emb-compare-cmd ^emb-words-run ^emb-paraphrase-run
[A question about the cache]{mark="0.691"} still scores almost zero point seven. ^emb-other-run
So here, a score near zero point seven came from a text that does not answer the question at all. ^emb-other-run ^emb-compare-cmd

## scores  layout=code  src=stack:app/rag/probe.py  show=27-40  lang=python  title="Each score in code"
Here are the three scores in code. ^emb-dot ^emb-cosine ^emb-l2
[The dot product]{lines=35-36} multiplies the two vectors number by number, and adds it all up. ^emb-dot
[Cosine similarity]{lines=31-32} divides that by both lengths. ^emb-cosine
For vectors of length one, that changes nothing, so the two scores agree to the last digit. ^emb-cosine ^emb-cos-dot-run
[L two distance]{lines=39-40} measures the straight line between the two vectors instead. ^emb-l2
Here it runs the other way: the most alike text has the smallest distance. ^emb-l2-run ^emb-l2
The app's in-memory store scores with the dot product, and pgvector with cosine similarity. ^emb-store-dot ^emb-memory-default ^emb-memory-ctor ^emb-memory-scores ^emb-pg-cosine ^emb-pg-score
For these vectors, which have length one, the two agree, as the table showed. ^emb-cos-dot-run ^emb-length-run ^emb-cosine

## rank  layout=cast  capture=vectors  title="Every chunk, ranked"
[Now score every chunk of the docs folder against the question]{play=rank}. ^emb-rank-cmd ^emb-rank-all
The probe indexes the folder the way the app does, so these are the scores the app sees. ^emb-rank-doc
[The top chunk]{mark="0.735"} holds the answer. ^emb-top-run ^emb-top-doc
[The third]{mark="0.668"} is about the cache, not deploys, and it still makes the cut. ^emb-third-run
[Only the chunks above this line]{mark="TOP_K is 3" trail=clear} reach the prompt: three, by default. ^emb-cut-run ^emb-topk-default
Raise top k, and the answer is likelier to be among them, but the model has more to read. ^emb-topk-trade
By default, no minimum score applies: the rank alone decides. ^emb-no-min ^emb-cut-run
A minimum score is a setting too. ^emb-min-setting
The recipe on measuring retrieval tests one.
[Stop the stack]{play=down} when you are done. ^emb-down-run

## same  layout=code  src=stack:app/rag/pipelines.py  show=47-52  lang=python  title="One model for both"
[The embedder for questions]{lines=47-48} reads the same setting as the one for chunks, and [names the same model]{lines=51-52}. ^emb-same
They have to: Haystack's own guide says to use the same embedding model for text and documents. ^emb-same-model-doc

## switch  layout=code  src=stack:app/rag/stores.py  show=20-26  lang=python  title="Switching models"
[With pgvector, the table holds vectors of one length]{lines=23}, set by a dimension setting that must match the embedder. ^emb-table-dim ^emb-dim-default
Titan's text embeddings take a dimensions setting of their own, so match the dimension setting to it. ^emb-titan-dims ^emb-table-dim
And every chunk must be embedded again, by the new model. ^emb-same-model-doc ^emb-index-once
[The demo rebuilds its table at every start]{lines=20-22}, so one restart does all of that. ^emb-rebuild ^emb-index-once
A production app must never empty its index on a restart, so there, re-indexing for a new model is a job of its own. ^emb-rebuild

## check  layout=checkpoint  card="A score ranks chunks. It is not a probability."
> ask: The top chunk scores [0.7]{say="zero point seven"}. How sure is the match?
> answer: The score does not say: in this run, a question about the cache, with nothing to say about deploys, scored [0.69]{say="zero point six nine"}. ^emb-other-run ^emb-compare-cmd
> Scores rank the chunks against this one question, and by default, the top three reach the prompt. ^emb-rank-sorted ^emb-cut-run ^emb-topk-default
