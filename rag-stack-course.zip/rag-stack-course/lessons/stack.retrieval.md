---
id: stack.retrieval
title: Measure retrieval
type: recipe
rung: practitioner
pins:
  lectern: 0.2.0
  python: '3.12'
  haystack-ai: 3.4.0
  pgvector-haystack: 7.0.0
  pgvector: 0.8.7
  tilt: 0.37.8
captures:
- measure
objective: Measure how chunking, headings, top k and a minimum score change what retrieval finds, on labelled questions, before you change a setting.
checkpoint_seed: Bigger chunks keep more context together and can win more hits, but they carry more words into the prompt.
prerequisites:
- stack.embedder
---

## golden  layout=code  src=stack:evals/questions.yaml  show=1-12  lang=yaml  title="Questions with known answers"
Before you turn a retrieval knob, measure what it does.
[The stack ships labelled questions about its Orbit docs]{lines=5-12}, for exactly that. ^ret-golden
[Each one names a phrase that the right chunk holds]{lines=1-2}, so the key still works after any re-chunking. ^ret-key
A few questions are ones the docs cannot answer, and a few are off the docs' topic altogether. ^ret-kinds

## eval  layout=cast  capture=measure  title="Measure five chunkings"
[Start the stack]{play=up}. ^ret-up-run
The evaluation runs inside the app's container, and calls only the embedder, never the chat model, so a run costs nothing. ^ret-eval-cmd ^ret-free
[Then run it]{play=eval}. ^ret-eval-cmd
For each way of chunking, it indexes all thirty-one docs, and asks all seventy-one questions. ^ret-eval-doc ^ret-counts-run
A hit at three means a chunk holding the answer came back in the top three. ^ret-hit-def
[The default cuts one passage per chunk]{mark="passage:1"}: a hundred and one chunks, fifteen words long on average. ^ret-passage1-run ^ret-default-chunks ^ret-words-mean
It finds the answer in the top three for eighty-three percent of the questions the docs answer. ^ret-passage1-run ^ret-answerable-only
Read along that row to see top k at work: the more chunks come back, the more answers are among them. ^ret-passage1-run ^ret-topk-trade
[Windows of forty words that share ten with their neighbors]{mark="word:40:10"} do best at three: ninety-seven percent. ^ret-overlap-run ^ret-overlap ^ret-chunking-spec
[Three passages per chunk]{mark="passage:3"} wins at one, with chunks more than twice as long. ^ret-passage3-run
Three passages per chunk beat one at every k. ^ret-passage3-run
A bigger chunk keeps related sentences together, and it carries more words into the prompt, so count those words too. ^ret-length-trade

## context  layout=code  src=stack:evals/orbit/orbit-rate-limits.md  lang=markdown  title="Why small chunks miss"
Here is why one passage per chunk misses so often.
[This passage]{lines=7} says the Team plan raises that to three thousand. ^ret-elliptic
On its own, it never says what it raises: [the passage before]{lines=5} does. ^ret-elliptic
That is what a small chunk loses, and what bigger or overlapping chunks keep together. ^ret-length-trade ^ret-overlap

## headings  layout=cast  capture=measure  title="Keep the headings"
[Run it again with the headings kept]{play=headings}. ^ret-headings-cmd
The cleaner runs before the splitter, so it decides what text the splitter sees at all. ^ret-clean-first ^ret-cleaner
By default, it drops every heading line, the ones that start with a hash sign. ^ret-drop-default ^ret-cleaner
Kept, each heading becomes a chunk of its own. ^ret-headings-doc
[That makes thirty-one more chunks]{mark="132"}, and none of them holds an answer. ^ret-headings-run ^ret-headings-doc ^ret-passage1-run
The hit at one drops from seventy-eight to seventy-two percent. ^ret-headings-run ^ret-passage1-run

## cutoff  layout=cast  capture=measure  title="Try a minimum score"
Last, a minimum score. [Try four of them]{play=cutoff}, with the default chunking and the top three. ^ret-cutoff-cmd ^ret-default-chunks ^ret-topk-default
The table counts the questions a cutoff leaves with no context at all. ^ret-cutoff-head
Then the app says the docs do not say: right for a question the docs cannot answer, and wrong for one they can. ^ret-no-context
[At zero point six]{mark="0.60"}, all five off-topic questions get no context, and every answerable one keeps its chunk. ^ret-cut06-run
[At zero point seven]{mark="0.70"}, five answerable questions lose all their context, and still not one question the docs miss is caught. ^ret-cut07-run
[Of the four tried, only zero point eight]{mark="0.80"} catches those six, and by then, thirty-five answerable questions get nothing. ^ret-cut08-run
So in this run, the cutoff caught every off-topic question long before any question the docs miss. ^ret-cut08-run

## apply  layout=cast  capture=measure  title="Turn it on"
[Set the minimum to zero point six for one run]{play=restart}, and the app restarts with it. ^ret-restart-cmd ^ret-restart-run
The cutoff now drops every chunk that scores under zero point six. ^ret-cutoff-rule ^ret-min-env ^ret-restart-cmd
[Then ask it something off topic]{play=offtopic}. ^ret-offtopic-cmd
At that minimum, every off-topic question in the evaluation kept nothing. ^ret-cut06-run
[The app answers that the docs do not say]{mark="The docs do not say."}, with no sources. ^ret-offtopic-run
Nothing cleared the cutoff, so the model never ran. ^ret-skip ^ret-offtopic-run
[Stop the stack]{play=down} when you are done. ^ret-down-run

## knobs  layout=code  src=stack:.env.example  show=13-23  lang=dotenv  title="Keep what you measured"
To keep a setting, put it in your .env file, and restart the app. ^ret-env
[The minimum score]{lines=13-15}, [the chunking]{lines=16-21}, and [the headings]{lines=22-23} are all here, commented out. ^ret-env-knobs
Measure first, change one setting at a time, and measure again.

## check  layout=checkpoint  card="Count the words a chunk carries, not just its hits."
> ask: Three passages per chunk win at [hit@1]{say="hit at one"}. Should you switch to bigger chunks?
> answer: Not on hit rate alone: a bigger chunk keeps related sentences together, so it can win more hits, but it carries more words into the prompt. ^ret-length-trade ^ret-passage3-run
> So count those words too. ^ret-length-trade
