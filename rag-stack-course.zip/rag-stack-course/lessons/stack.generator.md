---
id: stack.generator
title: Inside the generator
type: drilldown
rung: practitioner
pins:
  lectern: 0.2.0
  python: '3.12'
  haystack-ai: 3.4.0
  tilt: 0.37.8
captures:
- generator
objective: See what the generator actually reads, how text becomes tokens, how it picks each next token, and what temperature and seed change.
checkpoint_seed: At temperature zero the generator takes its top-rated token every time, so the same prompt gives the same answer. Above zero it samples, and the seed decides the draw.
component: llm
prerequisites:
- stack.app
---

## where  layout=map  title="Where the generator sits"
This lesson opens up the generator, the local chat model that writes the app's answers. ^gen-model ^gen-llm-local ^gen-prompt-edge
[The app sends it one prompt per question: an instruction, the top chunks, and the question]{trace=gen}. ^gen-prompt ^gen-prompt-edge
It writes each answer one token at a time, and the app streams every token on as it arrives. ^gen-stream ^gen-stream-doc ^gen-on-chunk ^gen-ndjson
First, what the model actually reads. Then how it picks each token.

## serve  layout=code  src=stack:docker-compose.yml  show=25-28  lang=yaml  title="One service, one model"
[The generator is a service of its own]{lines=25-26}, built on the same llama.cpp image as the embedder. ^gen-service ^gen-image ^gen-embedder-anchor
[It loads]{lines=27} Qwen [2.5]{say="two point five"}, a chat model of half a billion parameters. ^gen-model-file ^gen-model
[Its context window holds]{lines=28} [4,096]{say="four thousand and ninety-six"} tokens, shared by the prompt and the answer. ^gen-ctx-flag ^gen-ctx-doc ^gen-truncated-doc
And it runs at temperature zero, with a fixed seed. ^gen-ctx-flag ^gen-temp-flag-doc ^gen-seed-doc

## template  layout=cast  capture=generator  title="What the model reads"
[Start the stack]{play=up}, then ask the generator for the text it would read. ^gen-up-run
Here, it gave the terminal back once the app and both model servers had reported healthy. ^gen-up-healthy
[Send it a system message and a question]{play=template}. ^gen-template-cmd
The request holds two messages: one from the system, and one from the user. ^gen-template-cmd
The endpoint only applies the chat template, so the model does not run. ^gen-template-doc
[Each message becomes a turn between markers]{mark="<|im_start|>user"}. ^gen-template-run ^gen-template-doc
[The text ends by opening the assistant's turn]{mark="<|im_start|>assistant"}, and the model writes its answer from there. ^gen-template-run
[Leave the system message out]{play=default}, and here the template writes one of its own. ^gen-default-cmd ^gen-default-run
This time, only the user's message goes in. ^gen-default-cmd
[It tells the model it is Qwen]{mark="You are Qwen"}, a helpful assistant. ^gen-default-run
Every prompt the app builds opens with its own system message, as the first request did. ^gen-app-system ^gen-app-builder ^gen-template-run

## tokens  layout=cast  capture=generator  title="Text becomes tokens"
[Now ask how it splits a sentence into tokens]{play=tokens}. ^gen-tokens-cmd ^gen-tokenize-doc
Four words come back as ten tokens. ^gen-tokens-run
[Faithfulness splits in two]{mark='{"id":9881,"piece":" faith"},{"id":30414,"piece":"fulness"}'}. ^gen-tokens-run
[Each digit of the number is a token of its own]{mark='{"id":15,"piece":"0"},{"id":13,"piece":"."},{"id":23,"piece":"8"},{"id":20,"piece":"5"}'}. ^gen-tokens-run
[Ask the server for its context size]{play=window}: [4,096]{say="four thousand and ninety-six"} tokens. ^gen-window-cmd ^gen-window-run
So the model reads and writes tokens, and its limits count tokens, not words. ^gen-ctx-doc ^gen-npredict-doc

## next  layout=cast  capture=generator  title="Picking the next token"
[Ask for one token of an answer, with the three it rated highest]{play=next}. ^gen-next-cmd ^gen-probs-doc
The question is Name a fruit, and the answer stops after a single token. ^gen-next-cmd
The model writes every answer this way, one token after another, each picked from scores like these. ^gen-stream-doc ^gen-probs-doc
[It picked One]{mark='"token":"One"'}. ^gen-next-run
[The]{mark='"token":"The"'} [and A came next]{mark='"token":"A"'}. ^gen-next-run
Each score is a log probability: the closer to zero, the likelier. ^gen-logprob-doc ^gen-next-run
At temperature zero, the generator takes the top token every time. ^gen-temp-doc
At higher temperatures it takes more risks, so a less likely token can win. ^gen-temp-doc ^gen-temp-llama-doc

## sample  layout=cast  capture=generator  title="Temperature and seed"
[Ask twice at temperature zero, with two different seeds]{play=greedy}. ^gen-greedy-cmd
The prompt stays the same, and each answer stops at [12]{say="twelve"} tokens. ^gen-greedy-cmd ^gen-npredict-doc
The seed sets where the random draws start. ^gen-seed-doc
Both times, it writes [the same answer]{mark="One of the most popular fruits"}, word for word. ^gen-greedy-run
[Now ask at temperature one]{play=sample}. ^gen-sample-cmd
Same prompt, same seeds, same [12]{say="twelve"}-token cap. ^gen-sample-cmd
Only the temperature changed. ^gen-sample-cmd ^gen-greedy-cmd
A higher temperature gives less likely tokens more of a chance. ^gen-temp-doc ^gen-temp-llama-doc
[One seed wanders off into the model's own name]{mark="As Qwen"}. ^gen-sample-run
[The other names an apple]{mark="One popular"}. ^gen-sample-run

## speed  layout=cast  capture=generator  title="Reading is fast, writing is slow"
[Now ask the app a real question]{play=ask}. ^gen-ask-cmd
It retrieves the top chunks, builds the prompt, and the generator streams its answer back. ^gen-query-wiring ^gen-stream
[Faithfulness]{mark='{"token": " faith"}'} [arrives as two tokens]{mark='{"token": "fulness"}'}, the same two pieces as before. ^gen-ask-run ^gen-tokens-run
[Then read the generator's timings for that question]{play=timings}. ^gen-timings-cmd
The log keeps one line for reading the prompt, and one for writing the answer. ^gen-prompt-run ^gen-eval-run
[Reading the prompt took]{mark="137 tokens"} [137]{say="a hundred and thirty-seven"} tokens, at about [150]{say="a hundred and fifty"} a second. ^gen-prompt-run
[Writing the answer took]{mark="19 tokens"} [19]{say="nineteen"}, at under [20]{say="twenty"} a second. ^gen-eval-run
Per token, writing ran almost eight times slower than reading. ^gen-prompt-run ^gen-eval-run
[Stop the stack]{play=down} when you are done. ^gen-down-run

## settings  layout=code  src=stack:app/rag/pipelines.py  show=55-61  lang=python  title="The app's settings"
[The app sets all of this in one place]{lines=60-61}. ^gen-kwargs
Temperature zero and seed [42]{say="forty-two"}, so its answers repeat. ^gen-kwargs ^gen-temp-doc
And at most [160]{say="one hundred and sixty"} tokens of answer, well inside the window. ^gen-kwargs ^gen-ctx-flag

## check  layout=checkpoint  card="Temperature above zero: it samples, so answers vary."
> ask: A teammate asks the same question twice and gets two different answers. What changed?
> answer: The temperature rose above zero: at zero, the generator takes its top-rated token every time, so the same prompt gives the same answer. ^gen-temp-doc ^gen-greedy-run
> Above zero it samples, and each seed draws differently. ^gen-temp-doc ^gen-sample-run ^gen-seed-doc
