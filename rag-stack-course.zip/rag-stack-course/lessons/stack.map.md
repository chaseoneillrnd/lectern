---
id: stack.map
title: The stack, mapped
type: map
rung: practitioner
pins:
  lectern: 0.2.0
  python: '3.12'
  haystack-ai: 3.4.0
  tilt: 0.37.8
captures:
- quickstart
- tour
objective: Name each part of the stack, what it does, and how a document and a question move through it.
checkpoint_seed: The app indexes the docs once, when it starts, so a changed doc needs an app restart.
prerequisites:
- stack.quickstart
---

## whole  layout=map  title="The whole stack"
Every lesson in this course draws this same map, so you always know where you are.
The stack answers questions about a folder of docs. ^map-docs
[Your browser]{light=browser} sends each question to [the app]{light=app}, in the middle. ^map-ask
The app leans on two model servers, [the embedder]{light=embedder} and [the generator]{light=llm}. ^map-models
[Tilt]{light=tilt} runs all of it on your machine, and [GitLab CI]{light=ci} checks every merge request. ^map-tilt ^map-local ^map-ci

## the-app  layout=map  component=app  title="The app"
The app is a Flask server that runs two [Haystack]{chip} pipelines. ^map-flask ^map-pipelines
One indexes the docs folder, and the other answers questions from it. ^map-pipelines
Indexing runs once, in the background, when the app starts. ^map-index-once
Until it finishes, the app's health check fails, so Tilt only shows the app ready when it can really answer. ^map-healthz

## docs  layout=map  component=docs  title="Indexing the docs"
When the app starts, [it reads every Markdown file in the docs folder]{trace=index}. ^map-glob ^map-index-once
By default, it drops the headings, and splits the rest into passages. ^map-clean ^map-split
[Then the embedder turns each passage into a vector]{trace=app>embedder>app}, and by default, the app keeps them all in its memory. ^map-embed-docs ^map-doc-embedder ^map-models ^map-store
In the Quick start, that came to nine chunks. ^map-indexed
If you change a doc, restart the app in Tilt, so it indexes the folder again. ^map-restart

## ask  layout=map  component=browser  title="Answering a question"
[Your question goes from the browser to the app]{trace=ask}. ^map-ask
[The app has the embedder turn it into a vector too]{trace=app>embedder>app}. ^map-embed-question ^map-text-embedder ^map-query-embedding
The retriever then finds the stored passages closest to it, three by default. ^map-retriever ^map-query-embedding ^map-top-k
[The app hands those passages and your question to the generator]{trace=gen}. ^map-prompt ^map-prompt-template ^map-five-parts
[The answer streams back to your browser]{trace=llm>app>browser} as the model writes it, with its sources below. ^map-stream ^map-ndjson ^map-sources ^map-sources-below

## query  layout=code  src=stack:app/rag/pipelines.py  show=97-109  lang=python  title="The question path in code"
Here is that path in code: one pipeline with five parts. ^map-five-parts
[The embedder]{lines=100} turns the question into a vector, and [the retriever]{lines=101} finds the closest passages. ^map-embed-question ^map-retriever ^map-text-embedder ^map-query-embedding
[A cutoff]{lines=102} can drop passages that score too low, and by default, it drops none. ^map-cutoff ^map-cutoff-default
[The prompt builder]{lines=103} puts the rest in front of the question, and [the generator]{lines=104} answers. ^map-prompt ^map-five-parts ^map-prompt-template
[These four lines]{lines=105-108} wire the parts together, in the order you just watched. ^map-connect

## embedder  layout=map  component=embedder  title="The embedder"
The embedder is a small open model, served on your own machine. ^map-models ^map-local
It speaks the OpenAI API, so the app calls it with Haystack's standard OpenAI components. ^map-openai ^map-openai-import ^map-doc-embedder ^map-text-embedder
It publishes no port, so it stays inside the compose network, where the app reaches it. ^map-no-port

## generator  layout=map  component=llm  title="The generator"
The generator is a small open chat model, also on your machine. ^map-models ^map-local
It answers at temperature zero, with a fixed seed. ^map-temp
Both model servers stand in for Amazon Titan. ^map-local
Two settings swap Titan on Bedrock back in, and that path costs money per call. ^map-titan

## tilt  layout=map  component=tilt  title="Tilt"
[Tilt]{chip} drives the same compose file, so tilt up and docker compose up run the same stack. ^map-tilt
It starts the app only after both model servers report healthy. ^map-deps ^map-healthy
Then its smoke check asks the app one real question, and checks that the answer cites its source. ^map-smoke ^map-smoke-resource

## ci  layout=map  component=ci  title="GitLab CI"
[GitLab CI]{chip} runs the linter and the tests on every merge request, and builds the app's image on the default branch. ^map-ci ^map-ci-rules
The tests stub the model servers, so no stage calls a model, and CI costs nothing beyond runner time. ^map-ci-stub ^map-ci-free

## beyond  layout=map  title="Beyond the demo"
The team's full stack adds [Langfuse]{chip} tracing, which this demo leaves out. ^map-langfuse
And where the team runs it on Windows laptops through [WSL]{chip}, the demo runs on any Linux or Mac machine with Docker. ^map-wsl

## check  layout=checkpoint  card="Restart the app: it indexes once, at start."
> ask: A teammate edits a doc, but the app still gives the old answer. What did they forget?
> answer: To restart the app in Tilt. ^map-restart
> It indexes the docs folder only once, when it starts. ^map-restart ^map-index-once
