# The RAG reference stack: a Lectern course

Video lessons that teach the team's RAG stack, built with Lectern from scripts, claims and captures in this repo. The
stack itself lives in its own repo and stays clean: this course pins it by tag and commit, and never adds a file to it.

Today the course runs against [`rag-demo-stack`](https://github.com/chase-cto/rag-demo-stack), a zero-spend twin of
the reference stack with the same shape: Haystack pipelines behind Flask, run by Tilt on Docker Compose, with two local
llama.cpp models standing in for Amazon Titan. `course.yaml` reads it from a sibling clone, and lesson pages tell
teammates to clone the public repo.

| Lesson | Type | Status |
| --- | --- | --- |
| `stack.quickstart`, Run the stack | Quick start | v0.2.0: both gates approved |
| `stack.map`, The stack, mapped | Map | v0.2.0: both gates approved |
| `stack.app`, Inside the app | Drilldown on `app` | v0.2.0: both gates approved |
| `stack.embedder`, Inside the embedder | Drilldown on `embedder` | v0.2.0: revised, gate one approved, gate two in review |
| `stack.generator`, Inside the generator | Drilldown on `llm` | v0.2.0: new, both gates in review |
| `stack.retrieval`, Measure retrieval | Recipe | v0.2.0: revised, gate one approved, gate two in review |
| `stack.pgvector`, Switch to pgvector | Recipe | v0.2.0: both gates approved |

`map.yaml` holds the course Map: seven components on a 12 by 6 grid and the six edges between them. Every lesson
draws it, and the course page turns it into navigation: a component with a built drilldown opens it, and any other
opens its chapter in the Map lesson. Its positions are frozen: move a component only on purpose, because every lesson
that draws the Map rebuilds.

Three fresh agents, each playing a new teammate with only this lesson, reached a working stack on the first try: one
warm, then two on a cold Docker cache behind a TLS-inspecting proxy that rate-limits Docker Hub.

## Build

```
lectern sources                        # caches the pinned stack and its docs, llama.cpp's included, for offline claim checks
lectern capture quickstart tour stop   # in this order: fresh clone, models, tilt up, then the dashboard and app, then tilt down
lectern capture inside                 # after those three: compose up without Tilt, the health check, one question by curl
lectern capture vectors measure        # the probe's vectors and scores, then the labelled-question evaluation
lectern capture pgvector               # switches .env to pgvector for one run, then puts it back
lectern capture generator              # asks llama.cpp for the template, tokens, next-token scores and samples, then times one question
lectern build stack.quickstart
lectern build stack.map                # plays no captures, and borrows quickstart and tour as evidence the stack ran
lectern build stack.app
lectern build stack.embedder
lectern build stack.generator
lectern build stack.retrieval
lectern build stack.pgvector
lectern map check                      # the Map is pixel-identical in every lesson that draws it
lectern preview                        # the course page with the CourseMap, every lesson, the glossary
```

The captures need Docker with Compose v2 or newer, Tilt, Python 3.10 or newer and about 2 GB of disk, with the
pgvector image. They run in
`.lectern/stacks/rag-demo-stack`, a checkout of the pinned commit that `quickstart` resets like a new clone. They cost
nothing: every model is local. On a network that rate-limits Docker Hub or inspects TLS, export `PYTHON_IMAGE`,
`PGVECTOR_IMAGE` and `PROXY_CA` first, as the stack's `.env.example` explains. The captures pass those names through
and record only the names.

## Moving to the real stack

1. Point `sources.stack.repo` in `course.yaml` at the real repo and `ref` at its release tag, then
   `lectern sources --repin stack`. Lesson pages print `git clone` with that URL. While `repo` is a local path, `clone`
   gives the address teammates clone from and `web` the one claim links open. Without `clone` the page shows a
   placeholder, and the QA report says so.
2. Rewrite the capture specs in `capture/` for the real Quick start: its env file, its credentials step, its Tilt
   resources. Credentials stay in the stack's own config (an AWS profile, its `.env`) and never enter a capture spec.
   A capture that calls Titan on Bedrock costs money on every run, so check before running it.
3. Run the captures, fix the claims they break, rebuild, and take the lesson back through both gates.

## Staleness

`.gitlab-ci.yml` runs `lectern stale --fail` on a pipeline schedule. It flags the lesson when the stack has a newer tag,
when a file the captures depend on changes upstream, when an excerpt disappears at the stack's HEAD, or when Haystack
or Tilt ship a newer release than the pins. Set `LECTERN_IMAGE` to the Lectern container in your registry, and create a
weekly schedule under CI/CD.
