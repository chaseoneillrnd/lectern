// Lectern's VitePress theme: the components that turn generated pages into synced, checkable lessons and a
// navigable course.
// Use it whole (`export { default } from 'lectern/theme'`) or add the components to your own theme with enhanceApp.
import DefaultTheme from 'vitepress/theme'
import type { Theme } from 'vitepress'
import LessonPlayer from './components/LessonPlayer.vue'
import Claim from './components/Claim.vue'
import Checkpoint from './components/Checkpoint.vue'
import Term from './components/Term.vue'
import StaleBanner from './components/StaleBanner.vue'
import CourseMap from './components/CourseMap.vue'
import './styles.css'

export const components = { LessonPlayer, Claim, Checkpoint, Term, StaleBanner, CourseMap }

export function enhanceApp({ app }: { app: any }) {
  for (const [name, component] of Object.entries(components)) app.component(name, component)
}

const theme: Theme = { extends: DefaultTheme, enhanceApp }
export default theme
