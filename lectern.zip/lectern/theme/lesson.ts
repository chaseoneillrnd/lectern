import { computed } from 'vue'
import { useData, withBase } from 'vitepress'

export interface Chapter { id: string; title: string; start: number }
export interface ClaimInfo { kind: 'doc' | 'code' | 'run'; where: string; url?: string | null; excerpt: string }

export function useLesson() {
  const { frontmatter } = useData()
  const lesson = computed(() => (frontmatter.value.lectern || {}) as Record<string, any>)
  const media = (file: string) => withBase((lesson.value.media || './') + file)
  const claimIds = computed(() => Object.keys(lesson.value.claims || {}))
  return { lesson, media, claimIds }
}

export function mmss(seconds: number) {
  const s = Math.max(0, Math.round(seconds))
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`
}

export const store = {
  get(key: string): string | null { try { return localStorage.getItem(key) } catch { return null } },
  set(key: string, value: string) { try { localStorage.setItem(key, value) } catch { /* private window */ } },
}
