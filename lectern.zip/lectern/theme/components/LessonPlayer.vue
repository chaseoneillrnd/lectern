<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import { mmss, store, useLesson } from '../lesson'

const { lesson, media } = useLesson()
const video = ref<HTMLVideoElement | null>(null)
const current = ref(0)
const chapters = computed(() => (lesson.value.chapters || []).filter((c: any) => c.id !== 'title'))
const key = computed(() => `lectern:progress:${lesson.value.lesson}`)

const active = computed(() => {
  let id = ''
  for (const c of chapters.value) if (current.value + 0.05 >= c.start) id = c.id
  return id
})

// The page below the player is the transcript, one section per scene. Mark the section that is playing.
watch(active, (id, prev) => {
  if (typeof document === 'undefined') return
  if (prev) document.getElementById(prev)?.classList.remove('lectern-now')
  if (id && current.value > 0) document.getElementById(id)?.classList.add('lectern-now')
})

function seek(seconds: number, play = true) {
  const v = video.value
  if (!v) return
  v.currentTime = seconds
  current.value = seconds  // mark the chapter now, not at the next timeupdate
  if (play) v.play().catch(() => {})
}

function onTime() {
  if (!video.value) return
  current.value = video.value.currentTime
  store.set(key.value, String(Math.floor(current.value)))
}

function onHash() {
  const id = decodeURIComponent(location.hash.slice(1))
  const c = chapters.value.find((x: any) => x.id === id)
  if (c) seek(c.start, false)
}

onMounted(() => {
  window.addEventListener('hashchange', onHash)
  const saved = Number(store.get(key.value) || 0)
  if (location.hash) onHash()
  else if (saved > 5 && video.value) video.value.currentTime = saved
})
onBeforeUnmount(() => window.removeEventListener('hashchange', onHash))
</script>

<template>
  <figure class="lectern-player">
    <video ref="video" controls preload="metadata" playsinline :src="media('lesson.mp4')" :poster="media('poster.jpg')" @timeupdate="onTime">
      <track kind="captions" srclang="en" label="English" :src="media('lesson.vtt')" />
    </video>
    <figcaption class="lectern-player__bar">
      <span class="lectern-player__meta">
        {{ lesson.duration }} · {{ (lesson.rung || 'practitioner').replace(/^./, (c: string) => c.toUpperCase()) }}
      </span>
      <span class="lectern-player__files">
        <a :href="media('slides.pdf')">Slides</a>
        <a :href="media('transcript.md')">Transcript</a>
        <a :href="media('lesson.mp4')">MP4</a>
      </span>
    </figcaption>
    <ol class="lectern-player__chapters" aria-label="Chapters">
      <li v-for="c in chapters" :key="c.id">
        <button type="button" :class="{ active: c.id === active }" :aria-current="c.id === active ? 'true' : undefined"
                @click="seek(c.start)">
          <span class="time">{{ mmss(c.start) }}</span>
          <span>{{ c.title }}</span>
        </button>
      </li>
    </ol>
  </figure>
</template>
