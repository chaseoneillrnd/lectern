<script setup lang="ts">
// The course Map as navigation. The geometry is the video's own, cropped to what it draws, so the page and every
// lesson show one Map. A component opens its drilldown, or its chapter in the Map lesson when it has no drilldown yet.
import { computed } from 'vue'
import { useData, withBase } from 'vitepress'

interface MapNode { id: string; label: string; x: number; y: number; w: number; h: number; cx: number; cy: number;
  lines: string[]; line_h: number; role?: string | null; link?: string | null; title?: string | null;
  short?: string | null }
interface MapEdge { id: string; d: string; label?: string | null; lx: number; ly: number }
interface CourseMapData { heading?: string | null; viewBox: number[]; font: { node: number; label: number; radius: number };
  nodes: MapNode[]; edges: MapEdge[] }

const { frontmatter } = useData()
const map = computed(() => (frontmatter.value.lectern || {}).map as CourseMapData | undefined)
// The page title usually names the same system, so the Map's own heading only shows when it says something new.
const heading = computed(() => (map.value?.heading && map.value.heading !== frontmatter.value.title ? map.value.heading : ''))
const linked = computed(() => (map.value?.nodes || []).filter((n) => n.link))
const href = (n: MapNode) => (n.link ? withBase(n.link) : undefined)
const lineY = (n: MapNode, i: number) => n.cy + (i - (n.lines.length - 1) / 2) * n.line_h
// Where a component leads, unless the chapter is simply named after it.
const where = (n: MapNode) => {
  const s = n.short || n.title || ''
  return s.toLowerCase() === n.lines[0].toLowerCase() ? '' : s
}
</script>

<template>
  <figure v-if="map" class="lectern-map">
    <p v-if="heading" class="lectern-map__heading">{{ heading }}</p>
    <svg :viewBox="map.viewBox.join(' ')" role="group" :aria-label="map.heading || 'Course map'">
      <defs>
        <marker id="lectern-map-arrow" viewBox="0 0 10 10" refX="8.5" refY="5" markerWidth="5" markerHeight="5"
                orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" class="lectern-map__tip" /></marker>
      </defs>
      <g v-for="e in map.edges" :key="e.id" class="lectern-map__edge">
        <path :d="e.d" marker-end="url(#lectern-map-arrow)" />
        <text v-if="e.label" :x="e.lx" :y="e.ly" :font-size="map.font.label">{{ e.label }}</text>
      </g>
      <template v-for="n in map.nodes" :key="n.id">
        <a v-if="n.link" :href="href(n)" class="lectern-map__node linked" :data-component="n.id"
           :aria-label="`${n.label}: ${n.title}`">
          <title>{{ n.title }}</title>
          <rect :x="n.x" :y="n.y" :width="n.w" :height="n.h" :rx="map.font.radius" />
          <text v-for="(line, i) in n.lines" :key="i" :x="n.cx" :y="lineY(n, i)" :font-size="map.font.node">{{ line }}</text>
        </a>
        <g v-else class="lectern-map__node" :data-component="n.id">
          <rect :x="n.x" :y="n.y" :width="n.w" :height="n.h" :rx="map.font.radius" />
          <text v-for="(line, i) in n.lines" :key="i" :x="n.cx" :y="lineY(n, i)" :font-size="map.font.node">{{ line }}</text>
        </g>
      </template>
    </svg>
    <figcaption v-if="linked.length" class="lectern-map__legend">
      <p>Click a component to open the lesson that covers it.</p>
      <ul>
        <li v-for="n in linked" :key="n.id"><a :href="href(n)"><b>{{ n.label }}</b> <span v-if="where(n)">{{ where(n) }}</span></a></li>
      </ul>
    </figcaption>
  </figure>
</template>
