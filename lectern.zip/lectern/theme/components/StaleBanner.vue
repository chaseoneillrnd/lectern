<script setup lang="ts">
import { useLesson } from '../lesson'
const { lesson } = useLesson()
</script>

<template>
  <div v-if="lesson.stale" class="lectern-stale" role="status">
    <strong>This lesson may be out of date.</strong>
    {{ typeof lesson.stale === 'string' ? lesson.stale : 'A pinned source or capture changed since it was built.' }}
    Built {{ lesson.built }} against {{ Object.entries(lesson.pins || {}).map(([k, v]) => `${k} ${v}`).join(', ') }}.
  </div>
</template>
