<script setup lang="ts">
import { computed, ref } from 'vue'
import { useLesson } from '../lesson'

const props = defineProps<{ id: string }>()
const { lesson, claimIds } = useLesson()
const open = ref(false)
const claim = computed(() => (lesson.value.claims || {})[props.id])
const n = computed(() => claimIds.value.indexOf(props.id) + 1)
const label = computed(() => ({ doc: 'Docs', code: 'Source code', run: 'Captured run' } as any)[claim.value?.kind] || 'Source')
</script>

<template>
  <span class="lectern-claim" :class="{ open }">
    <button type="button" class="lectern-claim__mark" :aria-expanded="open" :aria-controls="`claim-${id}`"
            :title="`Claim ${id}: ${label}`" @click="open = !open">{{ n || '?' }}</button>
    <span v-if="open && claim" :id="`claim-${id}`" class="lectern-claim__card" role="note">
      <span class="lectern-claim__head">{{ label }} · <code>{{ claim.where }}</code></span>
      <span class="lectern-claim__excerpt">{{ claim.excerpt }}</span>
      <a v-if="claim.url" :href="claim.url" target="_blank" rel="noreferrer">Open the source at its pinned version</a>
    </span>
  </span>
</template>
