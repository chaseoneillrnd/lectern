<script setup lang="ts">
import { computed, ref } from 'vue'
import { useLesson } from '../lesson'

const props = defineProps<{ id: string }>()
const { lesson } = useLesson()
const term = computed(() => (lesson.value.terms || {})[props.id])
const open = ref(false)
</script>

<template>
  <span class="lectern-term" @mouseenter="open = true" @mouseleave="open = false">
    <button type="button" class="lectern-term__word" :aria-describedby="`term-${id}`" :aria-expanded="open"
            @click="open = true" @focus="open = true" @blur="open = false" @keydown.esc="open = false"><slot /></button>
    <span v-if="term" v-show="open" :id="`term-${id}`" role="tooltip" class="lectern-term__def">
      <strong>{{ term.term }}</strong> {{ term.define }}
    </span>
  </span>
</template>
