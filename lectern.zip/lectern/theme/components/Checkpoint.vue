<script setup lang="ts">
import { computed, ref } from 'vue'
import { store, useLesson } from '../lesson'
import Claim from './Claim.vue'

const props = defineProps<{ id: string }>()
const { lesson } = useLesson()
const cp = computed(() => (lesson.value.checkpoints || {})[props.id] || {})
const key = computed(() => `lectern:checkpoint:${lesson.value.lesson}:${props.id}`)
const attempt = ref(store.get(key.value) || '')
const shown = ref(false)
function save() { store.set(key.value, attempt.value) }
</script>

<template>
  <section class="lectern-checkpoint" :aria-labelledby="`cp-${id}`">
    <p class="lectern-checkpoint__label" :id="`cp-${id}`">Checkpoint</p>
    <p class="lectern-checkpoint__question">{{ cp.question }}</p>
    <label class="lectern-checkpoint__attempt">
      <span>Your answer first. It stays in this browser.</span>
      <textarea v-model="attempt" rows="3" @input="save" />
    </label>
    <button v-if="!shown" type="button" class="lectern-checkpoint__reveal" @click="shown = true">Reveal the answer</button>
    <div v-else class="lectern-checkpoint__answer">
      {{ cp.answer }} <Claim v-for="c in cp.claims || []" :key="c" :id="c" />
    </div>
  </section>
</template>
