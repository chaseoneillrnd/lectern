"""Unit tests for the deterministic pieces around the render: gates, judge validation, layout, chapters, wizard."""
import json
from pathlib import Path

import pytest
import yaml

from lectern.config import House, load_course
from lectern.gates import approve, calibration_bundle, gate_state, score_calibration, segments, validate_judge
from lectern.package import chapter_list, media_path
from lectern.paths import CoursePaths, LecternError
from lectern.render import diagram_geometry, fit_rows
from lectern.scaffold import new_course, new_lesson, parse_source
from lectern.wizard import Wizard


@pytest.fixture()
def house() -> House:
    return House()


def make_course(tmp_path: Path) -> CoursePaths:
    (tmp_path / "course.yaml").write_text(yaml.safe_dump({"id": "demo", "title": "Demo", "kind": "topic"}))
    paths = CoursePaths(tmp_path)
    paths.lessons.mkdir()
    paths.lesson_script("demo.one").write_text("---\nid: demo.one\ntitle: One\n---\n")
    paths.claims_ledger("demo.one").write_text("{}\n")
    return paths


# ----------------------------------------------------------------------------- gates


def test_gate_one_reopens_when_the_script_changes(tmp_path):
    paths = make_course(tmp_path)
    approve(paths, "demo", "demo.one", "one", by="tester")
    assert gate_state(paths, "demo", "demo.one")["one"]["approved"]
    paths.lesson_script("demo.one").write_text("---\nid: demo.one\ntitle: One, edited\n---\n")
    assert not gate_state(paths, "demo", "demo.one")["one"]["approved"]


def test_gate_two_needs_gate_one_and_an_mp4(tmp_path):
    paths = make_course(tmp_path)
    with pytest.raises(LecternError, match="gate one is open"):
        approve(paths, "demo", "demo.one", "two")
    approve(paths, "demo", "demo.one", "one")
    with pytest.raises(LecternError, match="no packaged MP4"):
        approve(paths, "demo", "demo.one", "two")
    import hashlib

    def sha(p):
        return hashlib.sha256(p.read_bytes()).hexdigest()

    mp4 = paths.dist_dir("demo", "demo.one") / "lesson.mp4"
    mp4.parent.mkdir(parents=True)
    mp4.write_bytes(b"not really a video")
    record = {"script": sha(paths.lesson_script("demo.one")), "claims": sha(paths.claims_ledger("demo.one")),
              "mp4": sha(mp4), "quality": "draft", "fidelity": "full", "checks_ok": True}
    (mp4.parent / "build.json").write_text(json.dumps(record))
    with pytest.raises(LecternError, match="draft"):
        approve(paths, "demo", "demo.one", "two")  # a draft render never reaches gate two
    (mp4.parent / "build.json").write_text(json.dumps({**record, "quality": "standard"}))
    approve(paths, "demo", "demo.one", "two")
    assert gate_state(paths, "demo", "demo.one")["two"]["approved"]
    mp4.write_bytes(b"a different render")
    assert not gate_state(paths, "demo", "demo.one")["two"]["approved"]


def test_gate_two_refuses_a_render_of_an_older_script(tmp_path):
    import hashlib

    paths = make_course(tmp_path)
    mp4 = paths.dist_dir("demo", "demo.one") / "lesson.mp4"
    mp4.parent.mkdir(parents=True)
    mp4.write_bytes(b"render of v1")
    old_script = hashlib.sha256(paths.lesson_script("demo.one").read_bytes()).hexdigest()
    (mp4.parent / "build.json").write_text(json.dumps({
        "script": old_script, "claims": hashlib.sha256(paths.claims_ledger("demo.one").read_bytes()).hexdigest(),
        "mp4": hashlib.sha256(mp4.read_bytes()).hexdigest(), "quality": "standard", "fidelity": "full",
        "checks_ok": True}))
    paths.lesson_script("demo.one").write_text("---\nid: demo.one\ntitle: One, v2\n---\n")
    approve(paths, "demo", "demo.one", "one")
    with pytest.raises(LecternError, match="older script"):
        approve(paths, "demo", "demo.one", "two")


# ----------------------------------------------------------------------------- judge


BUNDLE = {"lesson": "x", "items": [{"item": "a.s1", "sentence": "s", "evidence": []},
                                   {"item": "a.s2", "sentence": "t", "evidence": []}]}


def test_judge_output_must_cover_every_item_once():
    ok = {"scores": [{"item": "a.s1", "score": 3, "reason": "r"}, {"item": "a.s2", "score": 1, "reason": "r"}]}
    assert len(validate_judge(ok, BUNDLE)["scores"]) == 2
    with pytest.raises(LecternError, match="skipped"):
        validate_judge({"scores": ok["scores"][:1]}, BUNDLE)
    with pytest.raises(LecternError, match="unknown item"):
        validate_judge({"scores": ok["scores"] + [{"item": "zz", "score": 1, "reason": "r"}]}, BUNDLE)
    with pytest.raises(LecternError, match="0 to 3"):
        validate_judge({"scores": [{"item": "a.s1", "score": 4, "reason": "r"}, ok["scores"][1]]}, BUNDLE)


def test_calibration_flags_a_judge_that_passes_a_planted_bad_claim(house):
    bundle, expect = calibration_bundle(house)
    assert "bad" in expect.values() and "good" in expect.values()
    assert all("expect" not in item for item in bundle["items"])  # the judge never sees the answers
    lenient = {"scores": [{"item": i["item"], "score": 3, "reason": "fine"} for i in bundle["items"]]}
    misses = score_calibration(validate_judge(lenient, bundle), expect)
    assert len(misses) == sum(1 for v in expect.values() if v == "bad")


# ----------------------------------------------------------------------------- layout and packaging


def test_segments_mark_each_cue_span():
    segs = segments("Is every claim in the answer supported?", [{"span": "answer", "verb": "light", "target": "answer",
                                                                  "word_index": 5}])
    assert [s.get("cue") for s in segs] == [None, "light", None]
    assert "".join(s["text"] for s in segs) == "Is every claim in the answer supported?"


def test_labelled_edges_push_columns_apart_and_stay_centred(house):
    spec = {"nodes": [{"id": "a", "label": "Verdicts\n1 or 0", "at": [7.5, 2]},
                      {"id": "b", "label": "Score\nsupported ÷ all", "at": [8.5, 2]}],
            "edges": [{"id": "e", "from": "a", "to": "b", "label": "divide"}]}
    nodes, edges, boxes = diagram_geometry(spec, house.tokens, 1920, 1080)
    gap = boxes["b"]["x"] - (boxes["a"]["x"] + boxes["a"]["w"])
    assert gap >= 100
    left, right = boxes["a"]["x"], boxes["b"]["x"] + boxes["b"]["w"]
    assert abs((left + right) / 2 - 960) < 1


def test_stacked_boxes_keep_their_column(house):
    spec = {"nodes": [{"id": "top", "label": "Retrieved\ncontext", "at": [7.5, 1]},
                      {"id": "low", "label": "Faithfulness\njudge", "at": [7.5, 4]},
                      {"id": "right", "label": "Answer", "at": [8.0, 4]}],
            "edges": []}
    _, _, boxes = diagram_geometry(spec, house.tokens, 1920, 1080)
    assert boxes["top"]["cx"] == boxes["low"]["cx"]


def test_a_diagram_too_wide_for_the_frame_fails(house):
    spec = {"nodes": [{"id": f"n{i}", "label": "A rather long label", "at": [i, 1]} for i in range(8)], "edges": []}
    with pytest.raises(LecternError, match="wide"):
        diagram_geometry(spec, house.tokens, 1920, 1080)


def test_terminal_fits_the_rows_a_cast_uses():
    assert fit_rows("$ run\nline one\nline two\n$ ", 84, 24) == 5
    assert fit_rows("x" * 200, 84, 24) == 4  # floor of four rows
    assert fit_rows("\n".join(["y"] * 40), 84, 12) == 12  # never more than the recording had


def test_title_card_folds_into_the_first_chapter():
    tl = {"duration_ms": 30000, "scenes": [
        {"id": "title", "layout": "title", "params": {}, "sentences": [], "start_ms": 0, "end_ms": 3000},
        {"id": "concept", "layout": "diagram", "params": {"title": "What it checks"}, "sentences": [1],
         "start_ms": 3000, "end_ms": 30000}]}
    chapters = chapter_list(tl)
    assert [(c["id"], c["start_ms"], c["title"]) for c in chapters] == [("concept", 0, "What it checks")]


def test_media_never_shares_the_page_path():
    assert media_path("ragas", "ragas.faithfulness") != "/academy/ragas/ragas.faithfulness/"


# ----------------------------------------------------------------------------- scaffolding and wizard


def test_course_and_lesson_scaffolds(tmp_path, house, monkeypatch):
    monkeypatch.setattr("lectern.scaffold.resolve_commit", lambda repo, ref: "a" * 40)
    new_course(tmp_path, house, "demo", "Demo course", "topic", ["lib=https://example.com/lib.git@v1.0"], log=lambda *_: None)
    course = load_course(tmp_path)
    assert course.sources["lib"].commit == "a" * 40
    new_lesson(tmp_path, house, course, "demo.first", "drilldown", "Score one answer.", "A high score means correct.")
    assert "demo.first" in load_course(tmp_path).skeleton.drilldowns
    with pytest.raises(LecternError, match="cap-reason"):
        new_lesson(tmp_path, house, load_course(tmp_path), "demo.second", "recipe", "Do it.", "Seed.", cap_minutes=9)
    with pytest.raises(LecternError):
        parse_source("no-ref-here")


def test_wizard_keeps_on_enter_resets_on_default_and_revalidates(tmp_path, house):
    answers = iter(["", "40", "12", "default"])
    w = Wizard(house, tmp_path, ask=lambda prompt: next(answers), say=lambda *_: None)
    assert w.question("cap_minutes", current=8, inherited=6) == 8      # Enter keeps the current value
    assert w.question("cap_minutes", current=8, inherited=6) == 12     # 40 is rejected, then 12 is taken
    assert w.question("fidelity", current="slides", inherited="full") == "full"  # default resets


def test_wizard_resumes_from_saved_answers(tmp_path, house):
    st_path = tmp_path / "wizard-state.json"
    st_path.write_text(json.dumps({"mode": "lesson", "answers": {"lesson.id": "demo.x"}}))
    w = Wizard(house, tmp_path, ask=lambda p: "", say=lambda *_: None)
    assert w.load_state("lesson")["answers"] == {"lesson.id": "demo.x"}
    assert w.load_state("course")["answers"] == {}


# ----------------------------------------------------------------------------- captions


def _words(text, start=0.0, per=0.3):
    from lectern.package import word_spans

    spans = word_spans(text)
    return spans, [{"word": text[a:b], "start_ms": (start + i * per) * 1000, "end_ms": (start + (i + 1) * per) * 1000}
                   for i, (a, b) in enumerate(spans)]


def test_caption_cuts_prefer_a_comma_and_never_orphan_a_word():
    from lectern.package import balanced_cuts

    text = "The client is async on purpose, because even the synchronous score method runs the async path."
    spans, words = _words(text)
    groups = balanced_cuts(text, spans, words, 84, 6.0)
    first_end = spans[groups[0][1]][1]
    assert text[first_end] == ","  # the cut lands on the comma
    text2 = "The score runs from zero to one, and higher means the answer sticks closer to its context."
    spans2, words2 = _words(text2)
    groups2 = balanced_cuts(text2, spans2, words2, 84, 6.0)
    assert all(b - a >= 2 for a, b in groups2)  # no one-word cue


def test_caption_cues_respect_both_limits():
    from lectern.package import balanced_cuts

    text = " ".join(["word"] * 40)
    spans, words = _words(text, per=0.5)
    for a, b in balanced_cuts(text, spans, words, 84, 6.0):
        assert spans[b][1] - spans[a][0] <= 84
        assert (words[b]["end_ms"] - words[a]["start_ms"]) / 1000 <= 6.0
