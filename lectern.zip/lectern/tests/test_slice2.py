"""Slice 2: stack checkouts, terminal and browser captures against a stack, segmented casts, steps geometry,
source-backed code, staleness, and the frame inspector's bookkeeping."""
import json
import subprocess
from pathlib import Path

import pytest
import yaml
from PIL import Image

from lectern.config import House, load_course
from lectern.paths import CoursePaths, LecternError

GIT = ["git", "-c", "user.name=Test", "-c", "user.email=test@example.invalid", "-c", "init.defaultBranch=main"]


def git(cwd: Path, *args: str) -> str:
    return subprocess.run([*GIT, *args], cwd=cwd, check=True, capture_output=True, text=True).stdout.strip()


@pytest.fixture()
def house() -> House:
    return House()


@pytest.fixture()
def stack_course(tmp_path, monkeypatch):
    """A sibling stack repo tagged v1.0.0, and a course pinned to it by a relative path."""
    monkeypatch.setenv("LECTERN_SOURCES", str(tmp_path / "sources"))
    stack = tmp_path / "stack-repo"
    (stack / "app").mkdir(parents=True)
    (stack / "app" / "main.py").write_text("print('serving')\n")
    (stack / "README.md").write_text("The stack answers questions.\n")
    git(stack, "init", "-q")
    git(stack, "add", "-A")
    git(stack, "commit", "-q", "-m", "one")
    git(stack, "tag", "-a", "v1.0.0", "-m", "v1.0.0")
    commit = git(stack, "rev-parse", "HEAD")
    course = tmp_path / "course"
    course.mkdir()
    (course / "course.yaml").write_text(yaml.safe_dump({
        "id": "demo", "title": "Demo", "kind": "stack",
        "sources": {"stack": {"repo": "../stack-repo", "ref": "v1.0.0", "commit": commit}},
        "pins": {"lectern": "0.2.0"}}, sort_keys=False))
    paths = CoursePaths(course)
    for d in (paths.lessons, paths.capture_scripts, paths.captures):
        d.mkdir()
    return paths, stack, commit


# ----------------------------------------------------------------------------- sources and checkouts


def test_relative_repos_resolve_against_the_course(stack_course):
    from lectern.sources import fetch_all, read_source, repo_name, slug

    paths, _, commit = stack_course
    course = load_course(paths.root)
    assert slug("../stack-repo") == "stack-repo" and repo_name("git@host:team/rag.git") == "rag"
    fetch_all(paths, course)
    assert "answers questions" in read_source(course, "stack", "README.md")


def test_stack_checkout_is_fresh_on_request_and_refuses_edits(stack_course):
    from lectern.sources import stack_checkout

    paths, _, commit = stack_course
    course = load_course(paths.root)
    cwd, meta = stack_checkout(paths, course, "stack", fresh=True, log=lambda *_: None)
    assert meta["commit"] == commit and meta["folder"] == "stack-repo"
    (cwd / "models.bin").write_text("downloaded")           # untracked state survives a reuse
    assert stack_checkout(paths, course, "stack", log=lambda *_: None)[0] == cwd
    (cwd / "app" / "main.py").write_text("print('edited')\n")  # a tracked edit does not
    with pytest.raises(LecternError, match="tracked files changed"):
        stack_checkout(paths, course, "stack", log=lambda *_: None)
    stack_checkout(paths, course, "stack", fresh=True, log=lambda *_: None)
    assert not (cwd / "models.bin").exists() and "serving" in (cwd / "app" / "main.py").read_text()


def test_repin_moves_only_the_commit_line(stack_course):
    from lectern.sources import repin

    paths, stack, old = stack_course
    (stack / "README.md").write_text("The stack answers questions, now faster.\n")
    git(stack, "commit", "-qam", "two")
    git(stack, "tag", "-f", "-a", "v1.0.0", "-m", "moved")
    before, after = repin(paths, load_course(paths.root), "stack")
    assert before == old and after == git(stack, "rev-parse", "HEAD")
    assert load_course(paths.root).sources["stack"].commit == after


# ----------------------------------------------------------------------------- terminal captures


def test_terminal_capture_in_a_stack_with_cd_until_and_names_only(stack_course, monkeypatch):
    from lectern.capture import cast_text, run_capture

    paths, _, commit = stack_course
    monkeypatch.setenv("LECTERN_TEST_SECRET", "do-not-record-me")
    (paths.capture_scripts / "run.yaml").write_text(yaml.safe_dump({
        "id": "run", "kind": "terminal", "stack": "stack", "fresh": True, "cols": 60, "rows": 8,
        "env_pass": ["LECTERN_TEST_SECRET"],
        "steps": [{"id": "into", "run": "cd app"},
                  {"id": "where", "run": "pwd && test -n \"$LECTERN_TEST_SECRET\" && echo has-secret"},
                  {"id": "serve", "run": "echo ready to serve; sleep 30", "until": "ready to serve", "timeout": 20}]}))
    run_capture(paths, "run", log=lambda *_: None)
    meta = json.loads((paths.captures / "run" / "meta.json").read_text())
    text = cast_text(paths.captures / "run.cast")
    assert [m["id"] for m in meta["marks"]] == ["into", "where", "serve"]
    assert meta["stopped"] == {"serve": "ready to serve"} and meta["stack"]["commit"] == commit
    assert "LECTERN_TEST_SECRET" in meta["env_passed"]
    assert "~/stack-repo/app" in text and "has-secret" in text and "ready to serve" in text
    for f in (paths.captures / "run.cast", paths.captures / "run" / "meta.json"):
        assert "do-not-record-me" not in f.read_text()
    assert not text.rstrip().endswith("$"), "a command stopped by until still owns the terminal"


def test_until_must_be_the_last_step(stack_course):
    from lectern.capture import run_capture

    paths, _, _ = stack_course
    (paths.capture_scripts / "bad.yaml").write_text(yaml.safe_dump({
        "id": "bad", "kind": "terminal", "steps": [{"id": "a", "run": "echo go; sleep 30", "until": "go"},
                                                   {"id": "b", "run": "echo after"}]}))
    with pytest.raises(LecternError, match="must be the last step"):
        run_capture(paths, "bad", log=lambda *_: None)


# ----------------------------------------------------------------------------- cast segments


def _marks(paths: CoursePaths, cap: str, marks: list[dict]) -> None:
    (paths.captures / cap).mkdir(parents=True, exist_ok=True)
    (paths.captures / cap / "meta.json").write_text(json.dumps({"id": cap, "marks": marks}))


def test_cast_plays_one_command_per_cue_and_holds_between(stack_course):
    from lectern.timeline import plan_cast

    paths, _, _ = stack_course
    _marks(paths, "qs", [{"id": "env", "prompt": 0.4, "start": 1.0, "end": 2.0},
                         {"id": "models", "prompt": 2.5, "start": 3.1, "end": 6.0},
                         {"id": "up", "prompt": 6.5, "start": 7.1, "end": 8.0}])
    cues = [{"verb": "play", "target": "env", "at": 2.0, "span": "a"},
            {"verb": "play", "target": None, "at": 4.0, "span": "b"},
            {"verb": "play", "target": "up", "at": 5.0, "span": "c"}]
    segments, hold, busy, late = plan_cast(paths, "qs", cues, 9.0, 0.0)
    assert hold == pytest.approx(0.41)
    assert [(s["step"], s["at"], s["from"], s["to"]) for s in segments] == [
        ("env", 2.0, 1.0, pytest.approx(2.51)), ("models", 4.0, 3.1, pytest.approx(6.51)),
        ("up", pytest.approx(7.41), 7.1, 9.0)]
    assert late and late[0][0] == "c"   # the third cue waited for the second command
    assert busy == pytest.approx(7.41 + 1.9)


def test_a_later_scene_picks_up_the_terminal_where_its_first_command_starts(stack_course):
    from lectern.timeline import plan_cast

    paths, _, _ = stack_course
    _marks(paths, "qs", [{"id": "env", "prompt": 0.4, "start": 1.0, "end": 2.0},
                         {"id": "models", "prompt": 2.5, "start": 3.1, "end": 6.0},
                         {"id": "up", "prompt": 6.5, "start": 7.1, "end": 8.0}])
    later = [{"verb": "play", "target": "models", "at": 1.0, "span": "a"},
             {"verb": "play", "target": "up", "at": 6.0, "span": "b"}]
    segments, hold, _, _ = plan_cast(paths, "qs", later, 9.0, 0.0)
    assert hold == pytest.approx(2.51)   # the models prompt, with the env command above it
    assert [s["step"] for s in segments] == ["models", "up"]


def test_a_cast_without_marks_plays_whole(stack_course):
    from lectern.timeline import plan_cast

    paths, _, _ = stack_course
    segments, hold, _, _ = plan_cast(paths, "old", [], 12.0, 1.5)
    assert hold == 0.0 and segments == [{"at": 1.5, "from": 0.0, "to": 12.0, "step": "old"}]


# ----------------------------------------------------------------------------- steps scenes


def _browser_capture(paths: CoursePaths, cap: str = "tour") -> None:
    d = paths.captures / cap / "steps"
    d.mkdir(parents=True)
    for name in ("00-start", "01-open", "02-app"):
        Image.new("RGB", (64, 36), "black").save(d / f"{name}.png")
        (d / f"{name}.txt").write_text(f"page text of {name}\nOrbit caches search results for 10 minutes.")
    (paths.captures / cap / "meta.json").write_text(json.dumps({
        "id": cap, "kind": "browser", "viewport": [1280, 720], "url": "http://localhost:10350/",
        "steps": [{"id": "start", "file": "steps/00-start.png", "action": None, "url": "http://localhost:10350/"},
                  {"id": "open", "file": "steps/01-open.png", "action": "click", "touched": [100, 100, 40, 20],
                   "url": "http://localhost:10350/r/app/overview"},
                  {"id": "app", "file": "steps/02-app.png", "action": "goto", "url": "http://localhost:5000/"}]}))
    (paths.captures / cap / "targets.json").write_text(json.dumps({
        "counter": {"step": "start", "box": [688.8, 19.0, 45.5, 19.5], "phase": "after"},
        "line": {"step": "open", "box": [337, 489.5, 943, 19.5], "phase": "after"}}))


def test_goto_steps_crossfade_and_every_action_knows_its_cue(stack_course):
    from lectern.steps import load_capture, plan

    paths, _, _ = stack_course
    _browser_capture(paths)
    cap = load_capture(paths, "tour")
    cues = [{"verb": "play", "target": "open", "at": 1.0}, {"verb": "spotlight", "target": "line", "at": 2.0},
            {"verb": "play", "target": "app", "at": 6.0}]
    actions, _ = plan(cap, cues, 0)
    assert [(a["do"], a["cue"]) for a in actions] == [("play", 0), ("spotlight", 1), ("show", 2)]
    assert actions[1]["t"] > 2.0, "the accent waits for the click before it"


def test_accents_scale_to_the_window_and_stay_inside_it(stack_course, house):
    from lectern.render import compose_steps
    from lectern.steps import load_capture, plan

    paths, _, _ = stack_course
    _browser_capture(paths)
    cap = load_capture(paths, "tour")
    actions, _ = plan(cap, [{"verb": "spotlight", "target": "counter", "at": 1.0},
                            {"verb": "play", "target": "open", "at": 3.0},
                            {"verb": "spotlight", "target": "line", "at": 6.0}], 0)
    scene = {"id": "s", "steps": {"capture": "tour", "start": 0, "actions": actions}}
    _, ctx, _ = compose_steps(paths, scene, house.tokens, house.motion, 1920, 1080)
    k = ctx["view_w"] / 1280
    counter, line = ctx["accents"]
    assert counter["x"] == pytest.approx(688.8 * k - 10, abs=0.2)
    assert line["x"] + line["w"] <= ctx["view_w"] - 4 + 0.01, "a full-width box is clamped to the page"
    assert [a["text"] for a in ctx["addresses"]] == ["localhost:10350", "localhost:10350/r/app/overview"]


def test_run_claims_quote_a_browser_capture(stack_course):
    from lectern.capture import capture_text

    paths, _, _ = stack_course
    _browser_capture(paths)
    assert "Orbit caches search results for 10 minutes." in capture_text(paths, "tour")
    assert capture_text(paths, "missing") is None


# ----------------------------------------------------------------------------- code from a pinned source


def test_code_from_the_stack_passes_only_when_a_capture_ran_that_commit(stack_course):
    from lectern.checks import check_code_ran

    paths, _, commit = stack_course
    plan = {"lesson": {"front": {"captures": ["run"]}},
            "scenes": [{"id": "code", "layout": "code",
                        "code": {"src": "stack:app/main.py", "source": "stack", "commit": commit}}]}
    _, broken = check_code_ran(paths, plan)
    assert broken and "no capture in this lesson ran stack" in broken[0]
    (paths.captures / "run").mkdir(parents=True)
    (paths.captures / "run" / "meta.json").write_text(json.dumps({"stack": {"source": "stack", "commit": commit}}))
    assert check_code_ran(paths, plan)[1] == []


# ----------------------------------------------------------------------------- staleness


def test_newer_versions_ignore_prereleases_and_order_oldest_first():
    from lectern.stale import newer_versions

    assert newer_versions(["v1.0.0", "v1.1.0", "v2.0.0rc1", "v1.0.1", "junk"], "v1.0.0") == ["v1.0.1", "v1.1.0"]
    assert newer_versions(["v2.0.0"], "main") == []


def test_stale_flags_changed_paths_and_new_tags_then_clears_with_a_repin(stack_course, house):
    from lectern.sources import fetch_all, repin
    from lectern.stale import flag_page, lesson_flag, run_stale

    paths, stack, commit = stack_course
    course = load_course(paths.root)
    fetch_all(paths, course)
    paths.lesson_script("demo.qs").write_text("---\nid: demo.qs\ntitle: Quick start\ncaptures: [run]\n---\n\n"
                                              "## a  layout=cast  capture=run\nHello.\n")
    paths.claims_ledger("demo.qs").write_text(yaml.safe_dump({"qs-1": {
        "kind": "doc", "source": {"repo": "stack", "ref": "v1.0.0", "path": "README.md"},
        "excerpt": "The stack answers questions."}}))
    (paths.captures / "run").mkdir(parents=True)
    (paths.captures / "run" / "meta.json").write_text(json.dumps(
        {"stack": {"source": "stack", "commit": commit, "paths": ["app"]}}))
    page = paths.dist_dir("demo", "demo.qs") / "page.md"
    page.parent.mkdir(parents=True)
    page.write_text("---\ntitle: Quick start\nlectern:\n  stale: false\n---\n\n# Quick start\n")

    assert not run_stale(paths, course, house, log=lambda *_: None)["lessons"]["demo.qs"]["stale"]

    (stack / "app" / "main.py").write_text("print('serving v2')\n")
    (stack / "README.md").write_text("The stack now answers in two ways.\n")
    git(stack, "commit", "-qam", "v2")
    git(stack, "tag", "-a", "v1.1.0", "-m", "v1.1.0")
    report = run_stale(paths, course, house, log=lambda *_: None)
    reasons = " ".join(report["lessons"]["demo.qs"]["reasons"])
    assert "v1.1.0" in reasons and "qs-1" in reasons and "app/main.py" in reasons
    assert lesson_flag(paths, "demo.qs") and "v1.1.0" in page.read_text()

    # Re-pinning changes what the verdict was reached against, so the old flag no longer applies.
    (paths.root / "course.yaml").write_text((paths.root / "course.yaml").read_text().replace("v1.0.0", "v1.1.0"))
    repin(paths, load_course(paths.root), "stack")
    assert lesson_flag(paths, "demo.qs") is False
    assert flag_page(paths, "demo", "demo.qs", False) and "stale: false" in page.read_text()


# ----------------------------------------------------------------------------- frame inspector


def test_inspector_output_must_cover_every_frame_with_known_kinds():
    from lectern.inspector import validate_inspection

    bundle = {"items": [{"item": "f000"}, {"item": "f001"}], "mp4": "abc"}
    with pytest.raises(LecternError, match="every frame once"):
        validate_inspection({"frames": [{"item": "f000", "issues": []}]}, bundle)
    with pytest.raises(LecternError, match="issue kind"):
        validate_inspection({"frames": [{"item": "f000", "issues": [{"kind": "ugly", "severity": "major"}]},
                                        {"item": "f001", "issues": []}]}, bundle)
    out = validate_inspection({"frames": [{"item": "f001", "issues": [{"kind": "overflow", "severity": "minor"}]},
                                          {"item": "f000", "issues": [{"kind": "collision", "severity": "major"}]}]},
                              bundle)
    assert [(f["item"], f["verdict"]) for f in out["frames"]] == [("f000", "issue"), ("f001", "ok")]


def test_inspector_calibration_ships_planted_and_clean_frames(house):
    from lectern.inspector import calibration_bundle, score_calibration

    bundle, expect = calibration_bundle(house)
    assert all(Path(i["image"]).exists() for i in bundle["items"])
    planted = {k for k, v in expect.items() if v}
    assert planted and len(planted) < len(expect)
    lazy = {"frames": [{"item": i["item"], "issues": []} for i in bundle["items"]]}
    assert len(score_calibration(lazy, expect)) == len(planted)


# ----------------------------------------------------------------------------- page


def test_page_lists_the_commands_a_viewer_types(stack_course):
    from lectern.package import commands_block

    block = commands_block([{"commands": ["cp .env.example .env", "tilt up"], "stopped": {},
                             "stack": {"source": "stack", "repo": "https://gitlab.example.com/team/rag.git",
                                       "ref": "v1.0.0"}},
                            {"commands": ["tilt down"], "stopped": {},
                             "stack": {"source": "stack", "repo": "https://gitlab.example.com/team/rag.git",
                                       "ref": "v1.0.0"}}])
    assert block == ["git clone --branch v1.0.0 https://gitlab.example.com/team/rag.git", "cd rag",
                     "cp .env.example .env", "tilt up", "tilt down"]


def test_the_narration_cache_comes_from_env_then_machine_then_course(stack_course, monkeypatch, tmp_path):
    from lectern.config import load_course, tts_cache_dir

    paths, _, _ = stack_course
    monkeypatch.setenv("LECTERN_MACHINE", str(tmp_path / "machine.yaml"))
    monkeypatch.delenv("LECTERN_TTS_CACHE", raising=False)
    course = load_course(paths.root)
    assert tts_cache_dir(paths.root, course) == paths.root / ".lectern" / "cache" / "tts"
    course.tts_cache = "tts"                              # committed with Git LFS after the pilot
    assert tts_cache_dir(paths.root, course) == paths.root / "tts"
    (tmp_path / "machine.yaml").write_text("tts_cache: /srv/lectern/tts\n")   # the render server's shared cache
    assert tts_cache_dir(paths.root, course) == Path("/srv/lectern/tts")
    monkeypatch.setenv("LECTERN_TTS_CACHE", str(tmp_path / "shared"))
    assert tts_cache_dir(paths.root, course) == tmp_path / "shared"


def test_commands_block_marks_stops_prints_notes_and_never_trails_a_comment(stack_course):
    from lectern.config import load_course
    from lectern.package import commands_block, lesson_commands

    paths, _, _ = stack_course
    course = load_course(paths.root)
    local = {"source": "stack", "repo": "../rag-demo-stack", "ref": "v0.1.0"}
    groups = [{"commands": ["cp .env.example .env", "tilt up"], "ids": ["env", "up"], "stopped": {"up": "(ctrl-c)"},
               "notes": {"env": "Behind a proxy, set PROXY_CA in .env now."}, "stack": local},
              {"commands": ["tilt down"], "ids": ["down"], "stopped": {}, "notes": {}, "stack": local}]
    block = commands_block(groups)
    assert block == ["git clone --branch v0.1.0 <rag-demo-stack repo URL>", "cd rag-demo-stack",
                     "cp .env.example .env", "# Behind a proxy, set PROXY_CA in .env now.",
                     "tilt up", "# keeps running until you press Ctrl-C", "tilt down"]
    assert all(line.startswith("#") or "#" not in line for line in block)
    # A clone URL from course.yaml replaces the placeholder.
    groups[0]["stack"] = dict(local, clone="https://gitlab.example.com/team/rag-demo-stack.git")
    assert commands_block(groups)[0] == "git clone --branch v0.1.0 https://gitlab.example.com/team/rag-demo-stack.git"

    # lesson_commands reads notes from the capture spec, so a reworded note needs no new capture.
    (paths.capture_scripts / "qs.yaml").write_text(
        "id: qs\nkind: terminal\nsteps:\n  - id: env\n    run: cp .env.example .env\n    note: >-\n"
        "      Set PROXY_CA\n      in .env.\n")
    (paths.captures / "qs").mkdir(parents=True)
    (paths.captures / "qs" / "meta.json").write_text(json.dumps({
        "commands": ["cp .env.example .env"], "marks": [{"id": "env"}], "stopped": {},
        "stack": {"source": "stack", "repo": "../rag-demo-stack", "ref": "v0.1.0"}}))
    got = lesson_commands(paths, {"scenes": [{"layout": "cast", "cast": {"id": "qs"}}]}, course)
    assert got[0]["notes"] == {"env": "Set PROXY_CA in .env."} and got[0]["ids"] == ["env"]
    assert got[0]["stack"]["clone"] is None
    # The repo and ref come from course.yaml, not from what the capture recorded.
    assert got[0]["stack"]["repo"] == "../stack-repo" and got[0]["stack"]["ref"] == "v1.0.0"


def test_before_you_start_names_needs_the_clone_and_each_app_once(stack_course):
    from lectern.package import before_block, lesson_pages

    paths, _, _ = stack_course
    (paths.captures / "tour").mkdir(parents=True)
    (paths.captures / "tour" / "meta.json").write_text(json.dumps({"steps": [
        {"id": "start", "url": "http://localhost:10350/", "title": "✔︎ 5/5 ┊ Tilt"},
        {"id": "logs", "url": "http://localhost:10350/r/app/overview", "title": "✔︎ 5/5 ┊ Tilt"},
        {"id": "app", "url": "http://localhost:5000/", "title": "Ask the docs"}]}))
    plan = {"scenes": [{"layout": "steps", "steps": {"id": "tour"}}]}
    pages = lesson_pages(paths, plan)
    assert pages == [{"title": "Tilt", "url": "http://localhost:10350/"},
                     {"title": "Ask the docs", "url": "http://localhost:5000/"}]
    block = "\n".join(before_block({"needs": ["Docker"]}, [{"stack": {"repo": "../rag-demo-stack", "ref": "v0.1.0",
                                                                     "source": "stack"}, "commands": []}], pages))
    assert "- Docker" in block and "`rag-demo-stack` at tag `v0.1.0`" in block and "[Tilt](http://localhost:10350/)" in block
    assert before_block({}, [], []) == []


def test_a_capture_that_is_not_fresh_starts_where_the_quick_start_left_the_stack(stack_course):
    from lectern.config import set_yaml_key
    from lectern.package import before_block, commands_block, lesson_commands

    paths, _, _ = stack_course
    set_yaml_key(paths.root / "course.yaml", "skeleton.quickstart", "demo.quickstart")
    paths.lesson_script("demo.quickstart").write_text("---\nid: demo.quickstart\ntitle: Run the stack\n---\n")
    for cid, fresh, cmd in (("qs", True, "tilt up"), ("inside", False, "curl -s localhost:5000/healthz")):
        (paths.capture_scripts / f"{cid}.yaml").write_text(
            f"id: {cid}\nkind: terminal\nfresh: {str(fresh).lower()}\nsteps:\n  - id: s\n    run: {cmd}\n")
        (paths.captures / cid).mkdir(parents=True)
        (paths.captures / cid / "meta.json").write_text(json.dumps({
            "commands": [cmd], "marks": [{"id": "s"}], "stopped": {},
            "stack": {"source": "stack", "repo": "../stack-repo", "ref": "v1.0.0"}}))
    course = load_course(paths.root)
    drill = lesson_commands(paths, {"lesson": {"id": "demo.app"}, "scenes": [{"layout": "cast", "cast": {"id": "inside"}}]},
                            course)
    assert commands_block(drill) == ["curl -s localhost:5000/healthz"]  # no clone: it starts in the set-up folder
    before = "\n".join(before_block({}, drill, []))
    assert "Start in the `stack-repo` folder you set up in [Run the stack](/academy/demo/demo.quickstart)" in before
    assert "fresh clone" not in before
    quick = lesson_commands(paths, {"lesson": {"id": "demo.quickstart"},
                                    "scenes": [{"layout": "cast", "cast": {"id": "qs"}}]}, course)
    assert commands_block(quick)[:2] == ["git clone --branch v1.0.0 <stack-repo repo URL>", "cd stack-repo"]
    assert "Start from a fresh clone of `stack-repo`" in "\n".join(before_block({}, quick, []))
