"""Slice 3: the course Map. map.yaml validation and one-time drafting, map scenes, the trace verb, the drilldown
rule, shared-Map transitions, and the build record that reopens a lesson when the Map moves."""
import json
import math
import re

import pytest
import yaml

from lectern.config import House, load_course
from lectern.paths import CoursePaths, LecternError

MAP = """# The demo system. Positions are grid cells, centres of the components.
grid: [12, 6]
heading: The demo system
nodes:
  - {id: browser, label: Your browser, at: [1.6, 1.2]}
  - {id: app,     label: "App\\nFlask", at: [6, 1.2]}
  - {id: llm,     label: Generator,    at: [10.4, 4]}
edges:
  - {id: ask, from: browser, to: app, label: question}
  - {id: gen, from: app,     to: llm, label: prompt}
"""


@pytest.fixture()
def house() -> House:
    return House()


@pytest.fixture()
def map_course(tmp_path):
    root = tmp_path / "course"
    root.mkdir()
    (root / "course.yaml").write_text(yaml.safe_dump({
        "id": "demo", "title": "Demo", "kind": "stack", "map": "map.yaml",
        "skeleton": {"map": "demo.map", "drilldowns": ["demo.app"]}}, sort_keys=False))
    (root / "map.yaml").write_text(MAP)
    paths = CoursePaths(root)
    paths.lessons.mkdir()
    return paths


def lesson(paths: CoursePaths, lid: str, front: dict, body: str) -> None:
    paths.lesson_script(lid).write_text("---\n" + yaml.safe_dump({"id": lid, **front}, sort_keys=False) + "---\n" + body)


def compile_it(paths, house, lid):
    from lectern.compile import compile_lesson

    return compile_lesson(paths, load_course(paths.root), house, lid)[0]


# ----------------------------------------------------------------------------- map.yaml


def test_every_map_problem_is_reported_in_one_pass():
    from lectern.coursemap import map_problems

    spec = {"grid": [12, 6], "nodes": [{"id": "app", "label": "App"}, {"id": "app", "label": "Again", "at": [1, 1]},
                                       {"id": "Bad Id", "label": "x", "at": [1, 1]}, {"id": "far", "label": "Far", "at": [13, 2]}],
            "edges": [{"id": "e1", "from": "app", "to": "ghost"}]}
    errs = "\n".join(map_problems(spec, "map.yaml"))
    assert "app has no position" in errs and "lectern map draft" in errs
    assert "id app appears twice" in errs and "'Bad Id'" in errs
    assert "outside the 12 by 6 grid" in errs and "unknown component ghost" in errs


def test_draft_fills_only_missing_positions_and_keeps_the_file_as_written(map_course, house):
    from lectern.coursemap import draft_map

    text = re.sub(r",\s*at: \[(6, 1\.2|10\.4, 4)\]", "", MAP)
    (map_course.root / "map.yaml").write_text(text)
    drafted = draft_map(map_course, load_course(map_course.root), house)
    assert set(drafted) == {"app", "llm"}
    after = (map_course.root / "map.yaml").read_text()
    assert after.startswith("# The demo system.") and "{id: browser, label: Your browser, at: [1.6, 1.2]}" in after
    spec = yaml.safe_load(after)
    xs = {n["id"]: n["at"][0] for n in spec["nodes"]}
    assert xs["app"] < xs["llm"]  # columns follow the edges
    assert draft_map(map_course, load_course(map_course.root), house) == {}  # frozen from now on


def test_components_that_overlap_on_screen_fail(map_course, house):
    from lectern.coursemap import load_map, map_geometry

    (map_course.root / "map.yaml").write_text(MAP.replace("at: [10.4, 4]", "at: [6, 1.6]"))
    with pytest.raises(LecternError, match="app and llm overlap"):
        map_geometry(load_map(map_course, load_course(map_course.root)), house.tokens)


def test_trace_follows_an_edge_or_a_path_in_either_direction():
    from lectern.coursemap import trace_hops

    spec = yaml.safe_load(MAP)
    assert trace_hops(spec, "gen") == [{"edge": "gen", "from": "app", "to": "llm"}]
    assert [h["edge"] for h in trace_hops(spec, "browser>app>llm")] == ["ask", "gen"]
    back = trace_hops(spec, "llm>app>browser")
    assert [(h["from"], h["to"]) for h in back] == [("llm", "app"), ("app", "browser")]
    with pytest.raises(ValueError, match="no edge joins browser and llm"):
        trace_hops(spec, "browser>llm")
    with pytest.raises(ValueError, match="not an edge"):
        trace_hops(spec, "app")


def test_a_slanted_label_steps_off_its_line(house):
    from lectern.render import diagram_geometry, text_width

    spec = yaml.safe_load(MAP)
    _, edges, _ = diagram_geometry(spec, house.tokens, 1920, 1080)
    gen = next(e for e in edges if e["id"] == "gen")
    (sx, sy), (ex, ey) = [tuple(map(float, p.split(","))) for p in re.findall(r"[-\d.]+,[-\d.]+", gen["d"])]
    ux, uy = (ex - sx), (ey - sy)
    n = math.hypot(ux, uy)
    dist = abs((gen["lx"] - sx) * uy - (gen["ly"] - sy) * ux) / n  # label centre to the line
    half_w = text_width("prompt", house.tokens["size"]["small"], "400") / 2
    assert dist > 0.5 * half_w and gen["ly"] < (sy + ey) / 2  # off the line, on its upper side


# ----------------------------------------------------------------------------- compile


MAP_LESSON = """
## whole  layout=map  title="The whole system"
Here is the whole system. [The browser]{light=browser} asks the app. [A question travels across]{trace=browser>app}.

## middle  layout=map  component=app  title="The app"
The app sits in the middle. [It asks the generator]{trace=gen}, and [the answer comes back]{trace=llm>app>browser}.
"""


def test_map_scenes_draw_the_course_map_and_resolve_traces(map_course, house):
    lesson(map_course, "demo.map", {"title": "The map", "type": "map"}, MAP_LESSON)
    plan = compile_it(map_course, house, "demo.map")
    scenes = {s["id"]: s for s in plan["scenes"]}
    assert scenes["whole"]["map"]["heading"] == "The demo system" and scenes["middle"]["component"] == "app"
    cues = [c for s in scenes["middle"]["sentences"] for c in s["cues"]]
    assert [h["edge"] for h in cues[1]["params"]["hops"]] == ["gen", "ask"]
    assert plan["map"]["hash"] and plan["map"]["path"].endswith("map.yaml")


def test_map_scene_errors_name_the_fix(map_course, house):
    lesson(map_course, "demo.map", {"title": "The map", "type": "map"},
           "\n## x  layout=map  component=ghost\nHere it is. [Across]{trace=browser>llm}.\n")
    with pytest.raises(LecternError) as e:
        compile_it(map_course, house, "demo.map")
    assert "component=ghost is not on the Map" in str(e.value) and "no edge joins browser and llm" in str(e.value)


def test_a_drilldown_opens_on_the_map_with_its_component_lit(map_course, house):
    lesson(map_course, "demo.app", {"title": "The app", "type": "drilldown", "component": "app"},
           "\n## where  layout=map\nThis lesson covers the app.\n")
    plan = compile_it(map_course, house, "demo.app")
    assert next(s for s in plan["scenes"] if s["id"] == "where")["component"] == "app"
    lesson(map_course, "demo.app", {"title": "The app", "type": "drilldown"},
           "\n## where  layout=map\nThis lesson covers the app.\n")
    with pytest.raises(LecternError, match="component: <id>"):
        compile_it(map_course, house, "demo.app")
    (map_course.root / "diagrams").mkdir()
    (map_course.root / "diagrams" / "d.yaml").write_text(MAP)
    lesson(map_course, "demo.app", {"title": "The app", "type": "drilldown", "component": "app"},
           "\n## where  layout=diagram  diagram=d\nThis lesson covers the app.\n")
    with pytest.raises(LecternError, match="opens on the Map"):
        compile_it(map_course, house, "demo.app")


def test_lesson_new_asks_a_drilldown_for_its_component_and_writes_it(map_course, house):
    from lectern.scaffold import new_lesson

    course = load_course(map_course.root)
    args = ("See inside the app.", "The app indexes once, at start.")
    with pytest.raises(LecternError, match="Pass --component with its id: browser, app, llm"):
        new_lesson(map_course.root, house, course, "demo.app", "drilldown", *args)
    with pytest.raises(LecternError, match="--component ghost is not on the Map"):
        new_lesson(map_course.root, house, course, "demo.app", "drilldown", *args, component="ghost")
    with pytest.raises(LecternError, match="--component is for drilldowns"):
        new_lesson(map_course.root, house, course, "demo.map", "map", *args, component="app")
    path = new_lesson(map_course.root, house, course, "demo.app", "drilldown", *args, component="app",
                      prerequisites=["demo.map"])
    text = path.read_text()
    front = yaml.safe_load(text.split("---")[1])
    assert front["component"] == "app" and front["prerequisites"] == ["demo.map"]
    assert "layout=<title|map|" in text and "opens with app lit" in text


# ----------------------------------------------------------------------------- render


def timeline_for(plan: dict, fps: int = 30) -> dict:
    scenes, start = [], 0
    for s in plan["scenes"]:
        cues = [{**c, "t": 1.5 + 2.5 * k} for k, c in enumerate(c for x in s["sentences"] for c in x["cues"])]
        frames = fps * (4 + 3 * len(cues))
        scenes.append({"id": s["id"], "layout": s["layout"], "params": s["params"], "frames": frames,
                       "start_ms": start / fps * 1000, "cues": cues, "sentences": []})
        start += frames
    return {"lesson": plan["lesson"]["id"], "width": 1920, "height": 1080, "fps": fps, "scenes": scenes,
            "duration_ms": start / fps * 1000}


def svg_of(html: str) -> str:
    return re.search(r'<svg id="map".*?</svg>', html, re.S).group(0)


def test_every_lesson_draws_the_same_map_and_back_to_back_scenes_never_fade(map_course, house):
    from lectern.render import SceneComposer

    lesson(map_course, "demo.map", {"title": "The map", "type": "map"}, MAP_LESSON)
    lesson(map_course, "demo.app", {"title": "The app", "type": "drilldown", "component": "app"},
           "\n## where  layout=map\nThis lesson covers the app.\n")
    a, b = compile_it(map_course, house, "demo.map"), compile_it(map_course, house, "demo.app")
    ta, tb = timeline_for(a), timeline_for(b)
    ca, cb = SceneComposer(map_course, house, a, ta, {}), SceneComposer(map_course, house, b, tb, {})
    whole, _ = ca.compose(ta["scenes"][1])
    middle, _ = ca.compose(ta["scenes"][2])
    where, _ = cb.compose(tb["scenes"][1])
    strip = lambda s: re.sub(r'<g id="tracers">.*?</g></g>|<g id="tracers"></g>', "", s, flags=re.S)  # noqa: E731
    assert strip(svg_of(whole)) == strip(svg_of(middle)) == strip(svg_of(where))
    # whole follows the title card, so it fades in, and hands the Map to middle without a fade.
    assert 'tl.fromTo("#stage"' in whole and 'tl.to("#overlay", { opacity: 0' in whole
    assert 'tl.fromTo("#stage"' not in middle and 'tl.to(["#stage", "#overlay"]' in middle
    assert 'tl.to(".dimmable", { opacity: 1, duration: 0.3' in whole  # settles back to the plain Map first
    # A scene with a component opens with it lit.
    assert re.search(r'tl\.to\("#n-app \.box", \{ stroke: "#4cc2ff", strokeWidth: 5, duration: 0\.45 \}, 0\.000\)', where)


def test_trace_runs_a_dot_centre_to_centre_and_lights_as_it_goes(map_course, house):
    from lectern.coursemap import load_map, map_geometry
    from lectern.render import SceneComposer

    lesson(map_course, "demo.map", {"title": "The map", "type": "map"}, MAP_LESSON)
    plan = compile_it(map_course, house, "demo.map")
    tl = timeline_for(plan)
    html, _ = SceneComposer(map_course, house, plan, tl, {}).compose(tl["scenes"][2])
    _, _, boxes = map_geometry(load_map(map_course, load_course(map_course.root)), house.tokens)
    assert '<g class="tracer" id="tr-0" opacity="0">' in html and 'id="tr-1"' in html
    llm, app, browser = boxes["llm"], boxes["app"], boxes["browser"]
    # second trace: llm > app > browser, 1.2 s a hop
    assert f'tl.set("#tr-1", {{ x: {llm["cx"]}, y: {llm["cy"]}, opacity: 1 }}, 4.000);' in html
    assert f'tl.to("#tr-1", {{ x: {app["cx"]}, y: {app["cy"]}, duration: 1.2, ease: "none" }}, 4.000);' in html
    assert f'tl.to("#tr-1", {{ x: {browser["cx"]}, y: {browser["cy"]}, duration: 1.2, ease: "none" }}, 5.200);' in html
    assert 'tl.set("#tr-1", { opacity: 0 }, 6.400);' in html
    # app > browser crosses ask against its arrow, so the lit arrowhead moves to the start and points at the browser.
    assert 'tl.set("#e-ask .line", { attr: { "marker-end": "none", "marker-start": "url(#arrow-lit)" } }, 5.300);' in html


def test_the_build_record_reopens_a_lesson_when_the_map_moves(map_course):
    import hashlib

    from lectern.gates import render_problem

    def sha(p):
        return hashlib.sha256(p.read_bytes()).hexdigest()

    lesson(map_course, "demo.map", {"title": "The map", "type": "map"}, MAP_LESSON)
    map_course.claims_ledger("demo.map").write_text("{}\n")
    dist = map_course.dist_dir("demo", "demo.map")
    dist.mkdir(parents=True)
    (dist / "lesson.mp4").write_bytes(b"video")
    (dist / "build.json").write_text(json.dumps({
        "script": sha(map_course.lesson_script("demo.map")), "claims": sha(map_course.claims_ledger("demo.map")),
        "mp4": sha(dist / "lesson.mp4"), "quality": "standard", "fidelity": "full", "checks_ok": True,
        "map": {"path": "map.yaml", "hash": sha(map_course.root / "map.yaml")}}))
    assert render_problem(map_course, "demo", "demo.map") is None
    (map_course.root / "map.yaml").write_text(MAP.replace("[1.6, 1.2]", "[1.8, 1.2]"))
    assert "course Map changed" in render_problem(map_course, "demo", "demo.map")


def test_settled_moment_sits_before_the_first_cue_on_the_frame_grid():
    from lectern.mapcheck import settled_at

    assert settled_at({"cues": [], "frames": 300}, 30) == pytest.approx(28 / 30, abs=1e-4)
    assert settled_at({"cues": [{"verb": "light", "t": 0.7}], "frames": 300}, 30) == pytest.approx(18 / 30, abs=1e-4)
    assert settled_at({"cues": [{"verb": "light", "t": 0.2}], "frames": 300}, 30) == pytest.approx(15 / 30, abs=1e-4)


def test_a_cue_that_lands_mid_trace_is_flagged_and_the_scene_waits_for_the_dot(map_course, house, tmp_path):
    import numpy as np
    import soundfile as sf

    from lectern.timeline import build_timeline

    lesson(map_course, "demo.map", {"title": "The map", "type": "map"},
           "\n## x  layout=map\n[Across]{trace=browser>app>llm} and [the app]{light=app} at once.\n")
    plan = compile_it(map_course, house, "demo.map")
    wav = tmp_path / "s.wav"
    sf.write(wav, np.zeros(24000, dtype=np.float32), 24000)
    tts = {"voices": {}, "sentences": {}}
    for sc in plan["scenes"]:
        for s in sc["sentences"]:
            words = [{"word": w, "start": 0.3 * i, "end": 0.3 * i + 0.25, "fallback": False} for i, w in enumerate(s["words"])]
            tts["sentences"][s["id"]] = {"duration": 1.0, "words": words, "wav": str(wav)}
    eff = {"video.fps": 30, "video.width": 1920, "video.height": 1080, "title_seconds": 3}
    timeline, warnings = build_timeline(map_course, house, plan, tts, eff)
    assert any("while the trace on [Across] is still moving" in w for w in warnings)
    x = next(s for s in timeline["scenes"] if s["id"] == "x")
    trace = next(c for c in x["cues"] if c["verb"] == "trace")
    assert x["frames"] / 30 >= trace["t"] + 2 * 1.2  # the scene lasts until the dot arrives


# ----------------------------------------------------------------------------- course page, CourseMap, glossary


def fake_build(paths: CoursePaths, lid: str, scenes: list[dict], terms: dict | None = None, ms: int = 125000) -> None:
    """What `lectern build` leaves behind, as far as the site pages read it."""
    dist = paths.dist_dir("demo", lid)
    dist.mkdir(parents=True, exist_ok=True)
    (dist / "page.md").write_text("---\ntitle: x\n---\n")
    (dist / "timeline.json").write_text(json.dumps({"duration_ms": ms, "scenes": scenes}))
    build = paths.build_dir(lid)
    build.mkdir(parents=True, exist_ok=True)
    (build / "plan.json").write_text(json.dumps({"scenes": [{"id": s["id"], "component": (s.get("params") or {}).get(
        "component")} for s in scenes], "terms": terms or {}}))


def front_of(page: str) -> dict:
    return yaml.safe_load(page.split("---", 2)[1])


def test_the_course_map_links_each_component_to_its_drilldown_or_its_map_chapter(map_course, house):
    from lectern.site import course_page

    lesson(map_course, "demo.map", {"title": "The map", "type": "map"}, MAP_LESSON)
    lesson(map_course, "demo.app", {"title": "Inside the app", "type": "drilldown", "component": "app",
                                    "prerequisites": ["demo.map"]}, "\n## where  layout=map\nThis covers the app.\n")
    fake_build(map_course, "demo.map", [{"id": "whole", "params": {"title": "The whole system"}},
                                        {"id": "middle", "params": {"component": "app", "title": "The app"}},
                                        {"id": "gen-part", "params": {"component": "llm", "title": "The generator"}}])
    course = load_course(map_course.root)
    page = course_page(map_course, course, house)
    nodes = {n["id"]: n for n in front_of(page)["lectern"]["map"]["nodes"]}
    # No drilldown is built yet, so the app links to its chapter in the Map lesson.
    assert nodes["app"]["link"] == "/academy/demo/demo.map#middle"
    assert nodes["llm"]["link"] == "/academy/demo/demo.map#gen-part" and nodes["browser"]["link"] is None
    assert "<CourseMap />" in page and "| 2 | Inside the app | Drilldown |  | The map | Not built yet |" in page.replace(
        "[The map](/academy/demo/demo.map)", "The map")
    fake_build(map_course, "demo.app", [{"id": "where", "params": {}}])
    page = course_page(map_course, course, house)
    nodes = {n["id"]: n for n in front_of(page)["lectern"]["map"]["nodes"]}
    assert nodes["app"]["link"] == "/academy/demo/demo.app" and nodes["app"]["title"] == "Inside the app"
    assert "| 1 | [The map](/academy/demo/demo.map) | Map | 2:05 |  | In review |" in page


def test_the_glossary_lists_defined_terms_the_lessons_use_and_every_course_term(map_course, house):
    from lectern.site import glossary_page

    (map_course.root / "terms.yaml").write_text(yaml.safe_dump({
        "tilt": {"term": "Tilt", "define": "Runs the stack."},
        "dotenv": {"term": ".env", "say": "dot env", "define": "The settings file."},
        "loose": {"term": "Loose"}}))
    lesson(map_course, "demo.map", {"title": "The map", "type": "map"}, MAP_LESSON)
    fake_build(map_course, "demo.map", [{"id": "whole", "params": {}}], terms={"rag": {}, "tilt": {}})
    page = glossary_page(map_course, load_course(map_course.root), house)
    body = page.split("---", 2)[2]
    order = [m for m in re.findall(r'<span id="([a-z_]+)">', body)]
    assert order == ["dotenv", "rag", "tilt"]  # .env sorts as env; api, json and cli are unused house terms
    assert "| dot env |" in body and "[The map](/academy/demo/demo.map)" in body and "Loose" not in body


def test_a_scene_cannot_take_an_id_the_page_already_uses(map_course, house):
    lesson(map_course, "demo.map", {"title": "The map", "type": "map"}, "\n## app  layout=map\nHere it is.\n")
    with pytest.raises(LecternError, match="scene id `app` collides .* such as `the-app`"):
        compile_it(map_course, house, "demo.map")


def test_the_claims_judge_sees_the_map_and_where_each_box_sits(map_course, house):
    from lectern.gates import screen_text

    lesson(map_course, "demo.map", {"title": "The map", "type": "map"}, MAP_LESSON)
    plan = compile_it(map_course, house, "demo.map")
    middle = next(s for s in plan["scenes"] if s["id"] == "middle")
    text = screen_text(map_course, middle)
    assert "Boxes: Your browser, App Flask, Generator" in text and "Your browser -> App Flask (question)" in text
    assert "App Flask at top middle" in text and "Generator at bottom right" in text
    assert text.endswith("Lit when the scene opens: App Flask")


def test_a_trace_never_reverts_a_line_its_own_path_lights(house):
    from lectern.render import Verbs

    v = Verbs(house.motion, house.tokens)
    boxes = {n: {"cx": i * 100.0, "cy": 50.0} for i, n in enumerate(["browser", "app", "llm"])}
    v.trace(1.0, [{"edge": "gen", "from": "app", "to": "llm"}], boxes, "tr-0")
    v.js.clear()
    v.trace(5.0, [{"edge": "gen", "from": "llm", "to": "app"}, {"edge": "ask", "from": "app", "to": "browser"}], boxes, "tr-1")
    js = "\n".join(v.js)
    assert 'tl.to("#e-gen .line", { stroke: "#2f3b4a"' not in js and 'tl.to("#n-app .box", { stroke: "#2f3b4a"' not in js
    assert 'tl.to("#e-gen .line", { stroke: "#4cc2ff", duration: 0.2 }, 5.000);' in js


def test_a_reversed_line_gets_its_arrow_back_when_it_is_unlit(house):
    from lectern.render import Verbs

    v = Verbs(house.motion, house.tokens)
    boxes = {n: {"cx": i * 100.0, "cy": 50.0} for i, n in enumerate(["browser", "app"])}
    v.trace(1.0, [{"edge": "ask", "from": "app", "to": "browser", "reverse": True}], boxes, "tr-0")
    v.js.clear()
    v.light(4.0, "app", "node")
    assert 'tl.set("#e-ask .line", { attr: { "marker-start": "none", "marker-end": "url(#arrow)" } }, 4.000);' in v.js


def test_label_side_moves_a_slanted_label_below_its_line(house):
    from lectern.render import diagram_geometry

    spec = yaml.safe_load(MAP)
    above = next(e for e in diagram_geometry(spec, house.tokens, 1920, 1080)[1] if e["id"] == "gen")
    spec["edges"][1]["label_side"] = "below"
    below = next(e for e in diagram_geometry(spec, house.tokens, 1920, 1080)[1] if e["id"] == "gen")
    assert below["ly"] > above["ly"]


def test_long_code_lines_wrap_at_a_comma_with_a_hanging_indent(house):
    from lectern.render import code_columns, wrap_tokens

    cols = code_columns(1920, house.tokens)
    line = '    p.add_component("prompt", ChatPromptBuilder(template=PROMPT, required_variables=["documents", "question"]))'
    toks = [{"text": line[:20], "color": "#a", "italic": False, "bold": False},
            {"text": line[20:], "color": "#b", "italic": False, "bold": False}]
    rows = wrap_tokens(toks, cols, "#ink")
    text = ["".join(t["text"] for t in r) for r in rows]
    assert len(rows) == 2 and all(len(r) <= cols for r in text)
    assert text[0].endswith(", ") and text[1].startswith("        ")  # broke after a comma, indent plus four
    assert "".join(t.strip() for t in text).replace(" ", "") == line.replace(" ", "")
    assert wrap_tokens(toks[:1], cols, "#ink") == [toks[:1]]  # a line that fits is left alone


def test_a_deep_line_goes_on_right_of_its_own_indent(house):
    from lectern.render import code_columns, wrap_tokens

    cols = code_columns(1920, house.tokens)
    line = " " * 47 + 'remove_regex=r"(?m)^#.*$" if s.drop_headings else None))'
    rows = ["".join(t["text"] for t in r)
            for r in wrap_tokens([{"text": line, "color": "#a", "italic": False, "bold": False}], cols, "#i", "python")]
    assert len(rows) == 2 and all(len(r) <= cols for r in rows)
    assert len(rows[1]) - len(rows[1].lstrip(" ")) == 47 + 4  # never left of the line it goes on from


def test_a_line_that_leaves_a_bracket_open_wraps_under_it_as_the_next_line_does(house):
    from lectern.render import code_columns, wrap_tokens

    cols = code_columns(1920, house.tokens)

    def rows(line, lang="python"):
        return ["".join(t["text"] for t in r)
                for r in wrap_tokens([{"text": line, "color": "#a", "italic": False, "bold": False}], cols, "#i", lang)]

    # The next source line sits one column past DocumentCleaner's bracket, so the wrapped row starts there too.
    got = rows('    p.add_component("cleaner", DocumentCleaner(remove_empty_lines=False, remove_extra_whitespaces=False,')
    nxt = '                                               remove_regex=r"(?m)^#.*$"))'
    assert got == ['    p.add_component("cleaner", DocumentCleaner(remove_empty_lines=False,',
                   " " * 47 + "remove_extra_whitespaces=False,"]
    assert got[1].index("r") == nxt.index("r")
    # It breaks only after a comma directly inside that bracket, never inside a call nested in it.
    got = rows('        "sources": [{"file": Path(d.meta.get("file_path", "")).name, "text": d.content.strip(),')
    assert got == ['        "sources": [{"file": Path(d.meta.get("file_path", "")).name,', " " * 21 + '"text": d.content.strip(),']
    # A template string breaks after a \n it holds, never inside a tag.
    got = rows('        "Context:\\n{% for doc in documents %}- {{ doc.content }}\\n{% endfor %}\\nQuestion: {{ question }}"),')
    assert got[0].endswith("{% endfor %}\\n") and got[1].strip() == 'Question: {{ question }}"),'
    # A line that closes its brackets keeps the hanging indent, and a # in CSS is not a comment.
    assert rows("    p.add_component(\"retriever\", InMemoryEmbeddingRetriever(document_store=store, top_k=s.top_k))")[1] \
        == "        document_store=store, top_k=s.top_k))"
    assert all(len(r) <= cols for r in rows(".x { color: #fff; background: url(a.png); " * 3, "css"))


CAST = "\n".join([
    json.dumps({"version": 2, "width": 40, "height": 6, "title": "demo"}),
    json.dumps([0.0, "o", "$ "]),
    json.dumps([0.5, "o", "curl api\r\n"]),
    json.dumps([1.0, "o", '{"score": 0.734}\r\n{"score": 0.733}\r\n']),
    json.dumps([1.5, "o", "$ "]),
]) + "\n"


def cast_course(paths: CoursePaths, body: str) -> None:
    paths.captures.mkdir(exist_ok=True)
    (paths.captures / "run.cast").write_text(CAST)
    (paths.captures / "run").mkdir(exist_ok=True)
    (paths.captures / "run" / "meta.json").write_text(json.dumps({
        "commands": ["curl api"], "stopped": {},
        "marks": [{"id": "ask", "prompt": 0.0, "start": 0.2, "typed": 0.5, "end": 1.4}]}))
    lesson(paths, "demo.map", {"title": "The map", "type": "map", "captures": ["run"]}, body)


def test_mark_outlines_terminal_text_after_the_command_that_prints_it(map_course, house):
    from lectern.render import SceneComposer, cast_time, terminal_screen

    cast_course(map_course, "\n## a  layout=cast  capture=run\n[Run the call]{play=ask}. The top score is "
                            "[this one]{mark=\"0.734\"}.\n")
    plan = compile_it(map_course, house, "demo.map")
    tl = timeline_for(plan)
    scene = tl["scenes"][1]
    scene["play"] = {"hold": 0.0, "segments": [{"t": 1.5, "from": 0.2, "to": 1.6, "step": "ask"}]}
    mark_t = next(c["t"] for c in scene["cues"] if c["verb"] == "mark")
    assert cast_time(mark_t, [{"at": 1.5, "from": 0.2, "to": 1.6}], 0.0) == 1.6
    assert '{"score": 0.734}' in "".join(terminal_screen(map_course.captures / "run.cast", 40, 6, 1.6))
    html, _ = SceneComposer(map_course, house, plan, tl, {}).compose(scene)
    assert 'const MARKS = [{"id": "mark-1", "text": "0.734"}]' in html
    assert 'id="mark-1"' in html and 'id="mark-1-b"' in html  # a second outline for text split over two rows
    assert re.search(r'tl\.fromTo\(\["#mark-1", "#mark-1-b"\], \{ opacity: 0 \}, \{ opacity: 1, duration: 0\.35', html)
    assert ".then(placeMarks)" in html

    # Before the command runs, the terminal only shows its prompt, so the build says where the cue has to go.
    scene["play"] = {"hold": 0.0, "segments": [{"t": 9.0, "from": 0.2, "to": 1.6, "step": "ask"}]}
    with pytest.raises(LecternError, match="does not show it. Mark it after the command that prints it"):
        SceneComposer(map_course, house, plan, tl, {}).compose(scene)


def test_mark_needs_cast_text_the_capture_printed(map_course, house):
    cast_course(map_course, "\n## a  layout=cast  capture=run\n[Run the call]{play=ask}. "
                            "The answer is [here]{mark=\"0.999\"}.\n")
    with pytest.raises(LecternError, match="'0.999' never appears in the output of capture run"):
        compile_it(map_course, house, "demo.map")
    cast_course(map_course, "\n## a  layout=map\nThe whole map. [Here]{mark=\"0.734\"}.\n")
    with pytest.raises(LecternError, match="`mark` does not work in a map scene"):
        compile_it(map_course, house, "demo.map")


def test_a_cut_too_large_to_publish_plays_from_a_review_copy_that_fits(tmp_path):
    import subprocess

    from lectern.gates import review_copy

    src = tmp_path / "lesson.mp4"
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "lavfi", "-i", "testsrc2=size=640x360:rate=30:duration=4",
                    "-f", "lavfi", "-i", "sine=frequency=440:duration=4", "-c:v", "libx264", "-b:v", "2000k",
                    "-c:a", "aac", "-b:a", "96k", "-shortest", str(src)], check=True)
    size = src.stat().st_size
    assert review_copy(src, tmp_path / "copy.mp4", 4.0, max_bytes=size + 1) is None
    assert (tmp_path / "copy.mp4").read_bytes() == src.read_bytes()  # small enough: the very file
    got = review_copy(src, tmp_path / "small.mp4", 4.0, max_bytes=size // 2)
    assert got and (tmp_path / "small.mp4").stat().st_size <= size // 2
    probe = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "stream=codec_type,width", "-of", "csv=p=0",
                            str(tmp_path / "small.mp4")], capture_output=True, text=True).stdout
    assert "video,640" in probe and "audio" in probe  # same size frame, audio kept
    # Kept by the original's hash, so the packet after an approval reuses the re-encode instead of making another.
    cache = tmp_path / "cache"
    first = review_copy(src, tmp_path / "a.mp4", 4.0, max_bytes=size // 2, cache=cache)
    assert first["kbps"] and len(list(cache.iterdir())) == 1
    again = review_copy(src, tmp_path / "b.mp4", 4.0, max_bytes=size // 2, cache=cache)
    assert again["kbps"] is None and (tmp_path / "b.mp4").read_bytes() == (tmp_path / "a.mp4").read_bytes()


def test_code_and_terminal_text_show_the_characters_the_source_holds(map_course, house):
    from pathlib import Path

    import lectern
    from lectern.render import SceneComposer

    (map_course.root / "examples").mkdir()
    (map_course.root / "examples" / "x.py").write_text("def f(a) -> bool:\n    return a == 1\n")
    lesson(map_course, "demo.map", {"title": "The map", "type": "map"},
           "\n## code  layout=code  src=examples/x.py  lang=python\nHere is a function. [It compares]{lines=2}.\n")
    plan = compile_it(map_course, house, "demo.map")
    tl = timeline_for(plan)
    html, _ = SceneComposer(map_course, house, plan, tl, {}).compose(tl["scenes"][1])
    rule = re.search(r"\.code \{[^}]*\}", html).group(0)
    assert "font-variant-ligatures: none" in rule and '"calt" 0' in rule  # -> stays two characters, not an arrow
    cast = (Path(lectern.__file__).parent / "house" / "templates" / "cast.html.j2").read_text()
    assert re.search(r"\.ap-terminal, \.ap-player \{[^}]*font-variant-ligatures: none", cast)


def test_a_round_trip_lights_both_arrowheads_of_its_line(house):
    from lectern.render import Verbs

    v = Verbs(house.motion, house.tokens)
    boxes = {n: {"cx": i * 100.0, "cy": 50.0} for i, n in enumerate(["app", "embedder"])}
    v.trace(1.0, [{"edge": "embed", "from": "app", "to": "embedder"},
                  {"edge": "embed", "from": "embedder", "to": "app", "reverse": True}], boxes, "tr-0")
    js = "\n".join(v.js)
    assert '"marker-end": "url(#arrow-lit)", "marker-start": "url(#arrow-lit)"' in js
    v.js.clear()
    v.settle(9.0)
    assert 'tl.set("#e-embed .line", { attr: { "marker-start": "none", "marker-end": "url(#arrow)" } }, 9.000);' in v.js


def test_front_matter_ends_only_at_a_line_of_three_dashes():
    import yaml

    from lectern.script import front_matter

    page = ("---\ntitle: Inside the embedder\nclaims:\n- excerpt: |-\n    0.668  orbit-cache.md\n"
            "    ------ TOP_K is 3: only the chunks above this line reach the prompt\n---\n\n# Body\n")
    front, body = front_matter(page)
    assert yaml.safe_load(front)["claims"][0]["excerpt"].endswith("reach the prompt")  # the printed rule stays inside
    assert body == "\n\n# Body\n"
    assert front_matter("# no front matter\n") is None and front_matter("---\ntitle: open\n") is None


def test_a_newer_mark_dims_the_older_ones_or_clears_them(map_course, house):
    from lectern.render import SceneComposer

    cast_course(map_course, "\n## a  layout=cast  capture=run\n[Run the call]{play=ask}. The top score is "
                            "[this one]{mark=\"0.734\"}. The next is [that one]{mark=\"0.733\"}, close behind. "
                            "Both came from [one call]{mark=\"curl api\" trail=clear}.\n")
    plan = compile_it(map_course, house, "demo.map")
    tl = timeline_for(plan)
    scene = tl["scenes"][1]
    scene["play"] = {"hold": 0.0, "segments": [{"t": 1.5, "from": 0.2, "to": 1.6, "step": "ask"}]}
    on = [c["t"] for c in scene["cues"] if c["verb"] == "mark"]
    html, _ = SceneComposer(map_course, house, plan, tl, {}).compose(scene)
    fades = re.findall(r'tl\.to\(\["#(mark-\d+)", "#mark-\d+-b"\], \{ opacity: ([\d.]+), duration: 0\.3, '
                       r'ease: "power1\.out" \}, ([\d.]+)\);', html)
    first, second = sorted({f[0] for f in fades}, key=lambda m: int(m.split("-")[1]))
    # The second mark dims the first, and the third, with trail=clear, fades both out.
    assert (first, "0.35", f"{on[1]:.3f}") in fades and (first, "0", f"{on[2]:.3f}") in fades
    assert (second, "0", f"{on[2]:.3f}") in fades and len(fades) == 3

    cast_course(map_course, "\n## a  layout=cast  capture=run\n[Run the call]{play=ask}. "
                            "The top score is [this one]{mark=\"0.734\" trail=fade}.\n")
    with pytest.raises(LecternError, match="`mark` trail is dim or clear, not 'fade'"):
        compile_it(map_course, house, "demo.map")


def test_a_command_wider_than_the_terminal_is_flagged_before_capture():
    import random

    from lectern.capture import CONTINUE, strip_ansi, type_command, wide_commands

    long = "docker compose exec app python -m rag.evaluate --chunking passage:1 --min-score 0.5,0.6,0.7,0.8"
    spec = {"steps": [{"id": "up", "run": "docker compose up --wait"}, {"id": "cutoff", "run": long},
                      {"id": "split", "run": long.replace(" --min-score", " \\\n  --min-score")}]}
    warnings = wide_commands(spec, 96)
    assert len(warnings) == 1 and warnings[0].startswith("step cutoff types 97 characters on a 96-column terminal")

    events: list = []
    type_command(events, "a \\\nb", 0.0, 22, random.Random("x"))
    assert strip_ansi("".join(e[1] for e in events)) == "a \\\r\n> b" and CONTINUE in [e[1][2:] for e in events]


def test_say_gives_the_voice_other_words_than_the_screen(tmp_path):
    from lectern.script import parse_lesson

    p = tmp_path / "x.md"
    p.write_text("---\nid: x\n---\n\n## check  layout=checkpoint\n"
                 "> ask: The top chunk scores [0.7]{say=\"zero point seven\"}. How sure is the match?\n"
                 "> answer: It does not say: [hit@1]{say=\"hit at one\"} counts [the top]{mark=\"x\"} chunk. ^c1\n")
    lesson = parse_lesson(p, {"mark"})
    ask, how, answer = [s for _, s in lesson.sentences()]
    assert ask.text == "The top chunk scores zero point seven." and ask.shown == "The top chunk scores 0.7."
    assert ask.words[-3:] == ["zero", "point", "seven"]  # the voice is timed on the words it says
    assert how.shown is None  # nothing differs, so nothing is stored
    assert answer.shown == "It does not say: hit@1 counts the top chunk."
    assert answer.text == "It does not say: hit at one counts the top chunk." and answer.claims == ["c1"]
    assert [c.word_index for c in answer.cues] == [8]  # "the", counted in the words the voice says

    p.write_text("---\nid: x\n---\n\n## a  layout=map\nIt is [0.7]{say=\"zero point seven\" light}.\n")
    with pytest.raises(LecternError, match="`say` stands alone in its braces"):
        parse_lesson(p, {"light"})


def test_the_screen_page_and_transcript_show_the_shown_form_and_captions_follow_the_voice():
    from lectern.checks import on_screen_words
    from lectern.package import build_vtt, transcript_md

    ask = {"id": "check.s1", "text": "The top chunk scores zero point seven.", "shown": "The top chunk scores 0.7.",
           "kind": "ask", "voice": "examiner", "claims": [], "start_ms": 0.0, "end_ms": 2000.0,
           "words": [{"word": w, "start_ms": 300.0 * i, "end_ms": 300.0 * i + 250, "fallback": False}
                     for i, w in enumerate(["The", "top", "chunk", "scores", "zero", "point", "seven"])]}
    scene = {"id": "check", "layout": "checkpoint", "params": {"card": "Scores rank."}, "sentences": [ask],
             "start_ms": 0.0, "frames": 90, "cues": []}
    assert on_screen_words({"layout": "checkpoint", "params": {"card": "Scores rank."}}, scene, {}, "") == 5 + 2
    timeline = {"lesson": "x", "scenes": [scene], "duration_ms": 3000.0}
    plan = {"lesson": {"id": "x", "front": {"title": "X"}}, "course": {"title": "C"}}
    assert "The top chunk scores 0.7." in transcript_md(timeline, plan)
    assert "zero point seven" in build_vtt(timeline) and "0.7" not in build_vtt(timeline)
