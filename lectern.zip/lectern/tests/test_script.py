from pathlib import Path

import pytest

from lectern.config import set_yaml_key
from lectern.paths import LecternError
from lectern.script import parse_lesson, split_sentences
from lectern.tts import align

VERBS = {"light", "pulse", "lines", "play", "chip", "callout"}

SCRIPT = """---
id: demo.lesson
title: Demo
---

## concept  layout=diagram  diagram=faith
Faithfulness asks one question. Is every claim in the [answer]{light}
backed by the retrieved [context]{light}? ^faith-01

The score runs from 0 to 1. ^faith-02

## code  layout=code  src=x.py  show=1-5
[These four lines]{lines=2-5} score one answer. ^faith-03

> ask: An answer scores 1.0 and is still wrong. How?
> answer: The context was wrong. ^faith-04
> Faithfulness never sees the truth. ^faith-05
"""


def write(tmp_path: Path, text: str) -> Path:
    p = tmp_path / "demo.lesson.md"
    p.write_text(text)
    return p


def test_parses_scenes_sentences_cues_and_claims(tmp_path):
    lesson = parse_lesson(write(tmp_path, SCRIPT), VERBS)
    assert [s.id for s in lesson.scenes] == ["concept", "code", "code-checkpoint"]
    concept = lesson.scenes[0]
    assert [s.text for s in concept.sentences] == [
        "Faithfulness asks one question.",
        "Is every claim in the answer backed by the retrieved context?",
        "The score runs from 0 to 1.",
    ]
    second = concept.sentences[1]
    assert second.claims == ["faith-01"]
    assert [(c.verb, c.target, c.word_index) for c in second.cues] == [("light", None, 5), ("light", None, 10)]
    assert concept.sentences[1].paragraph_end and concept.sentences[2].paragraph_end
    code = lesson.scenes[1]
    assert code.sentences[0].cues[0].target == "2-5"
    check = lesson.scenes[2]
    assert check.layout == "checkpoint"
    assert [(s.kind, s.voice) for s in check.sentences] == [
        ("ask", "examiner"), ("ask", "examiner"), ("answer", "narrator"), ("answer", "narrator")]
    assert check.sentences[3].claims == ["faith-05"]


def test_decimal_numbers_do_not_split_sentences():
    text = "It scored 0.5 on the first run. Then it scored 1.0."
    spans = split_sentences(text, [])
    assert [text[a:b] for a, b in spans] == ["It scored 0.5 on the first run.", "Then it scored 1.0."]


def test_claim_tag_must_follow_a_sentence(tmp_path):
    bad = "---\nid: demo.lesson\n---\n\n## a  layout=title\n^orphan Text here.\n"
    with pytest.raises(LecternError):
        parse_lesson(write(tmp_path, bad), VERBS)


def test_line_numbers_point_at_the_script(tmp_path):
    lesson = parse_lesson(write(tmp_path, SCRIPT), VERBS)
    assert lesson.scenes[0].line == 6
    assert lesson.scenes[1].sentences[0].line == 13


def test_align_maps_words_to_kokoro_tokens():
    text = "We trace each request in Langfuse, then score it."
    words = ["We", "trace", "each", "request", "in", "Langfuse", "then", "score", "it"]
    reps = [{"start": 25, "end": 33, "expect": ["Langfuse"]}]
    tokens = [{"text": w, "start": i * 0.3, "end": i * 0.3 + 0.25} for i, w in enumerate(
        ["We", "trace", "each", "request", "in", "Langfuse", ",", "then", "score", "it", "."])]
    out = align(text, words, reps, tokens)
    assert [o["fallback"] for o in out] == [False] * 9
    assert out[5]["start"] == pytest.approx(1.5)
    assert out[6]["start"] == pytest.approx(2.1)


def test_align_respelled_term_takes_its_first_token():
    text = "Run it in WSL today."
    words = ["Run", "it", "in", "WSL", "today"]
    reps = [{"start": 10, "end": 13, "expect": ["W", "S", "L"]}]
    tokens = [{"text": w, "start": i * 0.2, "end": i * 0.2 + 0.15} for i, w in enumerate(["Run", "it", "in", "W", "S", "L", "today", "."])]
    out = align(text, words, reps, tokens)
    assert out[3]["start"] == pytest.approx(0.6)
    assert out[4]["start"] == pytest.approx(1.2)


def test_set_yaml_key_keeps_comments(tmp_path):
    p = tmp_path / "c.yaml"
    p.write_text("# house\ncap_minutes: 6   # default\nvideo:\n  fps: 30\n")
    set_yaml_key(p, "cap_minutes", 8)
    set_yaml_key(p, "video.fps", 25)
    set_yaml_key(p, "video.width", 1920)
    text = p.read_text()
    assert "# house" in text and "cap_minutes: 8   # default" in text
    assert "  fps: 25" in text and "  width: 1920" in text


def test_align_times_each_word_of_a_term_read_as_written():
    text = "Is it supported by the retrieved context?"
    words = ["Is", "it", "supported", "by", "the", "retrieved", "context"]
    reps = [{"start": 23, "end": 40, "original": "retrieved context", "rendered": "retrieved context",
             "expect": ["retrieved", "context"]}]
    tokens = [{"text": w, "start": i * 0.3, "end": i * 0.3 + 0.25} for i, w in enumerate(words + ["?"])]
    out = align(text, words, reps, tokens)
    assert out[6]["start"] == pytest.approx(1.8)  # "context" keeps its own time, not "retrieved"'s
    assert not out[6]["fallback"]
