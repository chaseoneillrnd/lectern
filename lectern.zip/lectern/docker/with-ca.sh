#!/bin/sh
# Run one build step trusting an optional proxy CA passed as a BuildKit secret (id=proxy_ca).
# The merged bundle exists only in /tmp for the length of the step, so no image layer keeps it.
if [ -s /run/secrets/proxy_ca ]; then
  bundle=/tmp/with-ca-bundle.pem
  cat /etc/ssl/certs/ca-certificates.crt /run/secrets/proxy_ca > "$bundle" 2>/dev/null || cp /run/secrets/proxy_ca "$bundle"
  export SSL_CERT_FILE="$bundle" CURL_CA_BUNDLE="$bundle" REQUESTS_CA_BUNDLE="$bundle" PIP_CERT="$bundle" \
         NODE_EXTRA_CA_CERTS="$bundle" npm_config_cafile="$bundle" HF_HUB_DISABLE_XET=1
  "$@"; rc=$?
  rm -f "$bundle"
  exit $rc
fi
exec "$@"
