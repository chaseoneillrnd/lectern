#!/bin/sh
# Point HyperFrames at the arm64 headless shell when the image carries one, then run the CLI.
if [ -s /opt/lectern/.browser_path ] && [ -z "$HYPERFRAMES_BROWSER_PATH" ]; then
  HYPERFRAMES_BROWSER_PATH="$(cat /opt/lectern/.browser_path)"
  export HYPERFRAMES_BROWSER_PATH
fi
exec lectern "$@"
