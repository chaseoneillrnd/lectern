"""Pinned sources, cached locally so claim checks run offline, and stack checkouts that captures run in."""
from __future__ import annotations

import os
import re
import subprocess
from functools import lru_cache
from pathlib import Path

from .config import CourseManifest
from .paths import CoursePaths, LecternError


def sources_root() -> Path:
    return Path(os.environ.get("LECTERN_SOURCES", Path.home() / ".lectern" / "sources"))


def is_remote(repo: str) -> bool:
    return "://" in repo or repo.startswith("git@")


def resolve_repo(repo: str, course_root: Path | None) -> str:
    """A repo is a URL or a path. A relative path is relative to the course root, so a sibling stack repo works."""
    if is_remote(repo) or Path(repo).is_absolute() or course_root is None:
        return repo
    return str((course_root / repo).resolve())


def slug(repo: str) -> str:
    repo = re.sub(r"^(\.\.?/)+", "", repo)
    return re.sub(r"[^A-Za-z0-9._-]+", "-", repo.removesuffix(".git").split("://")[-1]).strip("-")


def repo_name(repo: str) -> str:
    """The folder `git clone` would create: the last path segment without .git."""
    return re.split(r"[/:]", repo.rstrip("/").removesuffix(".git"))[-1]


def source_dir(repo: str, ref: str) -> Path:
    return sources_root() / f"{slug(repo)}@{ref}"


def git(*args, cwd: Path | None = None) -> str:
    p = subprocess.run(["git", *args], cwd=cwd, capture_output=True, text=True)
    if p.returncode != 0:
        raise LecternError(f"git {' '.join(args)} failed: {p.stderr.strip()[-400:]}")
    return p.stdout.strip()


def fetch(repo: str, ref: str, commit: str | None, course_root: Path | None = None) -> Path:
    dest = source_dir(repo, ref)
    url = resolve_repo(repo, course_root)
    if not (dest / ".git").exists():
        dest.parent.mkdir(parents=True, exist_ok=True)
        git("-c", "advice.detachedHead=false", "clone", "-q", "--depth", "1", "--branch", ref, url, str(dest))
    head = git("rev-parse", "HEAD", cwd=dest)
    if commit and head != commit:
        # The pin moved, for example a branch ref with a newer commit. Check out exactly the pinned commit.
        try:
            git("fetch", "-q", "--depth", "1", "origin", commit, cwd=dest)
            git("-c", "advice.detachedHead=false", "checkout", "-q", commit, cwd=dest)
        except LecternError as e:
            raise LecternError(f"{repo}@{ref} is at {head[:12]} and the course pins {commit[:12]}, which could not be "
                               f"fetched: {e}") from None
        head_of.cache_clear()
    return dest


@lru_cache(maxsize=32)
def head_of(root: Path) -> str:
    return git("rev-parse", "HEAD", cwd=root)


def fetch_all(paths: CoursePaths, course: CourseManifest) -> dict[str, Path]:
    return {name: fetch(pin.repo, pin.ref, pin.commit, paths.root) for name, pin in course.sources.items()}


def read_source(course: CourseManifest, name: str, path: str) -> str:
    if name not in course.sources:
        raise LecternError(f"source `{name}` is not declared in course.yaml sources")
    pin = course.sources[name]
    root = source_dir(pin.repo, pin.ref)
    if not root.exists():
        raise LecternError(f"source `{name}` is not cached. Run `lectern sources`")
    if pin.commit and head_of(root) != pin.commit:
        raise LecternError(f"the cached {name}@{pin.ref} is at {head_of(root)[:12]}, not the pinned {pin.commit[:12]}. "
                           "Run `lectern sources`")
    f = root / path
    if not f.is_file():
        raise LecternError(f"{name}@{pin.ref} has no file {path}")
    return f.read_text(encoding="utf-8")


def web_url(course: CourseManifest, name: str, path: str) -> str | None:
    """A link to the file at the pinned ref, or None when the source has no browsable home."""
    pin = course.sources[name]
    base = (pin.web or (pin.repo if is_remote(pin.repo) else "")).removesuffix(".git")
    if base.startswith("git@"):
        host, _, rest = base[4:].partition(":")
        base = f"https://{host}/{rest}"
    if not base:
        return None
    if "github.com" in base:
        return f"{base}/blob/{pin.ref}/{path}"
    if "gitlab" in base:
        return f"{base}/-/blob/{pin.ref}/{path}"
    return f"{base}@{pin.ref}:{path}"


def where(course: CourseManifest, name: str, path: str) -> str:
    return f"{name}@{course.sources[name].ref}:{path}"


# ----------------------------------------------------------------------------- stack checkouts


def stack_checkout(paths: CoursePaths, course: CourseManifest, name: str, fresh: bool = False, log=print) -> tuple[Path, dict]:
    """A working checkout of a pinned source for captures to run in, under .lectern/stacks/<repo name>.

    fresh: reset to the pinned commit and delete every untracked and ignored file, like a new clone. Otherwise the
    checkout keeps what earlier captures left (an env file, downloaded models), and must still sit on the pinned commit
    with no tracked file changed.
    """
    if name not in course.sources:
        raise LecternError(f"capture runs against stack `{name}`, which course.yaml does not declare under sources")
    pin = course.sources[name]
    if not pin.commit:
        raise LecternError(f"source `{name}` has no pinned commit. Run `lectern sources` or pin it in course.yaml")
    dest = paths.state / "stacks" / repo_name(pin.repo)
    url = resolve_repo(pin.repo, paths.root)
    if not (dest / ".git").exists():
        dest.parent.mkdir(parents=True, exist_ok=True)
        log(f"stack: cloning {pin.repo} at {pin.ref} into {dest.relative_to(paths.root)}")
        git("-c", "advice.detachedHead=false", "clone", "-q", "--branch", pin.ref, url, str(dest))
        fresh = True
    if fresh:
        try:
            git("cat-file", "-e", f"{pin.commit}^{{commit}}", cwd=dest)
        except LecternError:
            git("fetch", "-q", "origin", pin.commit, cwd=dest)
        git("-c", "advice.detachedHead=false", "checkout", "-q", "-f", "--detach", pin.commit, cwd=dest)
        git("clean", "-q", "-xdff", cwd=dest)
        log(f"stack: fresh checkout of {name} at {pin.ref} ({pin.commit[:12]})")
    head = git("rev-parse", "HEAD", cwd=dest)
    if head != pin.commit:
        raise LecternError(f"the {name} checkout is at {head[:12]} and the course pins {pin.commit[:12]}. "
                           "Run a capture with `fresh: true` to reset it")
    changed = git("status", "--porcelain", "--untracked-files=no", cwd=dest)
    if changed:
        raise LecternError(f"tracked files changed in the {name} checkout, so a capture would not show the pinned "
                           f"commit:\n{changed}\nRun a capture with `fresh: true` to reset it")
    return dest, {"source": name, "repo": pin.repo, "ref": pin.ref, "commit": head, "folder": dest.name}


def repin(paths: CoursePaths, course: CourseManifest, name: str) -> tuple[str | None, str]:
    """Point a source's pin at the commit its ref resolves to now, editing course.yaml in place. Returns (old, new)."""
    from .scaffold import resolve_commit

    if name not in course.sources:
        raise LecternError(f"course.yaml has no source `{name}`")
    pin = course.sources[name]
    new = resolve_commit(resolve_repo(pin.repo, paths.root), pin.ref)
    if not new:
        raise LecternError(f"could not resolve {name}@{pin.ref}. Is {pin.repo} reachable?")
    f = paths.root / "course.yaml"
    lines = f.read_text(encoding="utf-8").splitlines()
    in_sources, start = False, None
    for i, line in enumerate(lines):
        if re.match(r"^sources:\s*(#.*)?$", line):
            in_sources = True
        elif in_sources and re.match(r"^\S", line):
            break
        elif in_sources and re.match(rf"^  {re.escape(name)}:\s*(#.*)?$", line):
            start = i
            break
    if start is None:
        raise LecternError(f"could not find sources.{name} in course.yaml. Edit its commit by hand")
    end = start + 1
    while end < len(lines) and (lines[end].startswith("    ") or not lines[end].strip()):
        end += 1
    for i in range(start + 1, end):
        m = re.match(r"^(    commit:\s*)(\S+)(.*)$", lines[i])
        if m:
            lines[i] = f"{m.group(1)}{new}{m.group(3)}"
            break
    else:
        ref_line = next(i for i in range(start + 1, end) if lines[i].lstrip().startswith("ref:"))
        lines.insert(ref_line + 1, f"    commit: {new}")
    f.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return pin.commit, new
