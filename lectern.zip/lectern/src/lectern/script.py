"""Parse one lesson script: front matter, scenes, narration sentences, cues, claim tags and checkpoints.

Script syntax (see the spec, Data model > Lesson script):

    ## <scene-id>  layout=<template>  key=value ...
    Prose is narration. [span]{verb=target} fires a cue when the span's first word starts.
    A bare {verb} targets the thing the span names. ^claim-id ends a technical sentence.
    > ask: A checkpoint question, spoken by the Examiner.
    > answer: The answer, spoken by the Narrator after a countdown. ^claim-id
"""
from __future__ import annotations

import re
import shlex
from dataclasses import asdict, dataclass, field
from pathlib import Path

import yaml

from .paths import LecternError

TOKEN_RE = re.compile(
    r"\[(?P<span>[^\]\n]+)\]\{(?P<attrs>[^}\n]*)\}"
    r"|(?P<claim>[ \t]*\^(?P<cid>[A-Za-z0-9~][\w.~-]*))"
)
WORD_RE = re.compile(r"[A-Za-z0-9](?:[A-Za-z0-9'’._%-]*[A-Za-z0-9%])?")
SENT_END_RE = re.compile(r"[.!?]+[\"'’”)\]]*(?=\s|$)")
SCENE_RE = re.compile(r"^##\s+(?P<rest>\S.*)$")
COMMENT_RE = re.compile(r"<!--.*?-->", re.S)
NO_CLAIM = "nc"  # ^nc marks a technical-looking sentence the author asserts makes no claim; gate one shows them


@dataclass
class Cue:
    verb: str
    target: str | None
    params: dict
    span: str
    word_index: int          # index of the span's first word within its sentence
    line: int


@dataclass
class Sentence:
    id: str
    text: str                # what the voice says, markup removed
    words: list[str]
    claims: list[str]
    cues: list[Cue]
    voice: str               # narrator | examiner
    kind: str                # narration | ask | answer
    paragraph_end: bool
    line: int
    shown: str | None = None  # what the screen and page show, when [0.7]{say="zero point seven"} makes it differ


@dataclass
class Scene:
    id: str
    layout: str
    params: dict
    sentences: list[Sentence]
    line: int


@dataclass
class Lesson:
    path: str
    front: dict
    scenes: list[Scene] = field(default_factory=list)

    @property
    def id(self) -> str:
        return self.front["id"]

    def to_dict(self) -> dict:
        return asdict(self)

    def sentences(self):
        for scene in self.scenes:
            yield from ((scene, s) for s in scene.sentences)


def words_of(text: str) -> list[str]:
    return WORD_RE.findall(text)


def parse_attrs(attrs: str, verbs: set[str], line: int) -> list[tuple[str, str | None, dict]]:
    """`light`, `light=answer`, `callout=answer text="Two words"`, `light pulse` -> [(verb, target, params)]."""
    try:
        tokens = shlex.split(attrs)
    except ValueError as e:
        raise LecternError(f"line {line}: cannot parse cue attributes {{{attrs}}}: {e}") from None
    out: list[tuple[str, str | None, dict]] = []
    for tok in tokens:
        key, eq, val = tok.partition("=")
        if key in verbs:
            out.append((key, val if eq else None, {}))
        elif eq and out:
            out[-1][2][key] = val
        else:
            # Unknown verbs still parse so the compiler can report them with context.
            out.append((key, val if eq else None, {}))
    if not out:
        raise LecternError(f"line {line}: empty cue {{}}")
    return out


def say_text(attrs: str, line: int) -> str | None:
    """The spoken form in `[0.7]{say="zero point seven"}`, or None when the braces hold cues instead."""
    try:
        tokens = shlex.split(attrs)
    except ValueError:
        return None  # parse_attrs reports it
    if not any(tok.partition("=")[0] == "say" for tok in tokens):
        return None
    if len(tokens) != 1 or not tokens[0].startswith("say="):
        raise LecternError(f"line {line}: `say` stands alone in its braces, as in [0.7]{{say=\"zero point seven\"}}")
    spoken = tokens[0][len("say="):].strip()
    if not spoken:
        raise LecternError(f"line {line}: `say` needs the words the voice speaks")
    return spoken


def split_sentences(text: str, forced_ends: list[int]) -> list[tuple[int, int]]:
    """Sentence spans in `text`. A claim tag position always ends a sentence."""
    ends = set()
    for m in SENT_END_RE.finditer(text):
        nxt = text[m.end():].lstrip()
        if not nxt or nxt[0].isupper() or nxt[0].isdigit() or nxt[0] in "\"'“[(":
            ends.add(m.end())
    ends.update(e for e in forced_ends if 0 < e <= len(text))
    spans, start = [], 0
    for end in sorted(ends):
        if end <= start:
            continue
        chunk = text[start:end]
        if chunk.strip():
            lead = len(chunk) - len(chunk.lstrip())
            spans.append((start + lead, end))
        start = end
    tail = text[start:]
    if tail.strip():
        lead = len(tail) - len(tail.lstrip())
        spans.append((start + lead, len(text.rstrip())))
    return spans


def parse_paragraph(raw: str, scene_id: str, counter: list[int], line: int, voice: str, kind: str,
                    verbs: set[str]) -> list[Sentence]:
    # Collapse runs of spaces first, so every recorded cue and claim offset matches the final text.
    raw = re.sub(r"[ \t]+", " ", raw)
    # `out` is what the voice says, and every offset counts in it. `shown` is what the screen and page show: the same,
    # except where [0.7]{say="zero point seven"} gives the voice other words. `says` maps the two around each one.
    out, shown, cues, claims, says, pos = "", "", [], [], [], 0
    for m in TOKEN_RE.finditer(raw):
        out += raw[pos:m.start()]
        shown += raw[pos:m.start()]
        if m.group("span") is not None:
            spoken = say_text(m.group("attrs"), line)
            if spoken is not None:
                says.append((len(out), len(out) + len(spoken), len(shown), len(shown) + len(m.group("span"))))
                out += spoken
                shown += m.group("span")
                pos = m.end()
                continue
            cues.append((len(out), m.group("span"), m.group("attrs")))
            out += m.group("span")
            shown += m.group("span")
        else:
            claims.append((len(out), m.group("cid")))
        pos = m.end()
    out += raw[pos:]
    shown += raw[pos:]

    def shown_at(i: int) -> int:
        shift = 0
        for s0, s1, d0, d1 in says:
            if s0 < i < s1:
                raise LecternError(f"line {line}: a sentence ends inside [{shown[d0:d1]}]{{say=...}}")
            if i >= s1:
                shift = d1 - s1
        return i + shift

    spans = split_sentences(out, [c[0] for c in claims])
    sentences: list[Sentence] = []
    for start, end in spans:
        text = out[start:end].strip()
        on_screen = shown[shown_at(start):shown_at(end)].strip() if says else text
        counter[0] += 1
        sentences.append(Sentence(id=f"{scene_id}.s{counter[0]}", text=text, words=words_of(text), claims=[],
                                  cues=[], voice=voice, kind=kind, paragraph_end=False, line=line,
                                  shown=on_screen if on_screen != text else None))
    if not sentences:
        return []
    sentences[-1].paragraph_end = True

    for offset, cid in claims:
        idx = max((i for i, (s, e) in enumerate(spans) if e <= offset), default=None)
        if idx is None:
            raise LecternError(f"line {line}: claim tag ^{cid} must follow the sentence it supports")
        sentences[idx].claims.append(cid)

    for offset, span, attrs in cues:
        idx = next((i for i, (s, e) in enumerate(spans) if s <= offset < e), None)
        if idx is None:
            raise LecternError(f"line {line}: cue [{span}] sits outside any sentence")
        s_start = spans[idx][0]
        word_index = len(words_of(out[s_start:offset]))
        for verb, target, params in parse_attrs(attrs, verbs, line):
            sentences[idx].cues.append(Cue(verb=verb, target=target, params=params, span=span,
                                           word_index=word_index, line=line))
    return sentences


def parse_scene_header(rest: str, line: int) -> tuple[str, str, dict]:
    try:
        tokens = shlex.split(rest)
    except ValueError as e:
        raise LecternError(f"line {line}: cannot parse scene header: {e}") from None
    scene_id, params = tokens[0], {}
    for tok in tokens[1:]:
        key, eq, val = tok.partition("=")
        if not eq:
            raise LecternError(f"line {line}: scene parameter `{tok}` needs key=value")
        params[key] = val
    if not re.fullmatch(r"[a-z0-9][a-z0-9-]*", scene_id):
        raise LecternError(f"line {line}: scene id `{scene_id}` must be lowercase letters, digits and dashes")
    layout = params.pop("layout", None)
    if not layout:
        raise LecternError(f"line {line}: scene `{scene_id}` needs layout=<template>")
    return scene_id, layout, params


# Front matter runs from a first line of `---` to the next line that is exactly `---`, so a rule inside a value, such
# as the dashes a command printed into a claim's excerpt, never ends it.
FRONT_END = re.compile(r"^---[ \t]*$", re.M)


def front_matter(text: str) -> tuple[str, str] | None:
    """The front matter's text and the body after it, or None when the text opens with none or never closes it."""
    if not text.startswith("---\n"):
        return None
    end = FRONT_END.search(text, 4)
    return (text[4:end.start()], text[end.end():]) if end else None


def parse_lesson(path: Path, verbs: set[str]) -> Lesson:
    text = path.read_text(encoding="utf-8")
    front: dict = {}
    body_start = 1  # line number of the first body line
    if text.startswith("---\n"):
        end = FRONT_END.search(text, 4)
        if end is None:
            raise LecternError(f"{path}: front matter is not closed with ---")
        front = yaml.safe_load(text[4:end.start()]) or {}
        body_start = text[:end.end()].count("\n") + 1
        text = text[end.end():]
    if "id" not in front:
        raise LecternError(f"{path}: front matter needs id")
    lesson = Lesson(path=str(path), front=front)

    # Blank out comments but keep line numbers stable.
    text = COMMENT_RE.sub(lambda m: "\n" * m.group(0).count("\n"), text)
    lines = text.split("\n")
    scene: Scene | None = None
    counter = [0]
    para: list[str] = []
    para_line = 0
    quote: list[tuple[str, str, int]] = []  # (role, text, line)

    def flush_para():
        nonlocal para
        if para and scene is not None:
            scene.sentences += parse_paragraph(" ".join(para), scene.id, counter, para_line, "narrator",
                                               "narration", verbs)
        elif para:
            raise LecternError(f"{path}:{para_line}: narration before the first ## scene heading")
        para = []

    def flush_quote():
        nonlocal quote
        if not quote:
            return
        if scene is None:
            raise LecternError(f"{path}:{quote[0][2]}: checkpoint before the first ## scene heading")
        groups: list[list] = []
        for role, chunk, ln in quote:
            if role or not groups:
                groups.append([role or "ask", [chunk], ln])
            else:
                groups[-1][1].append(chunk)
        for role, chunks, ln in groups:
            voice = "examiner" if role == "ask" else "narrator"
            scene.sentences += parse_paragraph(" ".join(chunks), scene.id, counter, ln, voice, role, verbs)
        quote = []

    for i, raw_line in enumerate(lines):
        line_no = body_start + i
        stripped = raw_line.strip()
        m = SCENE_RE.match(stripped)
        if m:
            flush_para()
            flush_quote()
            sid, layout, params = parse_scene_header(m.group("rest"), line_no)
            if any(s.id == sid for s in lesson.scenes):
                raise LecternError(f"{path}:{line_no}: duplicate scene id `{sid}`")
            scene = Scene(id=sid, layout=layout, params=params, sentences=[], line=line_no)
            counter = [0]
            lesson.scenes.append(scene)
            continue
        if stripped.startswith(">"):
            flush_para()
            content = stripped[1:].strip()
            qm = re.match(r"(ask|answer):\s*(.*)$", content, re.I)
            if qm:
                quote.append((qm.group(1).lower(), qm.group(2), line_no))
            elif content:
                quote.append(("", content, line_no))
            continue
        if not stripped:
            flush_para()
            flush_quote()
            continue
        if stripped.startswith("#"):
            raise LecternError(f"{path}:{line_no}: only `## scene` headings are allowed in a script")
        flush_quote()
        if not para:
            para_line = line_no
        para.append(stripped)
    flush_para()
    flush_quote()

    _split_checkpoints(lesson)
    return lesson


def _split_checkpoints(lesson: Lesson) -> None:
    """A checkpoint inside a non-checkpoint scene becomes its own checkpoint scene right after it."""
    out: list[Scene] = []
    for scene in lesson.scenes:
        if scene.layout == "checkpoint":
            out.append(scene)
            continue
        main = [s for s in scene.sentences if s.kind == "narration"]
        check = [s for s in scene.sentences if s.kind != "narration"]
        scene.sentences = main
        out.append(scene)
        if check:
            cid = f"{scene.id}-checkpoint"
            for n, s in enumerate(check, 1):
                s.id = f"{cid}.s{n}"
            out.append(Scene(id=cid, layout="checkpoint", params={}, sentences=check, line=check[0].line))
    lesson.scenes = out
