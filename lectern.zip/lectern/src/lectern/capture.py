"""capture: run real commands in a pseudo-terminal and write an asciicast v2 file plus meta.json.

Typing is presentation, output is always real. Idle gaps compress to `idle_limit`. Captures run only when asked,
and their outputs become pinned inputs to every later build.

capture/<id>.yaml with `kind: terminal`:

    stack: stack                 # optional: run in a checkout of this pinned source, not the course repo
    fresh: true                  # with stack: start from a clean checkout, like a new clone
    env_pass: [PROXY_CA]         # variables taken from your shell when set. meta.json keeps their names, never values
    before: [tilt down]          # hidden setup, recorded in meta.json, never typed on screen
    steps:
      - id: env
        run: cp .env.example .env
      - id: up
        run: tilt up
        until: "(ctrl-c) to exit"  # for a command that waits forever: stop it once this text prints
    after: []                    # hidden cleanup, run even when a step fails
    stack_paths: [Tiltfile]      # stack files this capture shows or depends on. `lectern stale` watches them

With stack, output that prints the checkout's absolute path shows it as ~/<repo folder> instead, the way a teammate's
clone would read. `show_workdir_as` changes that, and meta.json records it.
"""
from __future__ import annotations

import codecs
import datetime as dt
import fcntl
import hashlib
import json
import os
import pty
import random
import re
import select
import shutil
import signal
import struct
import subprocess
import termios
import time
from pathlib import Path

from .config import load_yaml
from .paths import CoursePaths, LecternError

PROMPT = "\x1b[38;2;76;194;255m$\x1b[0m "
CONTINUE = "\x1b[38;2;76;194;255m>\x1b[0m "  # the prompt bash shows on a line a backslash carried on
ANSI = re.compile(r"\x1b\[[0-9;?]*[ -/]*[@-~]|\x1b\][^\x07]*\x07")
# Passed through from the caller's environment when set, so captures work behind proxies and on remote Docker hosts.
# Only the names are recorded.
DEFAULT_PASS = ("USER", "LOGNAME", "SHELL", "TMPDIR", "DOCKER_HOST", "DOCKER_CONFIG", "DOCKER_CONTEXT", "KUBECONFIG",
                "HTTP_PROXY", "HTTPS_PROXY", "NO_PROXY", "http_proxy", "https_proxy", "no_proxy",
                "SSL_CERT_FILE", "SSL_CERT_DIR", "REQUESTS_CA_BUNDLE", "PIP_CERT", "NODE_EXTRA_CA_CERTS")


def strip_ansi(text: str) -> str:
    return ANSI.sub("", text)


def wide_commands(spec: dict, cols: int) -> list[str]:
    """Steps whose typed lines run past the terminal's width, where the screen would wrap them mid-word."""
    out = []
    for i, step in enumerate(spec.get("steps") or [], 1):
        sid = str(step.get("id") or f"step{i}")
        for line in str(step["run"]).split("\n"):
            width = len(strip_ansi(PROMPT)) + len(line)
            if width > cols:
                out.append(f"step {sid} types {width} characters on a {cols}-column terminal, so the screen wraps "
                           "it mid-word. Shorten it, or carry it onto a second line with a backslash")
                break
    return out


def type_command(events: list, cmd: str, t: float, cps: float, rng: random.Random) -> float:
    """Type a command the way a person would. A backslash-newline goes on under bash's continuation prompt."""
    for ch in cmd:
        events.append([round(t, 4), "\r\n" + CONTINUE if ch == "\n" else ch])
        t += (1 / cps) * rng.uniform(0.7, 1.3)
    return t


def capture_env(paths: CoursePaths, spec: dict, cols: int | None = None, rows: int | None = None) -> tuple[dict, list[str]]:
    """A small, explicit environment: nothing from your shell leaks into a capture unless it is named."""
    env = {"PATH": os.environ.get("PATH", ""), "HOME": os.environ.get("HOME", "/root"), "TERM": "xterm-256color",
           "LANG": "C.UTF-8", "PYTHONUNBUFFERED": "1"}
    if cols and rows:
        env.update({"COLUMNS": str(cols), "LINES": str(rows)})
    passed = []
    for name in (*DEFAULT_PASS, *(spec.get("env_pass") or [])):
        if name in os.environ and name not in env:
            env[name] = os.environ[name]
            passed.append(name)
    for p in reversed(spec.get("path_prepend", [])):
        env["PATH"] = f"{(paths.root / p).resolve()}:{env['PATH']}"
    env.update({k: str(v) for k, v in (spec.get("env") or {}).items()})
    return env, sorted(set(passed))


def workdir(paths: CoursePaths, spec: dict, course=None, log=print) -> tuple[Path, dict | None]:
    """Where a capture's commands run: the course repo, or a checkout of a pinned stack."""
    if not spec.get("stack"):
        return paths.root, None
    from .config import load_course
    from .sources import stack_checkout

    course = course or load_course(paths.root)
    cwd, stack = stack_checkout(paths, course, spec["stack"], bool(spec.get("fresh")), log)
    stack["paths"] = list(spec.get("stack_paths") or [])
    return cwd, stack


def run_hooks(commands: list[str], cwd: Path, env: dict, log, what: str, strict: bool = True) -> list[dict]:
    out = []
    for cmd in commands or []:
        log(f"{what}: `{cmd}`")
        p = subprocess.run(cmd, shell=True, cwd=cwd, env=env, capture_output=True, text=True, timeout=1800)
        out.append({"run": cmd, "exit": p.returncode})
        if p.returncode != 0 and strict:
            raise LecternError(f"{what} `{cmd}` exited {p.returncode}:\n{(p.stdout + p.stderr)[-1500:]}")
    return out


def _kill_group(pid: int, fd: int) -> None:
    """SIGINT the step's process group the way Ctrl-C would, then SIGKILL whatever is left."""
    for sig, wait in ((signal.SIGINT, 15.0), (signal.SIGTERM, 5.0), (signal.SIGKILL, 5.0)):
        try:
            os.killpg(pid, sig)
        except ProcessLookupError:
            return
        t0 = time.monotonic()
        while time.monotonic() - t0 < wait:
            ready, _, _ = select.select([fd], [], [], 0.1)
            if fd in ready:
                try:
                    if not os.read(fd, 65536):
                        pass
                except OSError:
                    pass
            done, _ = os.waitpid(pid, os.WNOHANG)
            if done:
                return


def _run_in_pty(command: str, cwd: Path, env: dict, cols: int, rows: int, timeout: float,
                until: str | None = None, settle: float = 0.4) -> tuple[list, int, bool]:
    """Run one command. Returns its output events, its exit code, and whether `until` stopped it."""
    pid, fd = pty.fork()
    if pid == 0:  # child: pty.fork made it a session leader, so its process group is its pid
        try:
            fcntl.ioctl(0, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))
            os.chdir(cwd)
            os.execvpe("bash", ["bash", "--noprofile", "--norc", "-c", command], env)
        finally:
            os._exit(127)
    decoder = codecs.getincrementaldecoder("utf-8")("replace")
    events, t0, status, eof = [], time.monotonic(), None, False
    seen, matched_at = "", None
    while True:
        now = time.monotonic() - t0
        if matched_at is not None and now - matched_at >= settle:
            _kill_group(pid, fd)
            os.close(fd)
            return [e for e in events if e[0] <= matched_at + settle], 0, True
        if now > timeout:
            _kill_group(pid, fd)
            os.close(fd)
            tail = strip_ansi("".join(e[1] for e in events))[-1500:]
            what = f"waiting for {until!r}" if until else "running"
            raise LecternError(f"capture timed out after {timeout:.0f} s {what}: {command}\n{tail}")
        ready, _, _ = select.select([fd], [], [], 0.1)
        if fd in ready:
            try:
                data = os.read(fd, 65536)
            except OSError:  # EIO once the child side closes
                data = b""
            if data:
                text = decoder.decode(data)
                if text:
                    events.append([time.monotonic() - t0, text])
                    if until and matched_at is None:
                        seen = (seen + strip_ansi(text))[-20000:]
                        if until in seen:
                            matched_at = events[-1][0]
                continue
            eof = True
        if status is None:
            wpid, st = os.waitpid(pid, 0 if eof else os.WNOHANG)
            if wpid:
                status = st
        if status is not None and (eof or fd not in ready):
            break
    os.close(fd)
    if until:
        tail = strip_ansi("".join(e[1] for e in events))[-1500:]
        raise LecternError(f"`{command}` exited before printing {until!r}:\n{tail}")
    return events, os.waitstatus_to_exitcode(status), False


def _compress(events: list, idle_limit: float, start: float) -> tuple[list, float]:
    out, last_raw, t = [], 0.0, start
    for raw_t, text in events:
        t += min(raw_t - last_raw, idle_limit)
        last_raw = raw_t
        out.append([round(t, 4), text])
    return out, t


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


CD = re.compile(r"^cd\s+(\S+)\s*$")


def run_capture(paths: CoursePaths, capture_id: str, log=print, tokens: dict | None = None, course=None) -> Path:
    spec_path = paths.capture_scripts / f"{capture_id}.yaml"
    spec = load_yaml(spec_path)
    if spec.get("kind") == "browser":
        from .browser import run_browser_capture
        from .config import House

        return run_browser_capture(paths, capture_id, spec, tokens or House().tokens, log, course)
    if spec.get("kind") != "terminal":
        raise LecternError(f"{spec_path}: kind is terminal or browser")
    cols, rows = int(spec.get("cols", 84)), int(spec.get("rows", 12))
    idle_limit, cps = float(spec.get("idle_limit", 1.2)), float(spec.get("typing_cps", 22))
    for warning in wide_commands(spec, cols):
        log(f"capture {capture_id}: warning: {warning}")
    env, passed = capture_env(paths, spec, cols, rows)
    root, stack = workdir(paths, spec, course, log)
    rng = random.Random(capture_id)  # typing rhythm is presentation, so make it repeatable

    hooks = {"before": run_hooks(spec.get("before"), root, env, log, f"capture {capture_id}: before")}
    events: list = []
    marks: list[dict] = []
    t = 0.4
    raw_seconds, exit_codes, stopped = 0.0, [], {}
    cwd = root
    try:
        for i, step in enumerate(spec["steps"], 1):
            cmd, sid = step["run"], str(step.get("id") or f"step{i}")
            if sid in {m["id"] for m in marks}:
                raise LecternError(f"capture {capture_id}: step id {sid} is used twice")
            mark = {"id": sid, "prompt": round(t, 4)}
            events.append([round(t, 4), PROMPT])
            t += 0.6
            mark["start"] = round(t, 4)
            t = type_command(events, cmd, t, cps, rng)
            t += 0.35
            events.append([round(t, 4), "\r\n"])
            mark["typed"] = round(t, 4)
            if m := CD.match(cmd):
                # cd changes the shell's folder for the steps after it, as it would in a real terminal.
                target = (cwd / m.group(1)).resolve()
                if not target.is_dir():
                    raise LecternError(f"capture {capture_id}: `{cmd}` names no folder")
                cwd = target
                exit_codes.append(0)
                t += 0.15
            else:
                log(f"capture {capture_id}: running `{cmd}`")
                out, code, was_stopped = _run_in_pty(cmd, cwd, env, cols, rows, float(step.get("timeout", 1800)),
                                                     step.get("until"), float(step.get("settle", 0.4)))
                raw_seconds += out[-1][0] if out else 0.0
                exit_codes.append(code)
                if was_stopped:
                    stopped[sid] = step["until"]
                if code != 0:
                    text = "".join(e[1] for e in out)
                    raise LecternError(f"capture {capture_id}: `{cmd}` exited {code}. Output:\n{text[-2000:]}")
                compressed, t = _compress(out, idle_limit, t)
                events += compressed
            mark["end"] = round(t, 4)
            marks.append(mark)
            t += 0.5
            if sid in stopped and i < len(spec["steps"]):
                raise LecternError(f"capture {capture_id}: step {sid} uses until, so it must be the last step")
    finally:
        hooks["after"] = run_hooks(spec.get("after"), root, env, log, f"capture {capture_id}: after", strict=False)
    if not stopped:
        events.append([round(t, 4), PROMPT])  # a stopped command still owns the terminal, so no prompt returns

    paths.captures.mkdir(parents=True, exist_ok=True)
    cast_path = paths.captures / f"{capture_id}.cast"
    title = stack["folder"] if stack else paths.root.name
    if stack:
        # The checkout's location is a Lectern detail. Show it where a teammate's clone would be, and record that.
        shown_as = str(spec.get("show_workdir_as", f"~/{stack['folder']}"))
        stack["shown_as"] = {str(root): shown_as}
        events = [[t_, text.replace(str(root), shown_as)] for t_, text in events]
    header = {"version": 2, "width": cols, "height": rows, "title": title,
              "env": {"TERM": "xterm-256color", "SHELL": "/bin/bash"}}
    with open(cast_path, "w", encoding="utf-8") as fh:
        fh.write(json.dumps(header) + "\n")
        for t_, text in events:
            fh.write(json.dumps([t_, "o", text], ensure_ascii=False) + "\n")

    meta_dir = paths.captures / capture_id
    meta_dir.mkdir(exist_ok=True)
    shows = {f: sha256(paths.root / f) for f in spec.get("shows", [])}
    redaction = scan_secrets([cast_path])
    meta = {
        "id": capture_id,
        "kind": "terminal",
        "recorded": dt.date.today().isoformat(),
        "commands": [s["run"] for s in spec["steps"]],
        "exit_codes": exit_codes,
        "marks": marks,
        "stopped": stopped,
        "seconds": {"raw": round(raw_seconds, 1), "in_cast": round(t, 1)},
        "env": {k: v for k, v in (spec.get("env") or {}).items()},
        "env_passed": passed,
        "hooks": hooks,
        "shows": shows,
        "stack": stack,
        "lock": _lockfile_hash(paths),
        "requires": spec.get("requires"),
        "redaction": redaction,
    }
    (meta_dir / "meta.json").write_text(json.dumps(meta, indent=1, ensure_ascii=False))
    if redaction["findings"]:
        raise LecternError(f"capture {capture_id}: gitleaks found {redaction['findings']} secret(s). The cast stays on disk "
                           f"for inspection but every build that uses it is blocked")
    log(f"capture {capture_id}: wrote {cast_path.relative_to(paths.root)} ({t:.1f} s, raw run {raw_seconds:.0f} s)")
    return cast_path


def load_meta(paths: CoursePaths, capture_id: str) -> dict:
    p = paths.captures / capture_id / "meta.json"
    return json.loads(p.read_text()) if p.exists() else {}


def _lockfile_hash(paths: CoursePaths) -> dict:
    out = {}
    for p in sorted(paths.root.glob("examples/requirements*.txt")):
        out[str(p.relative_to(paths.root))] = sha256(p)
    return out


def gitleaks_bin() -> str | None:
    return os.environ.get("LECTERN_GITLEAKS") or shutil.which("gitleaks")


def scan_secrets(files: list[Path]) -> dict:
    """Run gitleaks over the given files. A finding blocks the build."""
    exe = gitleaks_bin()
    if not exe:
        return {"tool": None, "findings": 0, "note": "gitleaks not installed, scan skipped"}
    version = subprocess.run([exe, "version"], capture_output=True, text=True).stdout.strip()
    findings = 0
    details = []
    for f in files:
        report = f.with_suffix(f.suffix + ".gitleaks.json")
        p = subprocess.run([exe, "dir", str(f), "--no-banner", "--report-format", "json", "--report-path", str(report),
                            "--exit-code", "3"], capture_output=True, text=True)
        if p.returncode not in (0, 3):
            raise LecternError(f"gitleaks failed on {f}: {p.stderr[-500:]}")
        if report.exists():
            items = json.loads(report.read_text() or "[]")
            findings += len(items)
            details += [{"file": str(f.name), "rule": i.get("RuleID"), "line": i.get("StartLine")} for i in items]
            report.unlink()
    return {"tool": f"gitleaks {version}", "findings": findings, "details": details}


def cast_text(path: Path) -> str:
    """Everything the cast printed, ANSI escapes removed. Run claims quote from this."""
    chunks = []
    with open(path, encoding="utf-8") as fh:
        next(fh)
        for line in fh:
            if line.strip():
                ev = json.loads(line)
                if ev[1] == "o":
                    chunks.append(ev[2])
    text = strip_ansi("".join(chunks))
    return text.replace("\r\n", "\n").replace("\r", "")


def capture_text(paths: CoursePaths, capture_id: str) -> str | None:
    """What a capture showed, as text: a cast's output, or a browser capture's page text at every step."""
    cast = paths.captures / f"{capture_id}.cast"
    if cast.exists():
        return cast_text(cast)
    steps = paths.captures / capture_id / "steps"
    dumps = sorted(steps.glob("*.txt")) if steps.is_dir() else []
    if dumps:
        return "\n".join(p.read_text(encoding="utf-8") for p in dumps if ".b" not in p.stem)
    return None
