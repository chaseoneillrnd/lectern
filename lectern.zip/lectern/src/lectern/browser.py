"""Browser step captures: Playwright drives a UI step by step and saves data, not footage.

Each step writes a 2x screenshot, a text dump for the secrets scan, and the box of every element it touched, found by
role and name and never by pixels. A burst saves a short run of frames for real in-app motion, such as typing or a
streaming answer. The steps template synthesizes the cursor, click, zoom and crossfade on top.

capture/<id>.yaml with `kind: browser`:

    url: http://127.0.0.1:8765/
    start: python -m http.server 8765 --directory demo-app   # optional, stopped after the capture
    viewport: [1280, 720]
    mask: [{label: API key}]                                 # hidden in every screenshot
    steps:
      - id: home
        targets: {question: {role: textbox, name: Question}}
      - id: type
        type: {role: textbox, name: Question}
        text: How long does the retriever cache results?
        as: question
      - id: ask
        click: {role: button, name: Ask}
        as: ask-button
        burst: {seconds: 2.5}

A click on a link that opens a new tab takes `popup: true`, and the capture carries on in that tab. `wait_for:` names an
element the step's settled screenshot must wait for, such as the sources under a streamed answer.

Against a stack: `stack: <source>` runs `start`, `before` and `after` in a checkout of the pinned source, `ready` is a URL
to poll or `{run: <command>}` that must exit 0, and `storage_state` points at a Playwright login state kept outside the
course repo, for UIs behind a sign-in. Lectern passes that file to the browser and never reads it.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
import signal
import subprocess
import time
import urllib.request
from pathlib import Path

from .paths import CoursePaths, LecternError

ACTIONS = ("goto", "click", "fill", "type", "press", "hover", "wait", "scroll")
LOCATOR_KEYS = ("role", "label", "text", "placeholder", "alt", "title", "test_id")  # plus exact, nth, fit


def sha256(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def locate(page, spec: dict):
    """A Playwright locator from a semantic description. CSS and XPath are refused on purpose."""
    if not isinstance(spec, dict) or not any(k in spec for k in LOCATOR_KEYS):
        raise LecternError(f"locator {spec!r}: use role and name, label, text, placeholder, alt, title or test_id")
    exact = bool(spec.get("exact", True))
    if "role" in spec:
        loc = page.get_by_role(spec["role"], name=spec.get("name"), exact=exact) if spec.get("name") else page.get_by_role(spec["role"])
    elif "label" in spec:
        loc = page.get_by_label(spec["label"], exact=exact)
    elif "text" in spec:
        loc = page.get_by_text(spec["text"], exact=exact)
    elif "placeholder" in spec:
        loc = page.get_by_placeholder(spec["placeholder"], exact=exact)
    elif "alt" in spec:
        loc = page.get_by_alt_text(spec["alt"], exact=exact)
    elif "title" in spec:
        loc = page.get_by_title(spec["title"], exact=exact)
    else:
        loc = page.get_by_test_id(spec["test_id"])
    if "nth" in spec:
        loc = loc.nth(int(spec["nth"]))
    return loc


TEXT_BOX = """el => { const r = document.createRange(); r.selectNodeContents(el); const b = r.getBoundingClientRect();
  return {x: b.x, y: b.y, width: b.width, height: b.height}; }"""


def box_of(loc, fit: str | None = None) -> list[float]:
    """The element's box in CSS pixels. `fit: text` measures just its text, so a log line that spans the whole pane
    gets a box as wide as its words, and zoom and spotlight frame what is written."""
    loc.scroll_into_view_if_needed(timeout=10_000)
    b = loc.evaluate(TEXT_BOX) if fit == "text" else loc.bounding_box(timeout=10_000)
    if not b or not b["width"]:
        raise LecternError("element has no box. Is it visible?")
    return [round(b["x"], 1), round(b["y"], 1), round(b["width"], 1), round(b["height"], 1)]


def _wait_ready(ready, default_url: str, timeout: float, cwd: Path, env: dict, log) -> None:
    """Wait for a URL to answer below 500, or for a command such as `tilt wait ...` to exit 0."""
    if isinstance(ready, dict) and ready.get("run"):
        # Retry until it passes: a readiness command usually fails until the thing it asks has started at all.
        timeout = float(ready.get("timeout", timeout))
        log(f"ready: waiting for `{ready['run']}`")
        t0, last = time.time(), ""
        while (left := timeout - (time.time() - t0)) > 0:
            try:
                p = subprocess.run(ready["run"], shell=True, cwd=cwd, env=env, capture_output=True, text=True,
                                   timeout=left)
            except subprocess.TimeoutExpired:
                break
            if p.returncode == 0:
                return
            last = (p.stdout + p.stderr)[-1200:]
            time.sleep(2)
        raise LecternError(f"`{ready['run']}` did not pass within {timeout:.0f} s. Last output:\n{last}")
    url = (ready.get("url") if isinstance(ready, dict) else ready) or default_url
    if isinstance(ready, dict):
        timeout = float(ready.get("timeout", timeout))
    t0 = time.time()
    while time.time() - t0 < timeout:
        try:
            with urllib.request.urlopen(url, timeout=2) as r:  # noqa: S310 (local demo environment only)
                if r.status < 500:
                    return
        except Exception:
            time.sleep(0.5)
    raise LecternError(f"{url} did not answer within {timeout:.0f} s")


def _storage_state(paths: CoursePaths, value: str | None) -> str | None:
    """A Playwright login state for UIs behind a sign-in. It must live outside the course repo, so it is never committed."""
    if not value:
        return None
    p = Path(os.path.expandvars(os.path.expanduser(value))).resolve()
    if p == paths.root or paths.root in p.parents:
        raise LecternError(f"storage_state {value} is inside the course repo. Keep login state outside it, for example "
                           "under ~/.config/lectern/")
    if not p.is_file():
        raise LecternError(f"storage_state {value} does not exist. Save one with Playwright's codegen --save-storage")
    return str(p)


class StepWriter:
    def __init__(self, page, out: Path, masks: list, mask_color: str):
        self.page, self.out, self.masks, self.mask_color = page, out, masks, mask_color

    def shot(self, name: str, settled: bool = True) -> Path:
        p = self.out / f"{name}.png"
        self.page.screenshot(path=str(p), mask=self.masks, mask_color=self.mask_color, caret="hide",
                             animations="disabled" if settled else "allow", scale="device")
        return p

    def dump_text(self, name: str) -> Path:
        p = self.out / f"{name}.txt"
        p.write_text(self.page.inner_text("body"), encoding="utf-8")
        return p


def run_browser_capture(paths: CoursePaths, capture_id: str, spec: dict, house_tokens: dict, log=print,
                        course=None) -> Path:
    from playwright.sync_api import Error as PlaywrightError
    from playwright.sync_api import sync_playwright

    from .capture import capture_env, run_hooks, workdir

    url = spec.get("url")
    if not url:
        raise LecternError(f"capture {capture_id}: a browser capture needs url")
    vw, vh = (int(x) for x in spec.get("viewport", [1280, 720]))
    scale = int(spec.get("scale", 2))
    settle = float(spec.get("settle", 0.4))
    state = _storage_state(paths, spec.get("storage_state"))
    out = paths.captures / capture_id
    steps_dir = out / "steps"
    if steps_dir.exists():
        for f in steps_dir.iterdir():
            f.unlink()
    steps_dir.mkdir(parents=True, exist_ok=True)

    env, passed = capture_env(paths, spec)
    cwd, stack = workdir(paths, spec, course, log)
    hooks = {"before": run_hooks(spec.get("before"), cwd, env, log, f"capture {capture_id}: before")}
    server = None
    try:
        if spec.get("start"):
            log(f"capture {capture_id}: starting `{spec['start']}`")
            server = subprocess.Popen(spec["start"], shell=True, cwd=cwd, env=env, start_new_session=True,
                                      stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        _wait_ready(spec.get("ready"), url, float(spec.get("ready_timeout", 60)), cwd, env, log)
        record = _drive(paths, capture_id, spec, url, (vw, vh), scale, settle, steps_dir, house_tokens, log,
                        sync_playwright, PlaywrightError, state)
    finally:
        if server is not None:
            try:
                os.killpg(server.pid, signal.SIGINT)
                server.wait(timeout=20)
            except Exception:
                try:
                    os.killpg(server.pid, signal.SIGKILL)
                except Exception:
                    pass
        hooks["after"] = run_hooks(spec.get("after"), cwd, env, log, f"capture {capture_id}: after", strict=False)

    from .capture import scan_secrets

    redaction = scan_secrets(sorted(steps_dir.glob("*.txt")))
    record["redaction"] = redaction
    record["shows"] = {f: sha256(paths.root / f) for f in spec.get("shows", []) if (paths.root / f).exists()}
    if stack:
        stack["paths"] = list(spec.get("stack_paths") or [])
    record.update({"stack": stack, "env_passed": passed, "hooks": hooks, "signed_in": bool(state)})
    (out / "targets.json").write_text(json.dumps(record.pop("targets"), indent=1))
    (out / "meta.json").write_text(json.dumps(record, indent=1, ensure_ascii=False))
    if redaction["findings"]:
        raise LecternError(f"capture {capture_id}: gitleaks found {redaction['findings']} secret(s) in the page text. "
                           "Mask the element or use demo data. Every build that uses this capture is blocked")
    log(f"capture {capture_id}: {len(record['steps'])} steps, {sum(len(s.get('burst', [])) for s in record['steps'])} "
        f"burst frames, {len(json.loads((out / 'targets.json').read_text()))} targets")
    return out


def _drive(paths, capture_id, spec, url, viewport, scale, settle, steps_dir, tokens, log, sync_playwright, PwError,
           storage_state=None):
    vw, vh = viewport
    targets: dict[str, dict] = {}
    steps_out: list[dict] = []
    with sync_playwright() as pw:
        launch = {"headless": True}
        exe = os.environ.get("LECTERN_CAPTURE_BROWSER")
        if exe:
            launch["executable_path"] = exe
        browser = pw.chromium.launch(**launch)
        version = browser.version
        ctx = browser.new_context(viewport={"width": vw, "height": vh}, device_scale_factor=scale,
                                  color_scheme=spec.get("color_scheme", "dark"), locale="en-US", timezone_id="UTC",
                                  **({"storage_state": storage_state} if storage_state else {}))
        page = ctx.new_page()
        try:
            page.goto(url, wait_until="networkidle", timeout=60_000)
            masks = [locate(page, m) for m in spec.get("mask", [])]
            writer = StepWriter(page, steps_dir, masks, tokens["color"]["panel_2"])
            # Step 0 is the page as it loads. Every later step is shown first as the step before it, then changes.
            time.sleep(settle)
            for tid, tspec in (spec.get("targets") or {}).items():
                _add_target(targets, tid, "start", box_of(locate(page, tspec), tspec.get("fit")), "after")
            writer.shot("00-start")
            writer.dump_text("00-start")
            steps_out.append({"id": "start", "file": "steps/00-start.png", "action": None, "url": page.url,
                              "title": page.title()})
            for i, step in enumerate(spec["steps"], 1):
                if step.get("id") == "start":
                    raise LecternError("step id `start` is reserved for the page as it loads")
                sid = step.get("id") or f"step{i}"
                name = f"{i:02d}-{sid}"
                action = next((a for a in ACTIONS if a in step), None)
                rec = {"id": sid, "file": f"steps/{name}.png", "action": action}
                try:
                    if action and action != "goto" and action != "wait":
                        loc = locate(page, step[action])
                        box = box_of(loc, step[action].get("fit"))
                        rec["touched"] = box
                        if step.get("as"):
                            _add_target(targets, step["as"], sid, box, "before")
                    burst, page = _act(page, step, action, writer, name, settle)
                    if writer.page is not page:  # a click opened a new tab: the capture follows it
                        writer.page = page
                        writer.masks = [locate(page, m) for m in spec.get("mask", [])]
                        rec["new_tab"] = True
                    if burst:
                        rec["burst"] = burst
                    if step.get("wait_for"):
                        # The page is only settled once this shows, such as the sources under a streamed answer.
                        locate(page, step["wait_for"]).wait_for(state="visible",
                                                                timeout=float(step.get("timeout", 60)) * 1000)
                    page.wait_for_load_state("networkidle", timeout=15_000)
                    time.sleep(settle)
                    for tid, tspec in (step.get("targets") or {}).items():
                        _add_target(targets, tid, sid, box_of(locate(page, tspec), tspec.get("fit")), "after")
                    writer.shot(name)
                    writer.dump_text(name)
                    rec["url"], rec["title"] = page.url, page.title()
                except PwError as e:
                    raise LecternError(f"capture {capture_id}, step {sid}: {str(e).splitlines()[0]}") from None
                steps_out.append(rec)
                log(f"capture {capture_id}: step {name}{' with ' + str(len(rec['burst'])) + ' burst frames' if 'burst' in rec else ''}")
        finally:
            ctx.close()
            browser.close()
    import importlib.metadata as md

    return {"id": capture_id, "kind": "browser", "recorded": dt.date.today().isoformat(), "url": url,
            "viewport": [vw, vh], "scale": scale, "browser": f"chromium {version}",
            "playwright": md.version("playwright"), "steps": steps_out, "targets": targets,
            "requires": spec.get("requires")}


def _add_target(targets: dict, tid: str, step: str, box: list, phase: str) -> None:
    if tid in targets:
        raise LecternError(f"target {tid} is recorded twice. Give each target its own name")
    targets[tid] = {"step": step, "box": box, "phase": phase}


def _act(page, step: dict, action: str | None, writer: StepWriter, name: str, settle: float):
    """Do the step's action. Returns (burst frames, page): frames are a file and a presentation time in seconds each,
    and the page is a new tab when a click with `popup: true` opened one."""
    burst = step.get("burst")
    if action == "goto":
        page.goto(step["goto"], wait_until="networkidle", timeout=60_000)
        return None, page
    if action == "wait":
        locate(page, step["wait"]).wait_for(state="visible", timeout=float(step.get("timeout", 30)) * 1000)
        return None, page
    if action is None:
        return None, page
    loc = locate(page, step[action])
    if action == "click" and step.get("popup"):
        with page.context.expect_page(timeout=30_000) as opened:
            loc.click()
        new = opened.value
        new.set_viewport_size(page.viewport_size)
        new.wait_for_load_state("networkidle", timeout=60_000)
        return None, new
    if action == "type":
        # Typing is presentation: one frame every few characters, timed at a steady pace, like the terminal driver.
        text, cps = str(step.get("text", "")), float(step.get("typing_cps", 18))
        every = max(1, int(step.get("chars_per_frame", 2)))
        loc.click()
        frames, t = [], 0.0
        for k, ch in enumerate(text, 1):
            page.keyboard.type(ch)
            if k % every == 0 or k == len(text):
                frames.append({"file": writer.shot(f"{name}.b{len(frames):03d}", settled=False).name, "t": round(t, 3)})
            t += 1 / cps
        return [{"file": f"steps/{f['file']}", "t": f["t"]} for f in frames], page
    if action == "click":
        loc.click()
    elif action == "fill":
        loc.fill(str(step.get("text", "")))
    elif action == "press":
        loc.press(str(step.get("key", "Enter")))
    elif action == "hover":
        loc.hover()
    elif action == "scroll":
        loc.scroll_into_view_if_needed()
    if burst:
        # Real in-app motion: frames on the wall clock for a fixed span, kept at the times they were taken.
        seconds, frames, t0 = float(burst.get("seconds", 2.0)), [], time.monotonic()
        min_gap = 1 / float(burst.get("fps", 8))
        while (now := time.monotonic() - t0) < seconds:
            shot = writer.shot(f"{name}.b{len(frames):03d}", settled=False)
            frames.append({"file": f"steps/{shot.name}", "t": round(now, 3)})
            spare = min_gap - (time.monotonic() - t0 - now)
            if spare > 0:
                time.sleep(spare)
        return frames, page
    return None, page
