"""tts: synthesize every sentence with Kokoro, keep word timestamps, cache per sentence by content hash."""
from __future__ import annotations

import difflib
import hashlib
import json
import re
import time
from functools import lru_cache
from pathlib import Path

import numpy as np
import soundfile as sf

from .config import House
from .paths import CoursePaths, LecternError
from .terms import Registry

SR = 24000
SEED_SCHEME = "sentence-text-v1"
REPO_ID = "hexgrad/Kokoro-82M"


def lang_of(voice: str) -> str:
    return voice[0]  # a = American English, b = British English


def stay_offline() -> None:
    """Once `lectern init` has cached Kokoro, synthesis never touches the network, not even to check for updates."""
    if model_revision() == "unknown":
        return
    import os

    os.environ.setdefault("HF_HUB_OFFLINE", "1")
    os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")
    try:
        import huggingface_hub.constants as hf_constants

        hf_constants.HF_HUB_OFFLINE = True
    except Exception:
        pass


@lru_cache(maxsize=4)
def pipeline(lang: str):
    import torch

    stay_offline()
    from kokoro import KPipeline

    torch.use_deterministic_algorithms(True, warn_only=True)
    return KPipeline(lang_code=lang, repo_id=REPO_ID)


@lru_cache(maxsize=1)
def model_revision() -> str:
    try:
        from huggingface_hub import hf_hub_download

        p = Path(hf_hub_download(REPO_ID, "config.json", local_files_only=True))
        return p.parent.name
    except Exception:
        return "unknown"


def kokoro_version() -> str:
    import kokoro

    return getattr(kokoro, "__version__", "unknown")


def cache_key(tts_text: str, voice: str, speed: float, seed: int) -> str:
    payload = json.dumps({"text": tts_text, "voice": voice, "speed": speed, "seed": seed, "scheme": SEED_SCHEME,
                          "kokoro": kokoro_version(), "model": model_revision()}, sort_keys=True)
    return hashlib.sha256(payload.encode()).hexdigest()[:24]


def synthesize(tts_text: str, voice: str, speed: float, seed: int) -> tuple[np.ndarray, list[dict]]:
    import torch

    pipe = pipeline(lang_of(voice))
    torch.manual_seed(seed + int(hashlib.sha256(tts_text.encode()).hexdigest()[:8], 16))
    chunks, tokens, cursor = [], [], 0.0
    for res in pipe(tts_text, voice=voice, speed=speed, split_pattern=None):
        audio = res.audio.numpy().astype(np.float32)
        for tok in res.tokens or []:
            start = None if tok.start_ts is None else round(cursor + tok.start_ts, 4)
            end = None if tok.end_ts is None else round(cursor + tok.end_ts, 4)
            tokens.append({"text": tok.text, "start": start, "end": end})
        chunks.append(audio)
        cursor += len(audio) / SR
    if not chunks:
        raise LecternError(f"Kokoro produced no audio for: {tts_text!r}")
    return np.concatenate(chunks), tokens


def norm(w: str) -> str:
    return re.sub(r"[^a-z0-9]", "", w.lower())


def align(sentence_text: str, words: list[str], reps: list[dict], tokens: list[dict]) -> list[dict]:
    """Give every script word a start and end time from Kokoro's tokens.

    Words inside a registry replacement take the replacement's first token. Unmatched words take their nearest
    matched neighbour and carry fallback=True so QA can flag them.
    """
    # Character spans of each script word, to know which words a replacement covers.
    spans, pos = [], 0
    for w in words:
        i = sentence_text.find(w, pos)
        spans.append((i, i + len(w)))
        pos = i + len(w) if i >= 0 else pos
    expected: list[tuple[int, str]] = []  # (word index, expected token text)
    rep_of_word: dict[int, int] = {}
    for wi, (s, e) in enumerate(spans):
        rep = next((ri for ri, r in enumerate(reps) if r["start"] <= s < r["end"]), None)
        # A term Kokoro reads as written times word by word. Only a respelled or phoneme term is one unit.
        if rep is not None and "rendered" in reps[rep] and reps[rep]["rendered"] == reps[rep].get("original"):
            rep = None
        if rep is not None:
            rep_of_word[wi] = rep
            if not any(rep_of_word.get(k) == rep for k in range(wi)):
                expected += [(wi, t) for t in reps[rep]["expect"][:1]]
                expected += [(-1, t) for t in reps[rep]["expect"][1:]]
        else:
            expected.append((wi, words[wi]))

    timed = [t for t in tokens if norm(t["text"])]
    a = [norm(t) for _, t in expected]
    b = [norm(t["text"]) for t in timed]
    matcher = difflib.SequenceMatcher(a=a, b=b, autojunk=False)
    match_of: dict[int, dict] = {}
    for block in matcher.get_matching_blocks():
        for k in range(block.size):
            match_of[block.a + k] = timed[block.b + k]

    out: list[dict] = [dict(word=w, start=None, end=None, fallback=True) for w in words]
    for ei, (wi, _) in enumerate(expected):
        tok = match_of.get(ei)
        if wi >= 0 and tok and tok["start"] is not None:
            out[wi].update(start=tok["start"], end=tok["end"], fallback=False)
    # Words covered by a multi-word replacement inherit its first word's time.
    for wi, rep in rep_of_word.items():
        first = min(k for k, r in rep_of_word.items() if r == rep)
        if out[wi]["start"] is None and out[first]["start"] is not None:
            out[wi].update(start=out[first]["start"], end=out[first]["end"], fallback=False)
    # Remaining gaps: nearest timed neighbour, flagged.
    known = [i for i, o in enumerate(out) if o["start"] is not None]
    for i, o in enumerate(out):
        if o["start"] is None:
            prev = max((k for k in known if k < i), default=None)
            nxt = min((k for k in known if k > i), default=None)
            if prev is not None:
                o.update(start=out[prev]["end"], end=out[prev]["end"])
            elif nxt is not None:
                o.update(start=out[nxt]["start"], end=out[nxt]["start"])
            else:
                o.update(start=0.0, end=0.0)
    return out


def run_tts(paths: CoursePaths, house: House, plan: dict, registry: Registry, log=print) -> dict:
    """Synthesize every sentence in the plan. Returns the tts manifest and writes it beside the plan."""
    paths.tts_cache.mkdir(parents=True, exist_ok=True)
    cast = house.voices
    seed = int(cast.get("seed", 0))
    manifest = {"voices": {r: cast[r] for r in ("narrator", "examiner")}, "kokoro": kokoro_version(),
                "model": model_revision(), "sentences": {}}
    made = reused = 0
    t0 = time.time()
    for scene in plan["scenes"]:
        for s in scene["sentences"]:
            role = cast[s["voice"]]
            tts_text, reps = registry.apply(s["text"])
            key = cache_key(tts_text, role["voice"], float(role["speed"]), seed)
            wav, meta = paths.tts_cache / f"{key}.wav", paths.tts_cache / f"{key}.json"
            if wav.exists() and meta.exists():
                tokens = json.loads(meta.read_text())["tokens"]
                reused += 1
            else:
                audio, tokens = synthesize(tts_text, role["voice"], float(role["speed"]), seed)
                sf.write(wav, audio, SR, subtype="PCM_16")
                meta.write_text(json.dumps({"tts_text": tts_text, "voice": role["voice"], "speed": role["speed"],
                                            "tokens": tokens}, ensure_ascii=False, indent=1))
                made += 1
            duration = sf.info(wav).frames / SR
            words = align(s["text"], s["words"], reps, tokens)
            manifest["sentences"][s["id"]] = {
                "key": key, "wav": str(wav), "duration": round(duration, 4), "tts_text": tts_text,
                "voice": role["voice"], "words": words,
                "fallback_words": [w["word"] for w in words if w["fallback"]],
            }
    manifest["stats"] = {"synthesized": made, "cached": reused, "seconds": round(time.time() - t0, 1)}
    out = paths.build_dir(plan["lesson"]["id"]) / "tts.json"
    out.write_text(json.dumps(manifest, indent=1, ensure_ascii=False))
    log(f"tts: {made} sentences synthesized, {reused} from cache, {manifest['stats']['seconds']} s")
    return manifest
