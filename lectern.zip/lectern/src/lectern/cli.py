"""The Lectern CLI. Skills hold judgment, the CLI holds every step that must repeat."""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Optional

import typer

from . import config as cfg
from .paths import CoursePaths, LecternError, find_course_root

app = typer.Typer(add_completion=False, no_args_is_help=True,
                  help="Lectern: narrated, verified video lessons from Markdown scripts.")
config_app = typer.Typer(no_args_is_help=True, help="Get, set, explain and validate config across the four layers.")
app.add_typer(config_app, name="config")

os.environ.setdefault("HYPERFRAMES_NO_TELEMETRY", "1")
os.environ.setdefault("DO_NOT_TRACK", "1")
os.environ.setdefault("RAGAS_DO_NOT_TRACK", "true")


def _version(value: bool) -> None:
    if value:
        from . import __version__

        typer.echo(f"lectern {__version__}")
        raise typer.Exit()


@app.callback()
def main_options(version: bool = typer.Option(False, "--version", callback=_version, is_eager=True,
                                              help="Print the version and exit")):
    """Lectern: narrated, verified video lessons from Markdown scripts."""


class Ctx:
    def __init__(self, course_dir: Path | None = None):
        self.paths = CoursePaths(find_course_root(course_dir))
        self.paths.ensure()
        self.house = cfg.House()
        self.course = cfg.load_course(self.paths.root)
        self.paths.tts_cache = cfg.tts_cache_dir(self.paths.root, self.course)
        self.paths.tts_cache.mkdir(parents=True, exist_ok=True)

    def lesson_front(self, lesson_id: str) -> dict:
        from .script import parse_lesson

        lesson = parse_lesson(self.paths.lesson_script(lesson_id), set(self.house.motion["verbs"]))
        return lesson.front

    def effective(self, lesson_id: str | None = None, cli: dict | None = None):
        front = self.lesson_front(lesson_id) if lesson_id else {}
        return cfg.resolve(self.house, self.course, front, cli)

    def registry(self):
        from .terms import Registry

        return Registry.load(self.house.terms, self.paths.root / (self.course.terms or "terms.yaml"))


def fail(e: Exception) -> None:
    typer.secho(str(e), fg=typer.colors.RED, err=True)
    raise typer.Exit(1)


def cli_overrides(fidelity: Optional[str], quality: Optional[str]) -> dict:
    return {"fidelity": fidelity, "quality": quality}


# ----------------------------------------------------------------------------- config


@config_app.command("get")
def config_get(key: str, lesson: Optional[str] = typer.Option(None, help="Resolve for one lesson")):
    """Print the effective value of KEY."""
    try:
        eff = Ctx().effective(lesson)
        typer.echo(json.dumps(eff.get(key)))
    except LecternError as e:
        fail(e)


@config_app.command("explain")
def config_explain(key: str, lesson: Optional[str] = typer.Option(None, help="Resolve for one lesson")):
    """Print the chain for KEY across house, course, lesson and CLI, and name the layer that won."""
    try:
        typer.echo(cfg.explain(Ctx().effective(lesson), key))
    except LecternError as e:
        fail(e)


@config_app.command("validate")
def config_validate(lesson: Optional[str] = typer.Option(None)):
    """Validate every layer. Exits non-zero on the first invalid value."""
    try:
        eff = Ctx().effective(lesson)
        typer.echo(f"ok: {len(eff.values)} keys valid")
    except LecternError as e:
        fail(e)


def write_setting(key: str, value, scope: str, reason: Optional[str] = None) -> str:
    """Validate, then write one setting at its scope. The CLI owns every config write."""
    import yaml

    house = cfg.House()
    parsed = yaml.safe_load(value) if isinstance(value, str) else value
    q = house.question(key)
    if q and scope not in q.get("scope", []):
        raise LecternError(f"{key} can be set at {', '.join(q['scope'])}, not {scope}")
    parsed = cfg.validate_value(key, parsed, house)
    if q and q.get("reason_required_on_override") and scope != "house" and not reason:
        raise LecternError(f"{key} overrides need a reason (--reason)")
    if scope == "machine":
        profile = cfg.load_machine()
        section, _, leaf = key.partition(".")
        profile.setdefault(section, {})[leaf] = parsed
        cfg.save_machine(profile)
    elif key in ("narrator", "examiner"):
        cfg.set_yaml_key(house.root / "voices.yaml", f"{key}.voice", parsed)
    elif scope == "house":
        cfg.set_yaml_key(house.root / "config.yaml", key, parsed)
    elif scope == "course":
        ctx = Ctx()
        cfg.set_yaml_key(ctx.paths.root / "course.yaml", f"defaults.{key}", parsed)
        if reason:
            cfg.set_yaml_key(ctx.paths.root / "course.yaml", "defaults.cap_reason", reason)
        Ctx().effective()  # re-validate the whole chain after the write
    else:
        raise LecternError("lesson-scope values live in the lesson's front matter. Edit the script or use the wizard")
    return f"set {key}={parsed!r} at {scope}"


@config_app.command("set")
def config_set(key: str, value: str, scope: str = typer.Option(..., help="machine | house | course"),
               reason: Optional[str] = typer.Option(None, help="Required when the key demands a reason")):
    """Validate VALUE for KEY, then write it at SCOPE, keeping comments."""
    try:
        typer.echo(write_setting(key, value, scope, reason))
    except LecternError as e:
        fail(e)


# ----------------------------------------------------------------------------- stages


@app.command("compile")
def compile_cmd(lesson: str):
    """Parse the script and validate cues, targets, claim tags and terms. Writes the scene plan."""
    from .compile import compile_lesson

    try:
        ctx = Ctx()
        plan, warnings = compile_lesson(ctx.paths, ctx.course, ctx.house, lesson)
        for w in warnings:
            typer.secho(f"warning: {w}", fg=typer.colors.YELLOW)
        n = sum(len(s["sentences"]) for s in plan["scenes"])
        typer.echo(f"compile ok: {len(plan['scenes'])} scenes, {n} sentences, about {plan['estimate_minutes']} min")
    except LecternError as e:
        fail(e)


@app.command("tts")
def tts_cmd(lesson: str):
    """Synthesize every sentence with Kokoro, reusing the per-sentence cache."""
    from .compile import compile_lesson
    from .tts import run_tts

    try:
        ctx = Ctx()
        plan, _ = compile_lesson(ctx.paths, ctx.course, ctx.house, lesson)
        run_tts(ctx.paths, ctx.house, plan, ctx.registry())
    except LecternError as e:
        fail(e)


@app.command("capture")
def capture_cmd(capture_ids: list[str] = typer.Argument(..., help="One or more capture IDs, run in the order given")):
    """Run capture scripts against the live environment and pin their output. Later captures may rely on what
    earlier ones started, so a stack Quick start runs as `lectern capture quickstart tour`."""
    from .capture import run_capture

    try:
        ctx = Ctx()
        for capture_id in capture_ids:
            run_capture(ctx.paths, capture_id, log=typer.echo, tokens=ctx.house.tokens, course=ctx.course)
    except LecternError as e:
        fail(e)


@app.command("sources")
def sources_cmd(repin: list[str] = typer.Option([], "--repin", help="Re-pin this source to the commit its ref points "
                                                                      "at now. Repeat for each. Captures must re-run")):
    """Fetch every pinned source into the local cache, so claim checks run offline."""
    from .sources import fetch_all, repin as do_repin

    try:
        ctx = Ctx()
        for name in repin:
            old, new = do_repin(ctx.paths, ctx.course, name)
            typer.echo(f"{name}: pinned {new[:12]}" + (f" (was {old[:12]})" if old and old != new else " (unchanged)"))
        if repin:
            ctx = Ctx()
        for name, path in fetch_all(ctx.paths, ctx.course).items():
            typer.echo(f"{name}: {path}")
    except LecternError as e:
        fail(e)


def run_pipeline(ctx: "Ctx", lesson: str, until: str = "package", cli: dict | None = None) -> dict:
    """compile -> tts -> timeline -> render -> check -> package, stopping after `until`."""
    import time

    from .checks import normalize_loudness, run_checks
    from .compile import compile_lesson
    from .package import package_lesson, transcript_md
    from .render import render_lesson
    from .timeline import build_timeline
    from .tts import run_tts

    t0 = time.time()
    out: dict = {}
    plan, warnings = compile_lesson(ctx.paths, ctx.course, ctx.house, lesson)
    for w in warnings:
        typer.secho(f"warning: {w}", fg=typer.colors.YELLOW)
    typer.echo(f"compile: {len(plan['scenes'])} scenes, about {plan['estimate_minutes']} min")
    out["plan"] = plan
    if until == "compile":
        return out
    # Claims and shown code fail in seconds, so they gate everything expensive.
    from .checks import check_claims, check_code_ran

    claims, broken = check_claims(ctx.paths, ctx.course, plan)
    broken += check_code_ran(ctx.paths, plan)[1]
    if broken:
        raise LecternError("claims failed, nothing was rendered:\n  " + "\n  ".join(broken))
    typer.echo(f"claims: {len(claims)} verified against pinned sources and captures")
    tts = run_tts(ctx.paths, ctx.house, plan, ctx.registry(), log=typer.echo)
    out["tts"] = tts
    if until == "tts":
        return out
    eff = ctx.effective(lesson, cli)
    timeline, tw = build_timeline(ctx.paths, ctx.house, plan, tts, eff)
    typer.echo(f"timeline: {len(timeline['scenes'])} scenes, {timeline['duration_ms'] / 1000:.1f} s, {len(tw)} warnings")
    out["timeline"] = timeline
    if until == "timeline":
        return out
    render = render_lesson(ctx.paths, ctx.house, plan, timeline, eff, log=typer.echo)
    out["render"] = render
    if until == "render":
        return out
    build = ctx.paths.build_dir(lesson)
    normalize_loudness(build / "narration.wav", build / "narration.norm.wav", float(eff["loudness_lufs"]),
                       float(eff["true_peak_db"]))
    (build / "transcript.md").write_text(transcript_md(timeline, plan))
    check = run_checks(ctx.paths, ctx.course, ctx.house, plan, timeline, eff, build / "narration.norm.wav",
                       build / "transcript.md", render)
    out["check"] = check
    for w in check["warnings"]:
        typer.secho(f"warning: {w}", fg=typer.colors.YELLOW)
    if not check["ok"]:
        raise LecternError("check failed, the build is blocked:\n  " + "\n  ".join(check["broken"]))
    typer.echo(f"check: all gates green ({sum(1 for c in check['claims'] if c['status'] == 'ok')} claims verified)")
    if until == "check":
        return out
    dist = package_lesson(ctx.paths, ctx.course, ctx.house, plan, timeline, check, render, tts, eff, log=typer.echo)
    out["dist"] = dist
    typer.echo(f"build: done in {time.time() - t0:.0f} s -> {dist.relative_to(ctx.paths.root)}")
    return out


@app.command("build")
def build_cmd(lesson: str, fidelity: Optional[str] = typer.Option(None, help="full | slides"),
              quality: Optional[str] = typer.Option(None, help="draft | standard")):
    """Compile, tts, timeline, render, check and package one lesson."""
    try:
        run_pipeline(Ctx(), lesson, "package", cli_overrides(fidelity, quality))
    except LecternError as e:
        fail(e)


@app.command("render")
def render_cmd(lesson: str, quality: Optional[str] = typer.Option(None, help="draft | standard")):
    """Run every stage up to render: the joined scene video and the narration track."""
    try:
        run_pipeline(Ctx(), lesson, "render", cli_overrides(None, quality))
    except LecternError as e:
        fail(e)


@app.command("check")
def check_cmd(lesson: str):
    """Run every stage up to and including the deterministic gates."""
    try:
        run_pipeline(Ctx(), lesson, "check")
    except LecternError as e:
        fail(e)


@app.command("package")
def package_cmd(lesson: str):
    """Same as build. Every stage reuses its cache, so packaging alone costs seconds."""
    build_cmd(lesson)


@app.command("preview")
def preview_cmd(serve: bool = typer.Option(True, help="Serve with live reload. --no-serve only builds the static site"),
                port: int = typer.Option(5173)):
    """Build a local VitePress site from every packaged lesson, with the Lectern theme."""
    from .preview import build_site, build_static

    try:
        ctx = Ctx()
        site = build_site(ctx.paths, ctx.course, ctx.house)
        if not serve:
            out = build_static(site)
            typer.echo(f"preview built: {out}")
            return
        typer.echo(f"preview: http://localhost:{port}/  (Ctrl+C to stop)")
        import subprocess
        from .paths import node_bin
        subprocess.run([str(node_bin("vitepress")), "dev", "docs", "--port", str(port)], cwd=site)
    except LecternError as e:
        fail(e)


@app.command("site")
def site_cmd():
    """Write the course page (lessons in order, the CourseMap) and the glossary page into dist/<course>/."""
    from .site import write_site

    try:
        ctx = Ctx()
        for page in write_site(ctx.paths, ctx.course, ctx.house):
            typer.echo(f"site: {page.relative_to(ctx.paths.root)}")
    except LecternError as e:
        fail(e)


@app.command("profile")
def profile_cmd(seconds: float = typer.Option(10.0, help="Length of the probe render")):
    """Time a probe render at 1, 2 and half the CPUs, and keep the fastest worker count for this machine."""
    from .profile import run_profile

    try:
        result = run_profile(seconds, log=typer.echo)
        typer.echo(f"render.workers = {result['workers']} saved to {result['path']}")
    except LecternError as e:
        fail(e)


# ----------------------------------------------------------------------------- claims, judge, gates


def _claims(ctx: "Ctx", lesson: str) -> tuple[dict, list[dict], list[str]]:
    from .checks import check_claims, check_code_ran
    from .compile import compile_lesson

    plan, _ = compile_lesson(ctx.paths, ctx.course, ctx.house, lesson)
    claims, broken = check_claims(ctx.paths, ctx.course, plan)
    _, b2 = check_code_ran(ctx.paths, plan)
    return plan, claims, broken + b2


@app.command("claims")
def claims_cmd(lesson: str):
    """Check every claim's excerpt against its pinned source, and every shown file against a captured run."""
    try:
        ctx = Ctx()
        plan, claims, broken = _claims(ctx, lesson)
        for c in claims:
            mark = "ok    " if c["status"] == "ok" else "BROKEN"
            typer.echo(f"{mark} {c['id']:<10} {c['kind']:<5} {c['where']}")
        out = ctx.paths.build_dir(lesson) / "claims.json"
        out.write_text(json.dumps(claims, indent=1, ensure_ascii=False))
        if broken:
            raise LecternError("claims failed:\n  " + "\n  ".join(broken))
        typer.echo(f"claims ok: {len(claims)} verified against pinned sources and captures")
    except LecternError as e:
        fail(e)


@app.command("judge-input")
def judge_input_cmd(lesson: Optional[str] = typer.Argument(None),
                    calibration: bool = typer.Option(False, help="Write the planted-claims calibration bundle instead")):
    """Write the claims judge's input bundle: each cited sentence with its evidence and what is on screen."""
    from .gates import calibration_bundle, judge_input

    try:
        ctx = Ctx()
        if calibration:
            bundle, _ = calibration_bundle(ctx.house)
            out = ctx.paths.state / "judge" / "calibration-input.json"
        else:
            if not lesson:
                raise LecternError("name a lesson, or pass --calibration")
            plan, claims, broken = _claims(ctx, lesson)
            if broken:
                raise LecternError("fix broken claims before judging:\n  " + "\n  ".join(broken))
            bundle = judge_input(ctx.paths, plan, claims)
            out = ctx.paths.build_dir(lesson) / "judge-input.json"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(bundle, indent=1, ensure_ascii=False))
        typer.echo(f"judge input: {out} ({len(bundle['items'])} items)")
    except LecternError as e:
        fail(e)


@app.command("judge-save")
def judge_save_cmd(lesson: Optional[str] = typer.Argument(None),
                   result: Path = typer.Option(..., "--result", help="The judge's JSON output"),
                   calibration: bool = typer.Option(False, help="Score a calibration run against the planted answers")):
    """Validate the judge's JSON against the bundle it was given, then save it for the gate-one packet."""
    from .gates import calibration_bundle, score_calibration, validate_judge

    try:
        ctx = Ctx()
        raw = result.read_text(encoding="utf-8")
        start, end = raw.find("{"), raw.rfind("}")
        try:
            output = json.loads(raw[start:end + 1])
        except ValueError as e:
            raise LecternError(f"judge output is not JSON: {e}") from None
        if calibration:
            bundle, expect = calibration_bundle(ctx.house)
            checked = validate_judge(output, bundle)
            misses = score_calibration(checked, expect)
            out = ctx.paths.state / "judge" / "calibration.json"
            out.write_text(json.dumps({**checked, "misses": misses, "ok": not misses}, indent=1, ensure_ascii=False))
            for m in misses:
                typer.secho(f"miss: {m}", fg=typer.colors.RED)
            if misses:
                raise LecternError(f"judge calibration failed on {len(misses)} of {len(checked['scores'])} items")
            typer.echo(f"judge calibration passed: {len(checked['scores'])} items, every planted bad claim caught")
            return
        if not lesson:
            raise LecternError("name a lesson, or pass --calibration")
        bundle_path = ctx.paths.build_dir(lesson) / "judge-input.json"
        if not bundle_path.exists():
            raise LecternError(f"no judge input for {lesson}. Run `lectern judge-input {lesson}` first")
        bundle = json.loads(bundle_path.read_text())
        from .gates import bundle_sha, judge_input

        plan, claims, _ = _claims(ctx, lesson)
        if bundle_sha(judge_input(ctx.paths, plan, claims)) != bundle_sha(bundle):
            raise LecternError("the lesson changed after `lectern judge-input`. Write a new bundle and judge it again")
        checked = validate_judge(output, bundle)
        out = ctx.paths.build_dir(lesson) / "judge.json"
        out.write_text(json.dumps(checked, indent=1, ensure_ascii=False))
        weak = [s for s in checked["scores"] if s["score"] < 2]
        for s in weak:
            typer.secho(f"weak: {s['item']} scored {s['score']}: {s['reason']}", fg=typer.colors.YELLOW)
        typer.echo(f"judge saved: {len(checked['scores'])} sentences, {len(weak)} below 2")
    except LecternError as e:
        fail(e)


def _parse_reply(result: Path, what: str) -> dict:
    raw = result.read_text(encoding="utf-8")
    start, end = raw.find("{"), raw.rfind("}")
    try:
        return json.loads(raw[start:end + 1])
    except ValueError as e:
        raise LecternError(f"{what} output is not JSON: {e}") from None


@app.command("inspect-input")
def inspect_input_cmd(lesson: Optional[str] = typer.Argument(None),
                      calibration: bool = typer.Option(False, help="Write the planted-frames calibration bundle instead")):
    """Write the frame inspector's bundle: every contact-sheet frame with what it should show."""
    from .inspector import calibration_bundle, inspect_input

    try:
        ctx = Ctx()
        if calibration:
            bundle, _ = calibration_bundle(ctx.house)
            out = ctx.paths.state / "inspect" / "calibration-input.json"
        else:
            if not lesson:
                raise LecternError("name a lesson, or pass --calibration")
            plan = json.loads((ctx.paths.build_dir(lesson) / "plan.json").read_text())
            bundle = inspect_input(ctx.paths, ctx.course.id, lesson, plan)
            out = ctx.paths.build_dir(lesson) / "inspect-input.json"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(bundle, indent=1, ensure_ascii=False))
        typer.echo(f"inspect input: {out} ({len(bundle['items'])} frames)")
    except (LecternError, FileNotFoundError) as e:
        fail(e)


@app.command("inspect-save")
def inspect_save_cmd(lesson: Optional[str] = typer.Argument(None),
                     result: Path = typer.Option(..., "--result", help="The frame inspector's JSON output"),
                     calibration: bool = typer.Option(False, help="Score a calibration run against the planted defects")):
    """Validate the frame inspector's JSON against its bundle, then save it for the gate-two packet."""
    from .inspector import bundle_sha, calibration_bundle, inspect_input, score_calibration, validate_inspection

    try:
        ctx = Ctx()
        output = _parse_reply(result, "inspector")
        if calibration:
            bundle, expect = calibration_bundle(ctx.house)
            checked = validate_inspection(output, bundle)
            misses = score_calibration(checked, expect)
            out = ctx.paths.state / "inspect" / "calibration.json"
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_text(json.dumps({**checked, "misses": misses, "ok": not misses}, indent=1, ensure_ascii=False))
            for m in misses:
                typer.secho(f"miss: {m}", fg=typer.colors.RED)
            if misses:
                raise LecternError(f"inspector calibration failed on {len(misses)} of {len(checked['frames'])} frames")
            typer.echo(f"inspector calibration passed: {len(checked['frames'])} frames, every planted defect caught")
            return
        if not lesson:
            raise LecternError("name a lesson, or pass --calibration")
        bundle_path = ctx.paths.build_dir(lesson) / "inspect-input.json"
        if not bundle_path.exists():
            raise LecternError(f"no inspect input for {lesson}. Run `lectern inspect-input {lesson}` first")
        bundle = json.loads(bundle_path.read_text())
        plan = json.loads((ctx.paths.build_dir(lesson) / "plan.json").read_text())
        if bundle_sha(inspect_input(ctx.paths, ctx.course.id, lesson, plan)) != bundle_sha(bundle):
            raise LecternError("the lesson was rebuilt after `lectern inspect-input`. Write a new bundle and inspect again")
        checked = validate_inspection(output, bundle)
        review = ctx.paths.dist_dir(ctx.course.id, lesson) / "review"
        (review / "frame-inspection.json").write_text(json.dumps(checked, indent=1, ensure_ascii=False))
        major = [f for f in checked["frames"] if f["verdict"] == "issue"]
        for f in major:
            for i in f["issues"]:
                if i["severity"] == "major":
                    typer.secho(f"major: {f['item']} {i['kind']}: {i['note']}", fg=typer.colors.YELLOW)
        typer.echo(f"inspection saved: {len(checked['frames'])} frames, {len(major)} with a major issue")
    except LecternError as e:
        fail(e)


gate_app = typer.Typer(no_args_is_help=True, help="The two human gates: packets to review, and approvals.")
app.add_typer(gate_app, name="gate")


@gate_app.command("packet")
def gate_packet_cmd(lesson: str, gate: str = typer.Argument(..., help="one | two")):
    """Build the review page for a gate: script and claims for one, the render and QA for two."""
    from .gates import gate_one_packet, gate_state, gate_two_packet

    try:
        ctx = Ctx()
        out_dir = ctx.paths.state / "gates"
        out_dir.mkdir(parents=True, exist_ok=True)
        if gate == "one":
            plan, claims, broken = _claims(ctx, lesson)
            if broken:
                raise LecternError("gate one needs every claim verified first:\n  " + "\n  ".join(broken))
            from .gates import bundle_sha, judge_input

            judge_path = ctx.paths.build_dir(lesson) / "judge.json"
            judge = json.loads(judge_path.read_text()) if judge_path.exists() else None
            if judge is not None and judge.get("bundle_sha") != bundle_sha(judge_input(ctx.paths, plan, claims)):
                typer.secho("warning: the judge scored an older version of this lesson, so its scores are left out. "
                            "Run `lectern judge-input` and the claims-judge again", fg=typer.colors.YELLOW)
                judge = None
            elif judge is None:
                typer.secho("warning: no judge scores yet. Run the claims-judge and `lectern judge-save` first",
                            fg=typer.colors.YELLOW)
            from .audition import term_snippets

            snippets = term_snippets(ctx, plan)
            html = gate_one_packet(ctx.paths, ctx.house, plan, claims, judge, snippets)
        elif gate == "two":
            state = gate_state(ctx.paths, ctx.course.id, lesson)
            if not state["one"]["approved"]:
                typer.secho("warning: gate one is still open. The packet says so, and gate two cannot be approved "
                            "until gate one is", fg=typer.colors.YELLOW)
            timeline = json.loads((ctx.paths.build_dir(lesson) / "timeline.json").read_text())
            folder = gate_two_packet(ctx.paths, ctx.house, ctx.course.id, lesson, timeline, out_dir / f"{lesson}-gate-two",
                                     gate_one_open=not state["one"]["approved"])
            files = sorted(p.relative_to(folder).as_posix() for p in folder.rglob("*") if p.is_file())
            size = sum((folder / f).stat().st_size for f in files) / 1e6
            typer.echo(f"gate two packet: {folder / 'index.html'} with {len(files) - 1} files beside it ({size:.1f} MB)")
            return
        else:
            raise LecternError("gate is one or two")
        out = out_dir / f"{lesson}-gate-{gate}.html"
        out.write_text(html, encoding="utf-8")
        typer.echo(f"gate {gate} packet: {out} ({out.stat().st_size / 1e6:.1f} MB)")
    except LecternError as e:
        fail(e)


@gate_app.command("approve")
def gate_approve_cmd(lesson: str, gate: str = typer.Argument(..., help="one | two"),
                     by: Optional[str] = typer.Option(None, help="Who approved. Default: the current user")):
    """Record a human approval, pinned to the hashes of exactly what was reviewed."""
    from .gates import approve

    try:
        ctx = Ctx()
        entry = approve(ctx.paths, ctx.course.id, lesson, gate, by)
        typer.echo(f"gate {gate} approved for {lesson} by {entry['by']} on {entry['approved']}")
    except LecternError as e:
        fail(e)


# ----------------------------------------------------------------------------- setup, scaffolding, status


@app.command("init")
def init_cmd(check: bool = typer.Option(False, "--check", help="Only report what is missing"),
             defaults: bool = typer.Option(False, "--defaults", help="Take every default with no questions")):
    """Check the toolchain. Without --check, also cache Kokoro's weights so later runs work offline."""
    from .scaffold import check_toolchain, warm_models

    try:
        house = cfg.House()
        if not check:
            warm_models(house, log=typer.echo)
        if defaults:
            from .profile import run_profile
            from .wizard import init_defaults

            init_defaults(house, lambda: run_profile(log=typer.echo), log=typer.echo)
        rows = check_toolchain(house)
        width = max(len(r["what"]) for r in rows)
        for r in rows:
            mark = "ok  " if r["ok"] else "MISS"
            typer.echo(f"{mark} {r['what']:<{width}}  {r['detail']}" + (f"\n     fix: {r['fix']}" if r["fix"] else ""))
        hard = [r for r in rows if not r["ok"] and r["what"] not in ("gitleaks", "render profile")]
        if hard:
            raise LecternError(f"{len(hard)} required piece(s) missing")
        typer.echo("toolchain ready")
    except LecternError as e:
        fail(e)


course_app = typer.Typer(no_args_is_help=True, help="Start a course.")
app.add_typer(course_app, name="course")


@course_app.command("new")
def course_new_cmd(course_id: str = typer.Option(..., "--id"), title: str = typer.Option(...),
                   kind: str = typer.Option(..., help="stack | topic"),
                   source: list[str] = typer.Option([], help="name=repo@ref, repeat for each source"),
                   floor: Optional[str] = typer.Option(None, help="Comma-separated. Default depends on the kind"),
                   directory: Path = typer.Option(Path("."), "--dir", help="Where course.yaml goes")):
    """Write course.yaml (sources pinned to the commit each ref resolves to), terms.yaml and the course folders."""
    from .scaffold import new_course

    try:
        fl = [x.strip() for x in floor.split(",")] if floor else None
        path = new_course(directory.resolve(), cfg.House(), course_id, title, kind, source, fl, log=typer.echo)
        typer.echo(f"wrote {path}. Next: `lectern sources`")
    except LecternError as e:
        fail(e)


lesson_app = typer.Typer(no_args_is_help=True, help="Start a lesson.")
app.add_typer(lesson_app, name="lesson")


@lesson_app.command("new")
def lesson_new_cmd(lesson_id: str, lesson_type: str = typer.Option(..., "--type", help="quickstart | map | drilldown | recipe"),
                   objective: str = typer.Option(...), checkpoint_seed: str = typer.Option(...),
                   title: Optional[str] = typer.Option(None), rung: str = typer.Option("practitioner"),
                   captures: Optional[str] = typer.Option(None, help="Comma-separated capture IDs"),
                   cap_minutes: Optional[int] = typer.Option(None), cap_reason: Optional[str] = typer.Option(None),
                   component: Optional[str] = typer.Option(None, help="For a drilldown: the Map component it opens on"),
                   prerequisites: Optional[str] = typer.Option(None, help="Comma-separated lesson IDs to watch first")):
    """Write the lesson's front matter stub and an empty claims ledger, and add it to the course skeleton."""
    from .scaffold import new_lesson

    try:
        ctx = Ctx()
        caps = [x.strip() for x in captures.split(",")] if captures else []
        pres = [x.strip() for x in prerequisites.split(",")] if prerequisites else []
        path = new_lesson(ctx.paths.root, ctx.house, ctx.course, lesson_id, lesson_type, objective, checkpoint_seed,
                          title, rung, caps, cap_minutes, cap_reason, component, pres)
        typer.echo(f"wrote {path}. Next: /lectern:lesson {lesson_id}")
    except LecternError as e:
        fail(e)


map_app = typer.Typer(no_args_is_help=True, help="The course Map: draft positions once, then check every lesson draws it the same.")
app.add_typer(map_app, name="map")


@map_app.command("draft")
def map_draft_cmd():
    """Give every component in map.yaml that has no position one, by auto-layout. Positions already set never move."""
    from .coursemap import draft_map

    try:
        ctx = Ctx()
        drafted = draft_map(ctx.paths, ctx.course, ctx.house)
        if not drafted:
            typer.echo("every component has a position. Positions are frozen: move one by editing map.yaml, and every "
                       "lesson that draws the Map re-renders")
            return
        for nid, (x, y) in drafted.items():
            typer.echo(f"{nid}: at [{x:g}, {y:g}]")
        typer.echo(f"drafted {len(drafted)} positions into {ctx.course.map}. Look at them with `lectern map still`, adjust "
                   "by hand, and from then on they are frozen")
    except LecternError as e:
        fail(e)


@map_app.command("still")
def map_still_cmd(out: Path = typer.Option(Path("map.png"), help="Where to write the PNG"),
                  component: Optional[str] = typer.Option(None, help="Light this component, as a drilldown opens")):
    """Write one frame of the Map, as every lesson draws it, without building a lesson."""
    from .mapcheck import map_still

    try:
        ctx = Ctx()
        typer.echo(f"map still: {map_still(ctx.paths, ctx.course, ctx.house, out.resolve(), component)}")
    except LecternError as e:
        fail(e)


@map_app.command("check")
def map_check_cmd():
    """Photograph every built map scene as it settles and compare it with a still of the Map alone, pixel by pixel."""
    from .mapcheck import map_check

    try:
        ctx = Ctx()
        report = map_check(ctx.paths, ctx.course, ctx.house, log=typer.echo)
        for st, info in report["states"].items():
            label = "plain Map" if st == "plain" else f"opening on {st}"
            psnr = info.get("mp4_min_psnr_between_lessons")
            typer.echo(f"  {label}: {len(info['scenes'])} scenes" + (f", MP4 frames agree to {psnr} dB" if psnr else ""))
        for prob in report["problems"]:
            typer.secho(f"  {prob}", fg=typer.colors.RED)
        if not report["ok"]:
            raise typer.Exit(1)
    except LecternError as e:
        fail(e)


@app.command("stale")
def stale_cmd(fail_on_stale: bool = typer.Option(False, "--fail", help="Exit 1 when any lesson is stale, for a CI schedule")):
    """Compare pins against upstream: newer releases, excerpts missing at HEAD, and stack files that captures show
    and that changed. Flags stale lessons in status and on their pages. Never blocks a build."""
    from .stale import run_stale

    try:
        ctx = Ctx()
        report = run_stale(ctx.paths, ctx.course, ctx.house, log=typer.echo)
        stale = [lid for lid, e in report["lessons"].items() if e["stale"]]
        for item in report["unchecked"]:
            typer.secho(f"unchecked: {item}", fg=typer.colors.YELLOW)
        typer.echo(f"stale: {len(stale)} of {len(report['lessons'])} lessons flagged"
                   + (f" ({', '.join(stale)})" if stale else "") + f". Report: {ctx.paths.state / 'stale.json'}")
        if stale and fail_on_stale:
            raise typer.Exit(1)
    except LecternError as e:
        fail(e)


@app.command("status")
def status_cmd(as_json: bool = typer.Option(False, "--json")):
    """Effective config that differs from the house, each lesson's state, and open gates. Changes nothing."""
    from .status import course_status, format_status

    try:
        st = course_status(Ctx())
        typer.echo(json.dumps(st, indent=1, ensure_ascii=False) if as_json else format_status(st))
    except LecternError as e:
        fail(e)


@app.command("wizard")
def wizard_cmd(mode: str = typer.Argument(..., help="setup | audition | course | lesson | override | status")):
    """The wizard in the terminal: the same questions as /lectern:wizard, with Enter to keep each value."""
    from .wizard import Wizard

    try:
        house = cfg.House()
        try:
            root = find_course_root()
            state_dir = root / ".lectern"
        except LecternError:
            root, state_dir = None, Path.cwd() / ".lectern"
        w = Wizard(house, state_dir)
        if mode == "setup":
            from .profile import run_profile

            w.setup(lambda: run_profile(log=typer.echo))
        elif mode == "audition":
            def render_page() -> Path:
                audition_voices(out=Path(".lectern/audition/index.html"), voices=None, speeds="0.9,1.0,1.1")
                return Ctx().paths.root / ".lectern/audition/index.html"

            def apply_line(line: str) -> list[str]:
                from .audition import apply_picks

                ctx = Ctx()
                return apply_picks(ctx.house, ctx.paths.root / (ctx.course.terms or "terms.yaml"), line)

            w.audition(render_page, apply_line)
        elif mode == "course":
            from .scaffold import new_course

            def create(a: dict) -> Path:
                return new_course(Path.cwd(), house, a["course.id"], a["course.title"], a["course.kind"],
                                  a["course.sources"], a["course.floor"], log=typer.echo)

            w.course(create)
        elif mode == "lesson":
            from .scaffold import new_lesson

            def create(a: dict) -> Path:
                ctx = Ctx()
                return new_lesson(ctx.paths.root, house, ctx.course, a["lesson.id"], a["lesson.type"],
                                  a["lesson.objective"], a["lesson.checkpoint_seed"], a["lesson.title"], a["rung"])

            w.lesson(create)
        elif mode == "override":
            w.override(write_setting)
        elif mode == "status":
            status_cmd(as_json=False)
        else:
            raise LecternError("mode is setup, audition, course, lesson, override or status")
    except LecternError as e:
        fail(e)
    except (KeyboardInterrupt, EOFError):
        typer.echo("\nStopped. Answers so far are saved, so the same command resumes here.")
        raise typer.Exit(130)


audition_app = typer.Typer(no_args_is_help=True, help="Voice and pronunciation auditions.")
app.add_typer(audition_app, name="audition")


@audition_app.command("voices")
def audition_voices(out: Path = typer.Option(Path(".lectern/audition/index.html"), help="Where to write the page"),
                    voices: Optional[str] = typer.Option(None, help="Comma-separated voice IDs. Default: the shortlist"),
                    speeds: str = typer.Option("0.9,1.0,1.1", help="Comma-separated speeds")):
    """Render every shortlisted voice as Narrator and Examiner at three speeds, plus each proposed term."""
    from .audition import build_page, render_takes, render_terms
    from .config import load_yaml

    try:
        ctx = Ctx()
        vs = voices.split(",") if voices else list(ctx.house.voices["shortlist"])
        sp = [float(x) for x in speeds.split(",")]
        registry = ctx.registry()
        takes = render_takes(ctx.house, registry, vs, sp)
        course_terms = ctx.paths.root / (ctx.course.terms or "terms.yaml")
        raw = load_yaml(course_terms) if course_terms.exists() else {}
        terms = render_terms(ctx.house, registry, raw, ctx.house.voices["narrator"]["voice"])
        html = build_page(ctx.house, takes, terms, vs, sp, ctx.course.title)
        out = out if out.is_absolute() else ctx.paths.root / out
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(html, encoding="utf-8")
        typer.echo(f"audition page: {out} ({out.stat().st_size / 1e6:.1f} MB)")
    except LecternError as e:
        fail(e)


@audition_app.command("apply")
def audition_apply(line: str):
    """Write a picks line from the audition page into voices.yaml and the course terms."""
    from .audition import apply_picks

    try:
        ctx = Ctx()
        for change in apply_picks(ctx.house, ctx.paths.root / (ctx.course.terms or "terms.yaml"), line):
            typer.echo(change)
    except LecternError as e:
        fail(e)


def main():  # pragma: no cover
    try:
        app()
    except LecternError as e:
        typer.secho(str(e), fg=typer.colors.RED, err=True)
        sys.exit(1)


if __name__ == "__main__":  # pragma: no cover
    main()
