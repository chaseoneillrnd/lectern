"""site: the pages a course gets beside its lessons.

The course page lists the lessons in skeleton order, with length, what to watch first and whether each is current, and
opens on the CourseMap: click a component to open the lesson that covers it. The glossary page lists every term the
lessons define, from the same registry that drives pronunciation and chips.
"""
from __future__ import annotations

import json
from pathlib import Path

import yaml

from .config import CourseManifest, House, load_yaml
from .paths import CoursePaths
from .script import front_matter

TYPE_LABEL = {"quickstart": "Quick start", "map": "Map", "drilldown": "Drilldown", "recipe": "Recipe"}
FLOOR_NAMES = {"python": "Python", "git": "Git", "terminal": "the terminal", "docker": "Docker", "linux": "Linux",
               "sql": "SQL", "aws": "AWS", "kubernetes": "Kubernetes", "javascript": "JavaScript", "bash": "Bash"}


def course_url(course_id: str) -> str:
    return f"/academy/{course_id}/"


def lesson_url(course_id: str, lesson_id: str) -> str:
    return f"/academy/{course_id}/{lesson_id}"


def _front(paths: CoursePaths, lesson_id: str) -> dict:
    p = paths.lesson_script(lesson_id)
    if not p.exists():
        return {}
    parts = front_matter(p.read_text(encoding="utf-8"))
    return (yaml.safe_load(parts[0]) or {}) if parts else {}


def _mmss(ms: float) -> str:
    s = int(round(ms / 1000))
    return f"{s // 60}:{s % 60:02d}"


def lesson_rows(paths: CoursePaths, course: CourseManifest) -> list[dict]:
    """One row per lesson in skeleton order: what it is, how long, what to watch first, and where it stands."""
    from .gates import gate_state, render_problem
    from .preview import lesson_order
    from .stale import lesson_flag

    rows = []
    for lid in lesson_order(course):
        front = _front(paths, lid)
        dist = paths.dist_dir(course.id, lid)
        built = (dist / "page.md").exists() and (dist / "timeline.json").exists()
        row = {"id": lid, "title": front.get("title", lid), "type": front.get("type", ""), "built": built,
               "url": lesson_url(course.id, lid) if built else None,
               "minutes": _mmss(json.loads((dist / "timeline.json").read_text())["duration_ms"]) if built else None,
               "prerequisites": list(front.get("prerequisites") or []), "component": front.get("component")}
        if not built:
            row["status"] = "Not built yet"
        elif (flag := lesson_flag(paths, lid)):
            row["status"] = "May be out of date: " + (flag if isinstance(flag, str) else "a pinned source changed")
        elif gate_state(paths, course.id, lid)["two"]["approved"]:
            row["status"] = "Current"
        else:
            problem = render_problem(paths, course.id, lid)
            row["status"] = "In review" + (" (rebuild needed)" if problem and "changed" in problem else "")
        rows.append(row)
    return rows


def map_links(paths: CoursePaths, course: CourseManifest, rows: list[dict]) -> dict[str, dict]:
    """Where each component goes: its drilldown when one is built, else its chapter in the Map lesson."""
    links: dict[str, dict] = {}
    by_id = {r["id"]: r for r in rows}
    for lid in course.skeleton.drilldowns:
        r = by_id.get(lid)
        if r and r["built"] and r["component"] and r["component"] not in links:
            links[r["component"]] = {"link": r["url"], "title": r["title"], "short": r["title"]}
    m = course.skeleton.map
    if m and by_id.get(m, {}).get("built"):
        timeline = json.loads((paths.dist_dir(course.id, m) / "timeline.json").read_text())
        plan_f = paths.build_dir(m) / "plan.json"
        comps = {s["id"]: s.get("component") for s in json.loads(plan_f.read_text())["scenes"]} if plan_f.exists() else {}
        for sc in timeline["scenes"]:
            comp = comps.get(sc["id"]) or (sc.get("params") or {}).get("component")
            if comp and comp not in links:
                title = (sc.get("params") or {}).get("title") or sc["id"]
                links[comp] = {"link": f"{by_id[m]['url']}#{sc['id']}", "title": f"{by_id[m]['title']} · {title}",
                               "short": title}
    return links


def course_map(paths: CoursePaths, course: CourseManifest, house: House, rows: list[dict]) -> dict | None:
    if not course.map:
        return None
    from .coursemap import load_map, site_map

    spec = load_map(paths, course)
    data = site_map(spec, house.tokens)
    links = map_links(paths, course, rows)
    labels = {n["id"]: " · ".join(str(n["label"]).split("\n")) for n in spec["nodes"]}
    for n in data["nodes"]:
        n["label"] = labels[n["id"]]
        n.update(links.get(n["id"], {"link": None, "title": None, "short": None}))
    return data


def course_page(paths: CoursePaths, course: CourseManifest, house: House) -> str:
    rows = lesson_rows(paths, course)
    titles = {r["id"]: r for r in rows}
    cmap = course_map(paths, course, house, rows)
    fm = {"title": course.title, "outline": [2, 2],
          "lectern": {"generated": True, "page": "course", "course": {"id": course.id, "title": course.title},
                      **({"map": cmap} if cmap else {})}}
    body = ["<!-- Generated by `lectern site` from course.yaml, map.yaml and the built lessons. Do not edit: the next "
            "run overwrites this page. -->", "", f"# {course.title}", ""]
    if cmap:
        body += ["<CourseMap />", ""]
    body += ["## Lessons {#lessons}", "", "Watch them in this order.", "",
             "| | Lesson | Type | Length | Watch first | Status |", "| --- | --- | --- | --- | --- | --- |"]
    for i, r in enumerate(rows, 1):
        name = f"[{r['title']}]({r['url']})" if r["url"] else r["title"]
        first = ", ".join(f"[{titles[p]['title']}]({titles[p]['url']})" if p in titles and titles[p]["url"] else
                          (titles[p]["title"] if p in titles else p) for p in r["prerequisites"])
        body.append(f"| {i} | {name} | {TYPE_LABEL.get(r['type'], r['type'])} | {r['minutes'] or ''} | {first} | "
                    f"{r['status']} |")
    body += ["", "## Before this course {#before}", ""]
    names = [FLOOR_NAMES.get(f.lower(), f) for f in course.floor]
    floor = ", ".join(names[:-1]) + (" and " if len(names) > 1 else "") + (names[-1] if names else "")
    body.append(f"You should already be comfortable with {floor}." if course.floor else "No background assumed.")
    if course.prerequisites:
        body += ["", "Finish these courses first: " + ", ".join(f"[{c}]({course_url(c)})" for c in course.prerequisites) + "."]
    body += ["", "## Glossary {#glossary}", "",
             f"[Every term the lessons define]({course_url(course.id)}glossary), with what it means and how the narrator "
             "says it.", ""]
    return "---\n" + yaml.safe_dump(fm, sort_keys=False, allow_unicode=True, width=1000) + "---\n\n" + "\n".join(body)


def glossary_terms(paths: CoursePaths, course: CourseManifest, house: House) -> list[dict]:
    """Every defined term a built lesson uses, plus every defined course term, with the lessons that use it."""
    from .preview import lesson_order
    from .terms import Registry

    registry = Registry.load(house.terms, paths.root / (course.terms or "terms.yaml"))
    course_terms = load_yaml(paths.root / (course.terms or "terms.yaml")) if (paths.root / (course.terms or "terms.yaml")).exists() else {}
    used: dict[str, list[str]] = {}
    for lid in lesson_order(course):
        plan_f = paths.build_dir(lid) / "plan.json"
        if plan_f.exists() and (paths.dist_dir(course.id, lid) / "page.md").exists():
            for key in json.loads(plan_f.read_text()).get("terms", {}):
                used.setdefault(key, []).append(lid)
    out = []
    for key, t in registry.entries.items():
        if not t.define or (key not in used and key not in (course_terms or {})):
            continue
        said = t.say if t.say and t.say.lower() != t.term.lower() else None
        out.append({"key": key, "term": t.term, "define": t.define, "said": said, "lessons": used.get(key, [])})
    return sorted(out, key=lambda x: x["term"].lower().lstrip("."))


def glossary_page(paths: CoursePaths, course: CourseManifest, house: House) -> str:
    terms = glossary_terms(paths, course, house)
    rows = {r["id"]: r for r in lesson_rows(paths, course)}

    def cell(text: str) -> str:
        return text.replace("|", "\\|").replace("\n", " ")

    fm = {"title": f"Glossary · {course.title}", "outline": False,
          "lectern": {"generated": True, "page": "glossary", "course": {"id": course.id, "title": course.title}}}
    body = ["<!-- Generated by `lectern site` from the terms registry. Do not edit: the next run overwrites this page. -->",
            "", "# Glossary", "", f"Every term [{course.title}]({course_url(course.id)}) defines, in one place. Each lesson "
            "page explains a term where it first comes up.", "", "| Term | Meaning | Said | Used in |",
            "| --- | --- | --- | --- |"]
    for t in terms:
        lessons = "<br>".join(f"[{rows[x]['title']}]({rows[x]['url']})" for x in t["lessons"] if x in rows and rows[x]["url"])
        body.append(f'| <span id="{t["key"]}"></span>**{cell(t["term"])}** | {cell(t["define"])} | '
                    f'{cell(t["said"]) if t["said"] else ""} | {lessons} |')
    return "---\n" + yaml.safe_dump(fm, sort_keys=False, allow_unicode=True, width=1000) + "---\n\n" + "\n".join(body) + "\n"


def write_site(paths: CoursePaths, course: CourseManifest, house: House) -> list[Path]:
    out = paths.dist / course.id
    out.mkdir(parents=True, exist_ok=True)
    pages = {"index.md": course_page(paths, course, house), "glossary.md": glossary_page(paths, course, house)}
    written = []
    for name, text in pages.items():
        (out / name).write_text(text, encoding="utf-8")
        written.append(out / name)
    return written
