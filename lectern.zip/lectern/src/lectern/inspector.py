"""The frame inspector's input and output: one item per contact-sheet frame, with what that frame should show.

The frame-inspector agent looks at each frame for collisions, overflow and unreadable text, and checks that every
accent lands on what its cue names. It advises and never gates. Like the claims judge, it is calibrated first, on
planted frames where the answer is known.
"""
from __future__ import annotations

import hashlib
import json

from .config import House, load_yaml
from .paths import CoursePaths, LecternError

KINDS = ("collision", "overflow", "unreadable", "wrong-target", "other")
SEVERITIES = ("major", "minor")


def _target_hint(paths: CoursePaths, scene: dict, target: str | None) -> str:
    """For a browser target, the locator the capture found it by, so the inspector knows what to look for."""
    if not target or scene.get("layout") != "steps":
        return target or ""
    from .steps import load_capture

    cap_id = (scene.get("steps") or {}).get("capture")
    spec_p = paths.capture_scripts / f"{cap_id}.yaml"
    if not cap_id or not spec_p.exists():
        return target
    spec = load_yaml(spec_p)
    found = (spec.get("targets") or {}).get(target)
    for step in spec.get("steps", []):
        found = found or (step.get("targets") or {}).get(target)
        if step.get("as") == target:
            found = found or next((step[a] for a in ("click", "type", "fill", "press", "hover") if a in step), None)
    if isinstance(found, dict):
        desc = " ".join(f"{k} {v!r}" for k, v in found.items() if k in ("role", "name", "label", "text", "placeholder"))
        return f"{target} ({desc})"
    load_capture(paths, cap_id)  # raises a clear error when the capture is missing
    return target


def expectation(paths: CoursePaths, shot: dict, scene: dict, terms: dict) -> str:
    """What the frame should show, in a sentence."""
    moment, layout = shot.get("moment"), shot.get("layout")
    if moment == "opens":
        return f"The {layout} scene has just opened. Check the whole layout."
    if moment == "countdown":
        return "A checkpoint question with a countdown ring. The answer is not shown yet."
    if moment == "answer":
        return "The checkpoint's answer card, under the question."
    verb, target, params = shot.get("verb"), shot.get("target"), shot.get("params") or {}
    hint = _target_hint(paths, scene, target)
    where = "On the course Map" if layout == "map" else "In the diagram"
    if verb == "light":
        return f"{where}, '{target}' is lit with the accent and the rest is dimmed."
    if verb == "trace":
        hops = params.get("hops") or []
        path = " -> ".join([hops[0]["from"], *(h["to"] for h in hops)]) if hops else target
        return (f"{where}, the path {path} is lit with the accent, its arrows included, and the rest is dimmed. "
                "The moving dot has arrived and is hidden under the last box.")
    if verb == "pulse":
        return f"'{hint}' pulses once to draw the eye."
    if verb == "callout":
        return f"A callout reading \"{params.get('text', '')}\" points at {hint}."
    if verb == "chip":
        term = terms.get(target) or {}
        return f"A glossary chip for '{term.get('term', target)}' with its definition, not covering anything important."
    if verb == "lines":
        return f"Code lines {target} are highlighted and the other lines dimmed."
    if verb == "play" and layout == "cast":
        return "A terminal shows the command being run and its output."
    if verb == "play":
        return f"The browser has just done step '{target}': the cursor clicked or typed, and the page changed."
    if verb == "mark":
        return f"In the terminal, the text '{target}' is outlined with the accent, tightly, on the place it last appears."
    if verb == "zoom":
        return "The view zooms back out to the whole page." if target == "page" else f"The view is zoomed in on {hint}."
    if verb == "pan":
        return f"The zoomed view has moved to {hint}."
    if verb == "spotlight":
        return f"A spotlight frames {hint}, and the rest of the page is dimmed."
    if verb == "arrow":
        return f"An arrow points at {hint}."
    return f"{verb} on {target}"


def inspect_input(paths: CoursePaths, course_id: str, lesson_id: str, plan: dict) -> dict:
    dist = paths.dist_dir(course_id, lesson_id)
    sheet_p = dist / "review" / "contact-sheet.json"
    if not sheet_p.exists():
        raise LecternError(f"no contact sheet for {lesson_id}. Run `lectern build {lesson_id}` first")
    sheet = json.loads(sheet_p.read_text())
    timeline = json.loads((paths.build_dir(lesson_id) / "timeline.json").read_text())
    scenes = {s["id"]: s for s in timeline["scenes"]}
    frames_dir = paths.build_dir(lesson_id) / "frames"
    items = []
    for i, shot in enumerate(sheet):
        if "scene" not in shot:
            raise LecternError("the contact sheet predates frame inspection. Rebuild the lesson")
        items.append({"item": f"f{i:03d}", "image": str(frames_dir / shot["png"]), "time": shot.get("time"),
                      "scene": shot["scene"], "layout": shot["layout"], "span": shot.get("span", ""),
                      "expect": expectation(paths, shot, scenes[shot["scene"]], plan.get("terms", {}))})
    mp4 = dist / "lesson.mp4"
    return {"lesson": lesson_id, "mp4": hashlib.sha256(mp4.read_bytes()).hexdigest()[:16], "items": items}


def bundle_sha(bundle: dict) -> str:
    return hashlib.sha256(json.dumps(bundle, sort_keys=True).encode()).hexdigest()[:16]


def validate_inspection(output: dict, bundle: dict) -> dict:
    """One verdict per frame, issues with a known kind and severity, nothing invented."""
    frames = output.get("frames")
    if not isinstance(frames, list):
        raise LecternError("inspection output needs a `frames` list")
    wanted = [i["item"] for i in bundle["items"]]
    got = [f.get("item") for f in frames]
    if sorted(got) != sorted(wanted) or len(set(got)) != len(got):
        missing, extra = sorted(set(wanted) - set(got)), sorted(set(got) - set(wanted))
        raise LecternError(f"inspection must cover every frame once. Missing: {missing or 'none'}. "
                           f"Unknown or repeated: {extra or [g for g in got if got.count(g) > 1] or 'none'}")
    clean = []
    for f in frames:
        issues = []
        for issue in f.get("issues") or []:
            if issue.get("kind") not in KINDS or issue.get("severity") not in SEVERITIES:
                raise LecternError(f"{f['item']}: issue kind must be one of {', '.join(KINDS)} and severity major "
                                   f"or minor, got {issue.get('kind')!r} {issue.get('severity')!r}")
            issues.append({"kind": issue["kind"], "severity": issue["severity"],
                           "note": str(issue.get("note", ""))[:400]})
        verdict = "issue" if any(i["severity"] == "major" for i in issues) else "ok"
        clean.append({"item": f["item"], "verdict": verdict, "issues": issues})
    order = {k: n for n, k in enumerate(wanted)}
    clean.sort(key=lambda f: order[f["item"]])
    return {"frames": clean, "summary": str(output.get("summary", ""))[:600], "bundle_sha": bundle_sha(bundle),
            "mp4": bundle.get("mp4")}


def calibration_bundle(house: House) -> tuple[dict, dict]:
    """Planted frames from the house package: some clean, some with one known defect each."""
    root = house.root / "inspect-calibration"
    spec = load_yaml(root / "frames.yaml")
    items, expect = [], {}
    for i, f in enumerate(spec["frames"]):
        item = f"c{i:02d}"
        items.append({"item": item, "image": str(root / f["file"]), "time": "0:00", "scene": f.get("scene", "calibration"),
                      "layout": f.get("layout", ""), "span": f.get("span", ""), "expect": f["expect"]})
        expect[item] = f.get("defect")
    return {"lesson": "calibration", "items": items}, expect


def score_calibration(result: dict, expect: dict) -> list[str]:
    misses = []
    for f in result["frames"]:
        defect = expect.get(f["item"])
        majors = {i["kind"] for i in f["issues"] if i["severity"] == "major"}
        if defect and not majors:
            misses.append(f"{f['item']}: planted {defect} went unflagged")
        elif not defect and majors:
            misses.append(f"{f['item']}: a clean frame was flagged major ({', '.join(sorted(majors))})")
    return misses
