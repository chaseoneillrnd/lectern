"""Where Lectern finds the house package, the course, its caches and its outputs."""
from __future__ import annotations

import os
from pathlib import Path

PACKAGE_DIR = Path(__file__).resolve().parent
TOOL_ROOT = Path(os.environ.get("LECTERN_TOOL_ROOT", PACKAGE_DIR.parents[1]))


class LecternError(Exception):
    """A user-facing failure: printed without a traceback."""


def house_dir() -> Path:
    """The house package. LECTERN_HOUSE points at a copy when the shipped one should stay untouched."""
    return Path(os.environ.get("LECTERN_HOUSE", PACKAGE_DIR / "house"))


def node_root() -> Path:
    """Where node_modules lives (HyperFrames, GSAP, asciinema-player, fonts, Shiki)."""
    return Path(os.environ.get("LECTERN_NODE_ROOT", TOOL_ROOT))


def node_bin(name: str) -> Path:
    return node_root() / "node_modules" / ".bin" / name


def machine_profile_path() -> Path:
    return Path(os.environ.get("LECTERN_MACHINE", Path.home() / ".lectern" / "machine.yaml"))


def find_course_root(start: Path | None = None) -> Path:
    here = (start or Path.cwd()).resolve()
    for candidate in [here, *here.parents]:
        if (candidate / "course.yaml").exists():
            return candidate
    raise LecternError(f"No course.yaml found in {here} or any parent. Run `lectern wizard course` to start one.")


class CoursePaths:
    """All paths inside one course checkout."""

    def __init__(self, root: Path):
        self.root = root
        self.state = root / ".lectern"
        self.cache = self.state / "cache"
        self.tts_cache = self.cache / "tts"
        self.scene_cache = self.cache / "scenes"
        self.highlight_cache = self.cache / "highlight"
        self.sources = self.state / "sources"
        self.build = self.state / "build"
        self.lessons = root / "lessons"
        self.diagrams = root / "diagrams"
        self.capture_scripts = root / "capture"
        self.captures = root / "captures"
        self.dist = root / "dist"

    def lesson_script(self, lesson_id: str) -> Path:
        return self.lessons / f"{lesson_id}.md"

    def claims_ledger(self, lesson_id: str) -> Path:
        return self.lessons / f"{lesson_id}.claims.yaml"

    def build_dir(self, lesson_id: str) -> Path:
        return self.build / lesson_id

    def dist_dir(self, course_id: str, lesson_id: str) -> Path:
        return self.dist / course_id / lesson_id

    def ensure(self) -> None:
        for d in (self.tts_cache, self.scene_cache, self.highlight_cache, self.sources, self.build):
            d.mkdir(parents=True, exist_ok=True)
