"""map check: prove every lesson draws the same Map.

Each built lesson's map scenes are photographed at the moment they settle, before any cue moves, in the browser the
renderer uses. Every photo must match a reference still of the Map in the same state: plain, or opening with one
component lit. The packaged MP4s are compared too, at the same frames.
"""
from __future__ import annotations

import functools
import hashlib
import http.server
import json
import shutil
import subprocess
import threading
from pathlib import Path

import numpy as np
from PIL import Image

from .config import CourseManifest, House
from .paths import CoursePaths, LecternError

SETTLED_MIN = 0.5   # s: the stage has faded in and an opening light has finished
SETTLED_MAX = 0.95  # s: the timeline holds every cue until a scene has settled for a second


def settled_at(scene: dict, fps: int) -> float:
    """When a map scene is at rest, after its entrance and before its first cue, on the frame grid."""
    first = min((c["t"] for c in scene["cues"] if c["verb"] != "play"), default=None)
    t = SETTLED_MAX if first is None else min(SETTLED_MAX, first - 0.1)
    t = max(SETTLED_MIN, min(t, scene["frames"] / fps - 0.1))
    return round(int(t * fps) / fps, 4)


def write_composition(folder: Path, html: str, assets: dict[str, Path]) -> None:
    if folder.exists():
        shutil.rmtree(folder)
    folder.mkdir(parents=True)
    (folder / "index.html").write_text(html, encoding="utf-8")
    for name, src in assets.items():
        dst = folder / name
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, dst)


class _Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *args):  # noqa: D401 - the check prints its own summary
        pass


class Photographer:
    """Seeks a composition's GSAP timeline and screenshots the frame, in the renderer's own browser."""

    def __init__(self, root: Path, width: int, height: int):
        self.root, self.width, self.height = root, width, height

    def __enter__(self):
        from playwright.sync_api import sync_playwright

        from .render import browser_id

        handler = functools.partial(_Quiet, directory=str(self.root))
        self.server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), handler)
        threading.Thread(target=self.server.serve_forever, daemon=True).start()
        self.pw = sync_playwright().start()
        exe = browser_id()
        try:
            self.browser = self.pw.chromium.launch(headless=True, **({"executable_path": exe} if Path(exe).is_file() else {}))
        except Exception:
            self.browser = self.pw.chromium.launch(headless=True)
        self.page = self.browser.new_page(viewport={"width": self.width, "height": self.height}, device_scale_factor=1)
        self.page.add_init_script("window.__timelines = {};")
        return self

    def shoot(self, rel: str, t: float, out: Path) -> str:
        port = self.server.server_address[1]
        self.page.goto(f"http://127.0.0.1:{port}/{rel}/index.html", wait_until="load")
        self.page.evaluate("document.fonts.ready.then(() => true)")
        # seek() returns the timeline itself, so return nothing: serialising GSAP's object graph never finishes.
        self.page.evaluate(f"() => {{ window.__timelines.scene.seek({t}, false); }}")
        self.page.screenshot(path=str(out), animations="disabled")
        return pixel_hash(out)

    def __exit__(self, *exc):
        self.browser.close()
        self.pw.stop()
        self.server.shutdown()


def pixel_hash(png: Path) -> str:
    return hashlib.sha256(np.asarray(Image.open(png).convert("RGB")).tobytes()).hexdigest()


def video_frame(mp4: Path, at_s: float, out: Path) -> bool:
    p = subprocess.run(["ffmpeg", "-v", "error", "-y", "-ss", f"{at_s:.4f}", "-i", str(mp4), "-frames:v", "1", str(out)],
                       capture_output=True)
    return p.returncode == 0 and out.exists()


def psnr(a: Path, b: Path) -> float:
    x = np.asarray(Image.open(a).convert("RGB"), dtype=np.float64)
    y = np.asarray(Image.open(b).convert("RGB"), dtype=np.float64)
    mse = float(np.mean((x - y) ** 2))
    return float("inf") if mse == 0 else round(10 * np.log10(255.0 ** 2 / mse), 2)


def reference_scene(spec: dict, component: str | None, house: House, paths: CoursePaths, W: int, H: int, fps: int):
    """A one-scene lesson that only draws the Map, so the photo shows what map.yaml alone produces."""
    from .render import SceneComposer

    scene = {"id": "map", "layout": "map", "params": {}, "frames": fps * 2, "cues": [], "sentences": []}
    pscene = {"id": "map", "layout": "map", "map": spec, **({"component": component} if component else {})}
    plan = {"scenes": [pscene], "lesson": {"id": "map-reference", "front": {}}, "course": {"id": "", "title": ""}}
    timeline = {"lesson": "map-reference", "width": W, "height": H, "fps": fps, "scenes": [scene], "duration_ms": 2000}
    return SceneComposer(paths, house, plan, timeline, {}).compose(scene)


def map_check(paths: CoursePaths, course: CourseManifest, house: House, log=print) -> dict:
    from .coursemap import load_map, map_hash
    from .preview import lesson_order

    spec = load_map(paths, course)
    current = map_hash(paths, course)
    work = paths.state / "map-check"
    if work.exists():
        shutil.rmtree(work)
    (work / "comp").mkdir(parents=True)
    report: dict = {"map": spec["_path"], "hash": current, "lessons": {}, "states": {}, "problems": [], "notes": []}
    known = lesson_order(course) + sorted(p.stem for p in paths.lessons.glob("*.md")
                                          if not p.stem.endswith(".claims") and p.stem not in lesson_order(course))
    todo = []
    for lid in known:
        build = paths.build_dir(lid)
        if not (build / "plan.json").exists() or not (build / "timeline.json").exists():
            continue
        plan = json.loads((build / "plan.json").read_text())
        if not plan.get("map"):
            continue
        timeline = json.loads((build / "timeline.json").read_text())
        pscenes = {s["id"]: s for s in plan["scenes"]}
        if plan["map"]["hash"] != current:
            report["problems"].append(f"{lid}: built against an older map.yaml. Rebuild it with `lectern build {lid}`")
        rec = paths.dist_dir(course.id, lid) / "build.json"
        if rec.exists() and (json.loads(rec.read_text()).get("map") or {}).get("hash") not in (None, current):
            report["problems"].append(f"{lid}: its packaged MP4 draws an older Map. Rebuild it")
        report["lessons"][lid] = []
        for sc in timeline["scenes"]:
            if sc["layout"] != "map":
                continue
            comp = build / "scenes" / sc["id"]
            if not (comp / "index.html").exists():
                report["problems"].append(f"{lid}/{sc['id']}: not rendered yet. Run `lectern build {lid}`")
                continue
            todo.append((lid, sc, pscenes[sc["id"]].get("component"), comp, timeline))
    if not todo:
        raise LecternError("no built lesson draws the Map yet. Add a layout=map scene and build it")

    W, H, fps = todo[0][4]["width"], todo[0][4]["height"], todo[0][4]["fps"]
    states = sorted({c or "" for _, _, c, _, _ in todo})
    for st in states:
        html, assets = reference_scene(spec, st or None, house, paths, W, H, fps)
        write_composition(work / "comp" / f"ref-{st or 'plain'}", html, assets)
    for lid, sc, compo, comp, _ in todo:
        shutil.copytree(comp, work / "comp" / f"{lid}--{sc['id']}")

    with Photographer(work / "comp", W, H) as cam:
        refs = {}
        for st in states:
            name = f"ref-{st or 'plain'}"
            refs[st] = cam.shoot(name, round(int(SETTLED_MAX * fps) / fps, 4), work / f"{name}.png")
            report["states"][st or "plain"] = {"reference": f"{name}.png", "hash": refs[st], "scenes": []}
        for lid, sc, compo, comp, timeline in todo:
            t = settled_at(sc, fps)
            name = f"{lid}--{sc['id']}"
            h = cam.shoot(name, t, work / f"{name}.png")
            entry = {"lesson": lid, "scene": sc["id"], "at": t, "hash": h, "same": h == refs[compo or ""]}
            mp4 = paths.dist_dir(course.id, lid) / "lesson.mp4"
            frame = work / f"{name}.mp4frame.png"
            if mp4.exists() and video_frame(mp4, sc["start_ms"] / 1000 + t + 0.5 / fps, frame):
                entry["mp4_psnr_vs_reference"] = psnr(frame, work / f"ref-{compo or 'plain'}.png")
            report["lessons"][lid].append(entry)
            report["states"][compo or "plain"]["scenes"].append(f"{lid}/{sc['id']}")
            if not entry["same"]:
                report["problems"].append(f"{lid}/{sc['id']}: the Map differs from the reference at {t:.2f} s. "
                                          f"Compare {name}.png with ref-{compo or 'plain'}.png in {work}")
    # Frames from different MP4s of the same state, side by side: lossy encoding may move a few pixel values.
    for st, info in report["states"].items():
        frames = [work / f"{s.replace('/', '--')}.mp4frame.png" for s in info["scenes"]]
        frames = [f for f in frames if f.exists()]
        info["mp4_min_psnr_between_lessons"] = min((psnr(a, b) for i, a in enumerate(frames) for b in frames[i + 1:]),
                                                   default=None)
    report["ok"] = not report["problems"]
    (work / "report.json").write_text(json.dumps(report, indent=1))
    n = sum(len(v) for v in report["lessons"].values())
    log(f"map check: {n} map scenes in {len(report['lessons'])} lessons, {len(states)} states, "
        + ("every one identical to its reference" if report["ok"] else f"{len(report['problems'])} problems"))
    return report


def map_still(paths: CoursePaths, course: CourseManifest, house: House, out: Path, component: str | None = None,
              W: int = 1920, H: int = 1080, fps: int = 30) -> Path:
    """One frame of the Map as a lesson would show it, with no lesson built: for checking a draft by eye."""
    from .coursemap import load_map

    spec = load_map(paths, course)
    if component and component not in {n["id"] for n in spec["nodes"]}:
        raise LecternError(f"{component} is not on the Map")
    work = paths.state / "map-still"
    html, assets = reference_scene(spec, component, house, paths, W, H, fps)
    write_composition(work / "comp", html, assets)
    with Photographer(work, W, H) as cam:
        cam.shoot("comp", round(int(SETTLED_MAX * fps) / fps, 4), out)
    return out
