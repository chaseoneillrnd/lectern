// Highlight code with Shiki (VS Code grammars), so code on screen looks like the editor.
// stdin: {"code": "...", "lang": "python", "theme": "dark-plus"}
// stdout: [[["token text", "#color", fontStyle], ...], ...] one array per line
import { codeToTokens } from "shiki";

let raw = "";
for await (const chunk of process.stdin) raw += chunk;
const input = JSON.parse(raw);
const { tokens } = await codeToTokens(input.code, { lang: input.lang, theme: input.theme || "dark-plus" });
process.stdout.write(JSON.stringify(tokens.map((line) => line.map((t) => [t.content, t.color || null, t.fontStyle || 0]))));
