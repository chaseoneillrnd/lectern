"""Four config layers: house package, course manifest, lesson front matter, CLI flags.

Later layers win. `explain` reports the whole chain for one key and names the winner.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

import yaml
from pydantic import BaseModel, ConfigDict, Field, ValidationError

from .paths import LecternError, house_dir, machine_profile_path

LAYERS = ("house", "course", "lesson", "cli")
CONFIG_KEYS = {"cap_minutes", "cap_reason", "fidelity", "quality", "loudness_lufs", "true_peak_db",
               "title_seconds", "captions", "rung", "video.width", "video.height", "video.fps"}
MISSING = object()


# ----------------------------------------------------------------------------- loading


def load_yaml(path: Path) -> Any:
    try:
        return yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except FileNotFoundError:
        raise LecternError(f"Missing file: {path}") from None
    except yaml.YAMLError as e:
        raise LecternError(f"{path}: invalid YAML: {e}") from None


def flatten(d: dict, prefix: str = "") -> dict:
    out = {}
    for k, v in (d or {}).items():
        key = f"{prefix}{k}"
        if isinstance(v, dict):
            out.update(flatten(v, key + "."))
        else:
            out[key] = v
    return out


class House:
    """The house package: defaults, tokens, voices, motion vocabulary, terms and questions."""

    def __init__(self, root: Path | None = None):
        self.root = root or house_dir()
        self.config = load_yaml(self.root / "config.yaml")
        self.tokens = json.loads((self.root / "tokens.json").read_text())
        self.voices = load_yaml(self.root / "voices.yaml")
        self.motion = load_yaml(self.root / "motion.yaml")
        self.terms = load_yaml(self.root / "terms.yaml")
        self.questions = load_yaml(self.root / "questions.yaml")

    def question(self, key: str) -> dict | None:
        return next((q for q in self.questions if q["key"] == key), None)

    def version_hash(self) -> str:
        """Changes whenever anything that shapes a frame changes."""
        import hashlib

        h = hashlib.sha256()
        for name in ("tokens.json", "motion.yaml", "config.yaml"):
            h.update((self.root / name).read_bytes())
        for p in sorted((self.root / "templates").glob("*")):
            h.update(p.name.encode())
            h.update(p.read_bytes())
        return h.hexdigest()[:16]


# ----------------------------------------------------------------------------- course manifest


class SourcePin(BaseModel):
    model_config = ConfigDict(extra="forbid")
    repo: str = Field(description="git URL, or a path relative to the course root, such as a sibling stack repo")
    ref: str = Field(description="tag or branch the course teaches")
    commit: str | None = Field(default=None, description="commit the ref resolved to when pinned")
    docs: str | None = Field(default=None, description="public docs base URL for links on the page")
    web: str | None = Field(default=None, description="browsable repo URL for claim links, when repo is not one")
    clone: str | None = Field(default=None, description="URL teammates clone from, for lesson pages, when repo is not one")


class PinSpec(BaseModel):
    """A library pin that `lectern stale` can check for newer releases."""
    model_config = ConfigDict(extra="forbid")
    version: str
    pypi: str | None = Field(default=None, description="PyPI project name")
    npm: str | None = Field(default=None, description="npm package name")
    github: str | None = Field(default=None, description="owner/repo whose GitHub releases to watch")


class Skeleton(BaseModel):
    model_config = ConfigDict(extra="forbid")
    quickstart: str | None = None
    map: str | None = None
    drilldowns: list[str] = []
    recipes: list[str] = []


class CourseManifest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    id: str
    title: str
    kind: Literal["stack", "topic"]
    floor: list[str] = []
    prerequisites: list[str] = []
    sources: dict[str, SourcePin] = {}
    pins: dict[str, str | PinSpec] = {}
    skeleton: Skeleton = Skeleton()
    map: str | None = None
    tts_cache: str | None = Field(default=None, description="narration cache: a path in the course to commit with Git "
                                                            "LFS, or an absolute path such as a render server's")
    terms: str | None = "terms.yaml"
    owner: str | None = None
    defaults: dict = {}

    def pin_version(self, name: str) -> str | None:
        pin = self.pins.get(name)
        return pin.version if isinstance(pin, PinSpec) else pin

    def pin_versions(self) -> dict[str, str]:
        return {k: self.pin_version(k) for k in self.pins}


def load_course(root: Path) -> CourseManifest:
    data = load_yaml(root / "course.yaml")
    try:
        return CourseManifest.model_validate(data)
    except ValidationError as e:
        raise LecternError(f"course.yaml is invalid:\n{e}") from None


# ----------------------------------------------------------------------------- validation


RUNGS = ["eli5", "foundations", "practitioner", "expert", "internals"]


def validate_value(key: str, value: Any, house: House) -> Any:
    """Validate one value against its questions.yaml rule. Returns the coerced value."""
    q = house.question(key)
    rule = (q or {}).get("validate")
    if not rule:
        return value
    kind = rule.get("type")
    try:
        if kind == "int":
            v = int(value)
            if ("min" in rule and v < rule["min"]) or ("max" in rule and v > rule["max"]):
                raise ValueError(f"must be between {rule.get('min')} and {rule.get('max')}")
            return v
        if kind == "float":
            v = float(value)
            if ("min" in rule and v < rule["min"]) or ("max" in rule and v > rule["max"]):
                raise ValueError(f"must be between {rule.get('min')} and {rule.get('max')}")
            return v
        if kind == "choice":
            if value not in rule["choices"]:
                raise ValueError(f"must be one of {', '.join(map(str, rule['choices']))}")
            return value
        if kind == "slug":
            if not re.fullmatch(r"[a-z0-9][a-z0-9.-]*", str(value)):
                raise ValueError("use lowercase letters, digits, dots and dashes")
            return value
        if kind == "voice":
            if not re.fullmatch(r"[abjzefhip][fm]_[a-z]+", str(value)):
                raise ValueError("expected a Kokoro voice ID such as af_heart")
            return value
        if kind == "list":
            items = value if isinstance(value, list) else str(value).split(",")
            items = [str(x).strip() for x in items if str(x).strip()]
            if not items:
                raise ValueError("give at least one item, comma-separated")
            return items
        if kind == "sources":
            items = value if isinstance(value, list) else str(value).split(",")
            items = [str(x).strip() for x in items if str(x).strip()]
            for item in items:
                if not re.fullmatch(r"[a-z0-9][a-z0-9_-]*=\S+@[^@\s]+", item):
                    raise ValueError(f"{item!r}: expected name=repo@ref, such as "
                                     "ragas=https://github.com/explodinggradients/ragas.git@v0.4.3")
            if not items:
                raise ValueError("give at least one source")
            return items
        if kind == "text":
            if not str(value).strip():
                raise ValueError("cannot be empty")
            words = len(str(value).split())
            if "max_words" in rule and words > rule["max_words"]:
                raise ValueError(f"keep it to {rule['max_words']} words or fewer, got {words}")
            return value
        return value
    except (TypeError, ValueError) as e:
        raise LecternError(f"{key}={value!r}: {e}") from None


# ----------------------------------------------------------------------------- layering


@dataclass
class Effective:
    layers: dict[str, dict] = field(default_factory=dict)  # layer -> flattened config
    values: dict[str, Any] = field(default_factory=dict)
    winner: dict[str, str] = field(default_factory=dict)

    def __getitem__(self, key: str) -> Any:
        return self.values[key]

    def get(self, key: str, default: Any = None) -> Any:
        return self.values.get(key, default)

    def chain(self, key: str) -> list[tuple[str, Any]]:
        return [(layer, self.layers.get(layer, {}).get(key, MISSING)) for layer in LAYERS]


def lesson_config_layer(front: dict) -> dict:
    flat = flatten(front)
    return {k: v for k, v in flat.items() if k in CONFIG_KEYS}


def resolve(house: House, course: CourseManifest | None = None, front: dict | None = None,
            cli: dict | None = None) -> Effective:
    eff = Effective()
    eff.layers["house"] = flatten(house.config)
    eff.layers["course"] = flatten(course.defaults) if course else {}
    eff.layers["lesson"] = lesson_config_layer(front or {})
    eff.layers["cli"] = {k: v for k, v in (cli or {}).items() if v is not None}
    for layer in LAYERS:
        for k, v in eff.layers[layer].items():
            eff.values[k] = validate_value(k, v, house)
            eff.winner[k] = layer
    # A cap override needs its reason in the same layer.
    for layer in ("course", "lesson", "cli"):
        cap = eff.layers[layer].get("cap_minutes", MISSING)
        house_cap = eff.layers["house"].get("cap_minutes")
        if cap is not MISSING and cap != house_cap and not eff.layers[layer].get("cap_reason"):
            raise LecternError(f"{layer} sets cap_minutes={cap} without cap_reason. Overrides need a reason.")
    return eff


def explain(eff: Effective, key: str) -> str:
    lines = [f"{key}"]
    for layer, value in eff.chain(key):
        shown = "-" if value is MISSING else repr(value)
        mark = "  <- wins" if eff.winner.get(key) == layer else ""
        lines.append(f"  {layer:7} {shown}{mark}")
    if key not in eff.values:
        lines.append("  not set in any layer")
    return "\n".join(lines)


# ----------------------------------------------------------------------------- machine profile


def load_machine() -> dict:
    p = machine_profile_path()
    return load_yaml(p) if p.exists() else {}


def tts_cache_dir(root: Path, course: "CourseManifest") -> Path:
    """Where narration audio is cached. Kokoro's output varies by a few samples between CPU models, so every machine that
    builds a course should share one cache to keep its audio, and so its MP4, byte-identical.

    First match wins: LECTERN_TTS_CACHE, `tts_cache` in this machine's profile, `tts_cache` in course.yaml, then
    .lectern/cache/tts. A relative path is relative to the course, so a cache committed with Git LFS works.
    """
    import os

    for raw in (os.environ.get("LECTERN_TTS_CACHE"), load_machine().get("tts_cache"), course.tts_cache):
        if raw:
            p = Path(str(raw)).expanduser()
            return p if p.is_absolute() else root / p
    return root / ".lectern" / "cache" / "tts"


def save_machine(profile: dict) -> Path:
    p = machine_profile_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(yaml.safe_dump(profile, sort_keys=False))
    return p


# ----------------------------------------------------------------------------- comment-preserving writes


def set_yaml_key(path: Path, dotted: str, value: Any) -> None:
    """Set `a.b` style keys in a YAML file while keeping its comments and layout.

    Handles top-level keys and one level of nesting, which covers every key the wizard writes.
    """
    text = path.read_text(encoding="utf-8") if path.exists() else ""
    lines = text.splitlines()
    parts = dotted.split(".")
    rendered = yaml.safe_dump(value, default_flow_style=True, sort_keys=False).strip()
    if rendered.endswith("\n...") or rendered.endswith("..."):
        rendered = rendered.replace("\n...", "").replace("...", "").strip()

    def find(key: str, indent: int, start: int, end: int) -> int | None:
        pat = re.compile(rf"^{' ' * indent}{re.escape(key)}:(\s|$)")
        for i in range(start, end):
            if pat.match(lines[i]):
                return i
        return None

    def block_end(i: int, indent: int) -> int:
        j = i + 1
        while j < len(lines) and (not lines[j].strip() or lines[j].startswith(" " * (indent + 1)) or lines[j].lstrip().startswith("#")):
            j += 1
        return j

    def replace_value(i: int, indent: int, key: str) -> None:
        comment = ""
        m = re.search(r"\s+#.*$", lines[i])
        if m and not re.search(r"['\"]", lines[i][m.start():]):
            comment = m.group(0)
        lines[i] = f"{' ' * indent}{key}: {rendered}{comment}"

    if len(parts) == 1:
        i = find(parts[0], 0, 0, len(lines))
        if i is None:
            lines.append(f"{parts[0]}: {rendered}")
        else:
            replace_value(i, 0, parts[0])
    elif len(parts) == 2:
        i = find(parts[0], 0, 0, len(lines))
        if i is None:
            lines += [f"{parts[0]}:", f"  {parts[1]}: {rendered}"]
        else:
            end = block_end(i, 0)
            j = find(parts[1], 2, i + 1, end)
            if j is None:
                lines.insert(end, f"  {parts[1]}: {rendered}")
            else:
                replace_value(j, 2, parts[1])
    else:
        raise LecternError(f"Cannot write {dotted}: nesting deeper than two levels")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
