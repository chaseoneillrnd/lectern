"""preview: a minimal local VitePress site with the Lectern theme, so every page is seen as it will ship."""
from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path

import yaml

from .config import CourseManifest
from .package import media_path
from .paths import TOOL_ROOT, CoursePaths, LecternError, node_bin, node_root
from .script import front_matter

MEDIA = ("lesson.mp4", "lesson.vtt", "slides.pdf", "transcript.md", "poster.jpg")


def lesson_order(course: CourseManifest) -> list[str]:
    sk = course.skeleton
    order = [sk.quickstart, sk.map, *sk.drilldowns, *sk.recipes]
    return [x for x in order if x]


def build_site(paths: CoursePaths, course: CourseManifest, house=None) -> Path:
    from .config import House
    from .site import write_site

    site = paths.state / "preview"
    docs = site / "docs"
    if docs.exists():
        shutil.rmtree(docs)
    (docs / ".vitepress" / "theme").mkdir(parents=True)
    nm = site / "node_modules"
    target = node_root() / "node_modules"
    if nm.is_symlink() and nm.resolve() != target.resolve():
        nm.unlink()  # a link left by another install, such as the host's tool repo seen from inside the container
    if not nm.exists() and not nm.is_symlink():
        nm.symlink_to(target)

    built, rows = [], []
    for lesson_id in lesson_order(course):
        d = paths.dist_dir(course.id, lesson_id)
        page = d / "page.md"
        if not page.exists():
            rows.append(f"| {lesson_id} | not built yet | |")
            continue
        out = docs / "academy" / course.id / f"{lesson_id}.md"
        out.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(page, out)
        media = docs / "public" / media_path(course.id, lesson_id).strip("/")
        media.mkdir(parents=True, exist_ok=True)
        for f in MEDIA:
            if (d / f).exists():
                shutil.copyfile(d / f, media / f)
        parts = front_matter(page.read_text(encoding="utf-8"))
        if parts is None:
            raise LecternError(f"{page}: no front matter")
        fm = yaml.safe_load(parts[0])
        title, duration = fm["title"], fm["lectern"]["duration"]
        built.append({"text": title, "link": f"/academy/{course.id}/{lesson_id}"})
        rows.append(f"| [{title}](/academy/{course.id}/{lesson_id}) | {fm['lectern'].get('type', '')} | {duration} |")

    # The course page and the glossary, regenerated from what is built right now.
    course_dir = docs / "academy" / course.id
    course_dir.mkdir(parents=True, exist_ok=True)
    for page in write_site(paths, course, house or House()):
        shutil.copyfile(page, course_dir / page.name)
    (docs / "index.md").write_text("\n".join([
        "---", "outline: false", "---", "", "# Academy preview", "",
        f"Preview of the generated academy pages. Start at [{course.title}](/academy/{course.id}/).", "",
        "| Lesson | Slot | Length |", "| --- | --- | --- |", *rows, "",
    ]))
    config = {
        "title": "Academy preview",
        "description": f"Local preview of {course.title}",
        "cleanUrls": True,
        # Stack lessons link to the apps the stack serves on localhost, which only exist on a running stack.
        "ignoreDeadLinks": "localhostLinks",
        "themeConfig": {
            "nav": [{"text": course.title, "link": f"/academy/{course.id}/"}],
            "sidebar": {"/": [{"text": course.title, "items": [{"text": "Overview", "link": f"/academy/{course.id}/"}, *built,
                                                              {"text": "Glossary", "link": f"/academy/{course.id}/glossary"}]}]},
            "search": {"provider": "local"},
        },
        "vite": {"server": {"fs": {"allow": [str(TOOL_ROOT), str(site)]}}},
    }
    (docs / ".vitepress" / "config.mts").write_text(
        "import { defineConfig } from 'vitepress'\n\nexport default defineConfig(" + json.dumps(config, indent=2) + ")\n")
    (docs / ".vitepress" / "theme" / "index.ts").write_text(
        f"export {{ default }} from '{(TOOL_ROOT / 'theme' / 'index.ts').as_posix()}'\n")
    return site


def vitepress(site: Path, *args: str) -> subprocess.CompletedProcess:
    exe = node_bin("vitepress")
    if not exe.exists():
        raise LecternError("VitePress is not installed. Run npm ci in the tool repo")
    env = {**os.environ, "VITE_CJS_IGNORE_WARNING": "true"}
    return subprocess.run([str(exe), *args], cwd=site, env=env, capture_output=True, text=True)


def build_static(site: Path) -> Path:
    p = vitepress(site, "build", "docs")
    if p.returncode:
        raise LecternError(f"VitePress build failed:\n{(p.stdout + p.stderr)[-2000:]}")
    return site / "docs" / ".vitepress" / "dist"
