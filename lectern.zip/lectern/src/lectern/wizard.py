"""The terminal wizard: questions.yaml rendered as prompts, for anyone working without Claude.

One question at a time, each with its default and one line of why. Enter keeps the current value, `default` resets to
the inherited one. Every answer validates the moment it is given. Answers are saved after each question in
.lectern/wizard-state.json, so an interrupted session resumes where it stopped. Nothing is written until the mode ends
with a diff and a yes.
"""
from __future__ import annotations

import datetime as dt
import json
from pathlib import Path
from typing import Callable

from .config import House, flatten, load_machine, save_machine, set_yaml_key, validate_value
from .paths import LecternError

Ask = Callable[[str], str]


class Wizard:
    def __init__(self, house: House, state_dir: Path, ask: Ask = input, say: Callable[[str], None] = print):
        self.house, self.ask, self.say = house, ask, say
        self.state_path = state_dir / "wizard-state.json"

    # --------------------------------------------------------------------- state

    def load_state(self, mode: str) -> dict:
        if self.state_path.exists():
            st = json.loads(self.state_path.read_text())
            if st.get("mode") == mode and st.get("answers"):
                self.say(f"Resuming {mode}: {len(st['answers'])} answer(s) kept from {st.get('started', 'earlier')}.")
                return st
        return {"mode": mode, "started": dt.datetime.now().isoformat(timespec="minutes"), "answers": {}}

    def save_state(self, st: dict) -> None:
        self.state_path.parent.mkdir(parents=True, exist_ok=True)
        self.state_path.write_text(json.dumps(st, indent=1, ensure_ascii=False))

    def clear_state(self) -> None:
        if self.state_path.exists():
            self.state_path.unlink()

    # --------------------------------------------------------------------- one question

    def question(self, key: str, current=None, inherited=None, required: bool = True):
        q = self.house.question(key) or {"key": key, "prompt": key}
        shown = current if current is not None else inherited if inherited is not None else q.get("default")
        self.say("")
        self.say(q["prompt"])
        if q.get("help"):
            self.say(f"  why: {q['help']}")
        rule = q.get("validate") or {}
        if rule.get("type") == "choice":
            self.say(f"  choices: {', '.join(map(str, rule['choices']))}")
        while True:
            hint = f" [{self._fmt(shown)}]" if shown not in (None, "", []) else ""
            raw = self.ask(f"> {key}{hint}: ").strip()
            if raw == "":
                if shown in (None, "", []):
                    if not required:
                        return None
                    self.say("  this one has no default. Type a value")
                    continue
                value = shown
            elif raw == "default":
                value = inherited if inherited is not None else q.get("default")
                if value is None:
                    self.say("  nothing to inherit here. Type a value")
                    continue
            else:
                value = raw
            try:
                return validate_value(key, value, self.house)
            except LecternError as e:
                self.say(f"  {e}")

    @staticmethod
    def _fmt(v) -> str:
        return ", ".join(map(str, v)) if isinstance(v, list) else str(v)

    def confirm(self, prompt: str) -> bool:
        return self.ask(f"{prompt} [y/N] ").strip().lower() in ("y", "yes")

    def diff(self, before: dict, after: dict) -> list[str]:
        lines = []
        for k in after:
            if before.get(k) != after[k]:
                lines.append(f"  {k}: {self._fmt(before.get(k)) if before.get(k) is not None else '-'} -> {self._fmt(after[k])}")
        return lines

    # --------------------------------------------------------------------- modes

    def setup(self, run_profile: Callable[[], dict] | None = None) -> dict:
        st = self.load_state("setup")
        machine = load_machine().get("render") or {}
        before = {"render.workers": machine.get("workers")}
        before.update({k: flatten(self.house.config).get(k) for k in ("cap_minutes", "fidelity", "quality", "loudness_lufs")})
        a = st["answers"]
        if "render.workers" not in a:
            if machine.get("workers"):
                self.say(f"\nThis machine was profiled on {machine.get('probed')}: {machine['workers']} render workers.")
                again = self.confirm("Profile it again?")
            else:
                again = True
            if again and run_profile:
                self.say("Timing a 10-second probe at 1, 2 and half the CPUs. This takes about a minute.")
                result = run_profile()
                machine = {"workers": result["workers"]}
            a["render.workers"] = self.question("render.workers", current=machine.get("workers"))
            self.save_state(st)
        for key in ("cap_minutes", "fidelity", "quality", "loudness_lufs"):
            if key in a:
                continue
            a[key] = self.question(key, current=before[key], inherited=(self.house.question(key) or {}).get("default"))
            self.save_state(st)
        changes = self.diff(before, a)
        if not changes:
            self.say("\nNothing changed.")
            self.clear_state()
            return a
        self.say("\nChanges:\n" + "\n".join(changes))
        if not self.confirm("Write these?"):
            self.say("Nothing written. Your answers are saved, so `lectern wizard setup` resumes here.")
            return a
        if a["render.workers"] != before["render.workers"]:
            profile = load_machine()
            profile.setdefault("render", {})["workers"] = a["render.workers"]
            save_machine(profile)
        for key in ("cap_minutes", "fidelity", "quality", "loudness_lufs"):
            if a[key] != before[key]:
                set_yaml_key(self.house.root / "config.yaml", key, a[key])
        self.clear_state()
        self.say("Written. Next: `lectern wizard audition`.")
        return a

    def audition(self, render_page: Callable[[], Path], apply_line: Callable[[str], list[str]]) -> None:
        page = render_page()
        self.say(f"\nOpen {page} in a browser and listen. Pick a Narrator, an Examiner, a speed for each and every term.")
        line = self.ask("Paste the picks line from the bottom of the page (Enter to pick by typing): ").strip()
        if not line:
            v = self.house.voices
            narrator = self.question("narrator", current=v["narrator"]["voice"])
            n_speed = self._speed("Narrator", v["narrator"]["speed"])
            examiner = self.question("examiner", current=v["examiner"]["voice"])
            e_speed = self._speed("Examiner", v["examiner"]["speed"])
            line = f"narrator={narrator}@{n_speed} examiner={examiner}@{e_speed}"
        self.say(f"\nPicks: {line}")
        if not self.confirm("Write these to voices.yaml and terms.yaml?"):
            self.say("Nothing written.")
            return
        for change in apply_line(line):
            self.say(f"  {change}")

    def _speed(self, role: str, current: float) -> float:
        while True:
            raw = self.ask(f"> {role} speed [{current}]: ").strip()
            try:
                v = float(raw) if raw else float(current)
                if 0.7 <= v <= 1.3:
                    return v
            except ValueError:
                pass
            self.say("  a speed between 0.7 and 1.3")

    def course(self, create: Callable[[dict], Path]) -> dict:
        st = self.load_state("course")
        a = st["answers"]
        for key in ("course.kind", "course.id", "course.title", "course.sources", "course.floor"):
            if key in a:
                continue
            inherited = None
            if key == "course.floor":
                inherited = ["python", "git", "terminal"] if a.get("course.kind") == "stack" else ["python", "terminal"]
            a[key] = self.question(key, inherited=inherited)
            self.save_state(st)
        self.say("\ncourse.yaml will hold:\n" + "\n".join(f"  {k}: {self._fmt(v)}" for k, v in a.items()))
        if not self.confirm("Create the course?"):
            self.say("Nothing written. `lectern wizard course` resumes with these answers.")
            return a
        path = create(a)
        self.clear_state()
        self.say(f"Wrote {path}. Next: `lectern sources`, then `lectern wizard lesson`.")
        return a

    def lesson(self, create: Callable[[dict], Path]) -> dict:
        st = self.load_state("lesson")
        a = st["answers"]
        for key in ("lesson.id", "lesson.title", "lesson.type", "lesson.objective", "lesson.checkpoint_seed", "rung"):
            if key in a:
                continue
            inherited = (self.house.question(key) or {}).get("default")
            a[key] = self.question(key, inherited=inherited)
            self.save_state(st)
        self.say("\nThe lesson stub will hold:\n" + "\n".join(f"  {k}: {self._fmt(v)}" for k, v in a.items()))
        if not self.confirm("Create the stub?"):
            self.say("Nothing written. `lectern wizard lesson` resumes with these answers.")
            return a
        path = create(a)
        self.clear_state()
        self.say(f"Wrote {path}. Write it with /lectern:lesson {a['lesson.id']}, or by hand.")
        return a

    def override(self, write: Callable[[str, object, str, str | None], str]) -> None:
        key = self.ask("> key to change: ").strip()
        q = self.house.question(key)
        if not q:
            raise LecternError(f"{key} is not a wizard question. Keys: {', '.join(x['key'] for x in self.house.questions)}")
        scopes = [s for s in q.get("scope", []) if s != "cli"]
        scope = self.ask(f"> scope ({', '.join(scopes)}) [{scopes[-1]}]: ").strip() or scopes[-1]
        if scope not in scopes:
            raise LecternError(f"{key} can be set at {', '.join(scopes)}")
        value = self.question(key)
        reason = None
        if q.get("reason_required_on_override") and scope != "house":
            while not reason:
                reason = self.ask("> reason (required for this override): ").strip()
        self.say(f"\n  {key} = {self._fmt(value)} at {scope}" + (f", because {reason}" if reason else ""))
        if self.confirm("Write it?"):
            self.say(write(key, value, scope, reason))


def init_defaults(house: House, run_profile: Callable[[], dict], log=print) -> list[str]:
    """Take every setup default with no questions. Fail on any required value that has no default and no way to derive it."""
    problems, taken = [], []
    for q in house.questions:
        if q.get("mode") != "setup":
            continue
        if q["key"] == "render.workers":
            if not (load_machine().get("render") or {}).get("workers"):
                result = run_profile()
                taken.append(f"render.workers={result['workers']} (profiled)")
            else:
                taken.append(f"render.workers={(load_machine().get('render') or {})['workers']} (kept)")
            continue
        current = flatten(house.config).get(q["key"], q.get("default"))
        if current is None:
            problems.append(f"{q['key']} has no default. Set it with `lectern config set {q['key']} <value> --scope house`")
            continue
        validate_value(q["key"], current, house)
        taken.append(f"{q['key']}={current!r}")
    if problems:
        raise LecternError("init --defaults cannot finish:\n  " + "\n  ".join(problems))
    for t in taken:
        log(f"init: {t}")
    return taken
