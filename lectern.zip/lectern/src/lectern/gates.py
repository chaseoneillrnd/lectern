"""Human gates. Gate one approves the script and its claims before render, gate two approves the render.

Approvals are recorded in lessons/<id>.gates.yaml with hashes of what was approved, so any later edit reopens the gate.
"""
from __future__ import annotations

import datetime as dt
import getpass
import hashlib
import json
import shutil
from pathlib import Path

import jinja2
import yaml

from .config import House, load_yaml
from .paths import CoursePaths, LecternError


def sha_file(p: Path) -> str | None:
    return hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None


def gates_path(paths: CoursePaths, lesson_id: str) -> Path:
    return paths.lessons / f"{lesson_id}.gates.yaml"


def fingerprints(paths: CoursePaths, course_id: str, lesson_id: str) -> dict:
    return {
        "script": sha_file(paths.lesson_script(lesson_id)),
        "claims": sha_file(paths.claims_ledger(lesson_id)),
        "mp4": sha_file(paths.dist_dir(course_id, lesson_id) / "lesson.mp4"),
    }


def build_record(paths: CoursePaths, course_id: str, lesson_id: str) -> dict:
    p = paths.dist_dir(course_id, lesson_id) / "build.json"
    return json.loads(p.read_text()) if p.exists() else {}


def render_problem(paths: CoursePaths, course_id: str, lesson_id: str) -> str | None:
    """Why the packaged MP4 cannot go to gate two, or None when it can: it must come from the current script and
    ledger, at standard quality and full fidelity, with every check green."""
    now = fingerprints(paths, course_id, lesson_id)
    b = build_record(paths, course_id, lesson_id)
    if not now["mp4"]:
        return "no packaged MP4. Run `lectern build` first"
    if not b or b.get("mp4") != now["mp4"]:
        return "the packaged MP4 has no build record. Rebuild with `lectern build`"
    if b.get("script") != now["script"] or b.get("claims") != now["claims"]:
        return "the MP4 was built from an older script or ledger. Rebuild with `lectern build`"
    if b.get("quality") != "standard" or b.get("fidelity") != "full":
        return f"the MP4 is a {b.get('quality')} {b.get('fidelity')} render. Gate two takes standard quality, full fidelity"
    if not b.get("checks_ok"):
        return "the build's checks did not pass"
    drawn = b.get("map")
    if drawn and sha_file(paths.root / drawn["path"]) != drawn["hash"]:
        return ("the course Map changed after this MP4 was built. Rebuild with `lectern build`, so every lesson draws "
                "the same Map")
    return None


def gate_state(paths: CoursePaths, course_id: str, lesson_id: str) -> dict:
    rec = load_yaml(gates_path(paths, lesson_id)) if gates_path(paths, lesson_id).exists() else {}
    now = fingerprints(paths, course_id, lesson_id)
    one = rec.get("one")
    one_ok = bool(one) and one.get("script") == now["script"] and one.get("claims") == now["claims"]
    two = rec.get("two")
    two_ok = (one_ok and bool(two) and two.get("mp4") == now["mp4"] and two.get("script") == now["script"]
              and render_problem(paths, course_id, lesson_id) is None)
    return {"one": {"approved": one_ok, "record": one}, "two": {"approved": two_ok, "record": two}}


def approve(paths: CoursePaths, course_id: str, lesson_id: str, gate: str, by: str | None = None) -> dict:
    if gate not in ("one", "two"):
        raise LecternError("gate is one or two")
    state = gate_state(paths, course_id, lesson_id)
    now = fingerprints(paths, course_id, lesson_id)
    if gate == "two":
        if not state["one"]["approved"]:
            raise LecternError("gate one is open for this script. Approve the script and claims first")
        problem = render_problem(paths, course_id, lesson_id)
        if problem:
            raise LecternError(f"gate two cannot be approved: {problem}")
    rec = load_yaml(gates_path(paths, lesson_id)) if gates_path(paths, lesson_id).exists() else {}
    entry = {"approved": dt.date.today().isoformat(), "by": by or getpass.getuser(), "script": now["script"]}
    if gate == "one":
        entry["claims"] = now["claims"]
    else:
        entry["mp4"] = now["mp4"]
    rec[gate] = entry
    gates_path(paths, lesson_id).write_text(
        "# Human gate approvals. Hashes record exactly what was approved; any later edit reopens the gate.\n"
        + yaml.safe_dump(rec, sort_keys=False))
    return entry


# ----------------------------------------------------------------------------- packets


def _env(house: House) -> jinja2.Environment:
    env = jinja2.Environment(loader=jinja2.FileSystemLoader(house.root / "templates"), autoescape=True)
    env.filters["tojson_safe"] = lambda v: json.dumps(v).replace("</", "<\\/")
    return env


def segments(text: str, cues: list[dict]) -> list[dict]:
    """Split a sentence into plain runs and cue spans, so the packet shows where each cue fires."""
    out, pos = [], 0
    for cue in sorted(cues, key=lambda c: c["word_index"]):
        i = text.find(cue["span"], pos)
        if i < 0:
            continue
        if i > pos:
            out.append({"text": text[pos:i]})
        target = cue.get("target") or ""
        label = cue["verb"] + (f" {target}" if target and target != cue["span"] else "")
        out.append({"text": cue["span"], "cue": label})
        pos = i + len(cue["span"])
    if pos < len(text):
        out.append({"text": text[pos:]})
    return out


def gate_one_packet(paths: CoursePaths, house: House, plan: dict, claims: list[dict], judge: dict | None,
                    term_audio: list[dict]) -> str:
    scores = {s["item"]: s for s in (judge or {}).get("scores", [])}
    claim_by_id = {c["id"]: c for c in claims}
    scenes = []
    for sc in plan["scenes"]:
        rows = []
        for s in sc["sentences"]:
            ev = [claim_by_id.get(cid, {"id": cid, "status": "missing", "where": "", "excerpt": "", "kind": ""})
                  for cid in s["claims"] if cid != "nc"]
            rows.append({"id": s["id"], "text": s["text"], "shown": s.get("shown"),
                         "segments": segments(s["text"], s["cues"]), "kind": s["kind"],
                         "voice": s["voice"], "claims": ev, "judge": scores.get(s["id"]), "no_claim": s.get("no_claim")})
        scenes.append({"id": sc["id"], "layout": sc["layout"], "title": sc["params"].get("title") or sc["id"], "rows": rows})
    judged = [s["score"] for s in scores.values()]
    fp = fingerprints(paths, plan["course"]["id"], plan["lesson"]["id"])
    cited = sum(1 for sc in scenes for r in sc["rows"] if r["claims"])
    return _env(house).get_template("gate_one.html.j2").render(
        lesson=plan["lesson"], front=plan["lesson"]["front"], course=plan["course"], scenes=scenes, terms=term_audio,
        n_claims=len(claims), n_ok=sum(1 for c in claims if c["status"] == "ok"), cited=cited,
        n_sentences=sum(len(sc["rows"]) for sc in scenes), minutes=plan["estimate_minutes"],
        judged=len(judged), weak=sum(1 for s in judged if s < 2), judge_summary=(judge or {}).get("summary"),
        script_sha=(fp["script"] or "")[:12], claims_sha=(fp["claims"] or "")[:12], today=dt.date.today().isoformat(),
        voices={"narrator": house.voices["narrator"], "examiner": house.voices["examiner"],
                "status": house.voices.get("status", "")},
    )


REVIEW_MAX_BYTES = 14_000_000  # a published review page carries files up to 15 MB each


def review_copy(src: Path, dst: Path, duration_s: float, max_bytes: int = REVIEW_MAX_BYTES,
                cache: Path | None = None) -> dict | None:
    """Put the lesson MP4 beside the review page. A cut too large to publish there is re-encoded to fit, at full size,
    with the audio untouched. Returns what was re-encoded, or None for a plain copy. The approval always pins the
    original file, and the page's frames always come from the full render. With `cache`, a re-encode is kept by the
    original's hash, so writing the packet again after an approval takes seconds."""
    if src.stat().st_size <= max_bytes:
        shutil.copyfile(src, dst)
        return None
    kept = cache / f"{hashlib.sha256(src.read_bytes()).hexdigest()[:16]}-{max_bytes}.mp4" if cache else None
    if kept and kept.exists():
        shutil.copyfile(kept, dst)
        return {"mb": round(dst.stat().st_size / 1e6, 1), "kbps": None}
    made = _reencode(src, dst, duration_s, max_bytes)
    if kept:
        kept.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(dst, kept)
    return made


def _reencode(src: Path, dst: Path, duration_s: float, max_bytes: int) -> dict:
    import subprocess

    def probe(stream: str) -> float:
        p = subprocess.run(["ffprobe", "-v", "error", "-select_streams", stream, "-show_entries", "stream=bit_rate",
                            "-of", "csv=p=0", str(src)], capture_output=True, text=True)
        try:
            return float(p.stdout.strip()) / 1000
        except ValueError:
            return 128.0

    audio_kbps, budget = probe("a:0"), max_bytes * 0.97
    for _ in range(4):  # one pass at an average bitrate lands near the budget, and a tighter retry closes the gap
        video_kbps = max(budget * 8 / 1000 / duration_s - audio_kbps, 80)
        p = subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", str(src), "-map", "0:v:0", "-map", "0:a:0",
                            "-c:v", "libx264", "-preset", "medium", "-b:v", f"{video_kbps:.0f}k",
                            "-maxrate", f"{video_kbps * 1.6:.0f}k", "-bufsize", f"{video_kbps * 3:.0f}k",
                            "-pix_fmt", "yuv420p", "-c:a", "copy", "-movflags", "+faststart", str(dst)],
                           capture_output=True, text=True)
        if p.returncode != 0:
            raise LecternError(f"could not re-encode the review copy: {p.stderr.strip()[-300:]}")
        if dst.stat().st_size <= max_bytes:
            return {"mb": round(dst.stat().st_size / 1e6, 1), "kbps": round(video_kbps)}
        budget *= max_bytes / dst.stat().st_size * 0.97
    raise LecternError(f"the review copy is still over {max_bytes / 1e6:.0f} MB after four tries")


def gate_two_packet(paths: CoursePaths, house: House, course_id: str, lesson_id: str, timeline: dict, out_dir: Path,
                    gate_one_open: bool = False) -> Path:
    """Write the gate-two review folder: index.html beside the MP4, captions and contact-sheet frames it plays."""
    from PIL import Image

    from .package import chapter_list

    dist = paths.dist_dir(course_id, lesson_id)
    mp4 = dist / "lesson.mp4"
    if not mp4.exists():
        raise LecternError("no packaged lesson. Run `lectern build` first")
    if out_dir.exists():
        shutil.rmtree(out_dir)
    (out_dir / "frames").mkdir(parents=True)
    reencoded = review_copy(mp4, out_dir / "lesson.mp4", timeline["duration_ms"] / 1000,
                            cache=paths.state / "cache" / "review")
    poster = (dist / "poster.jpg").exists()
    if poster:
        shutil.copyfile(dist / "poster.jpg", out_dir / "poster.jpg")
    review = dist / "review"
    sheet = json.loads((review / "contact-sheet.json").read_text())
    frames_dir = paths.build_dir(lesson_id) / "frames"
    shots = []
    for i, shot in enumerate(sheet):
        im = Image.open(frames_dir / shot["png"]).convert("RGB")
        im.thumbnail((960, 540))
        name = f"frames/{i:03d}.jpg"
        im.save(out_dir / name, quality=84)
        t, _, label = shot["label"].partition("  ")
        shots.append({"src": name, "time": t, "label": label, "span": shot["span"]})
    check = json.loads((review / "check.json").read_text())
    inspection = None
    insp_p = review / "frame-inspection.json"
    if insp_p.exists():
        insp = json.loads(insp_p.read_text())
        mp4_sha = hashlib.sha256(mp4.read_bytes()).hexdigest()[:16]
        if insp.get("mp4") == mp4_sha:  # findings about an older render are left out
            notes = {f"f{i:03d}": s for i, s in enumerate(shots)}
            inspection = {"summary": insp.get("summary", ""), "frames": len(insp["frames"]),
                          "issues": [{"item": f["item"], "time": notes.get(f["item"], {}).get("time", ""),
                                      "label": notes.get(f["item"], {}).get("label", ""), **i}
                                     for f in insp["frames"] for i in f["issues"]]}
            for k, s in enumerate(shots):
                s["issues"] = [i for i in inspection["issues"] if i["item"] == f"f{k:03d}"]
    html = _env(house).get_template("gate_two.html.j2").render(
        lesson=lesson_id, title=timeline.get("title") or lesson_id, course=(timeline.get("course") or {}).get("title", course_id),
        shots=shots, check=check, chapters=chapter_list(timeline), duration=timeline["duration_ms"] / 1000,
        size_mb=round(mp4.stat().st_size / 1e6, 1), mp4_sha=(sha_file(mp4) or "")[:12],
        script_sha=(sha_file(paths.lesson_script(lesson_id)) or "")[:12], today=dt.date.today().isoformat(),
        gate_one_open=gate_one_open, poster=poster, vtt=(dist / "lesson.vtt").read_text(encoding="utf-8").replace("</", "< /"),
        inspection=inspection, reencoded=reencoded,
    )
    (out_dir / "index.html").write_text(html, encoding="utf-8")
    return out_dir


def screen_text(paths: CoursePaths, scene: dict) -> str | None:
    """What the viewer sees while a scene plays, as text, so the judge can weigh sentences that describe the screen."""
    if scene["layout"] == "code":
        from .render import code_text

        a, b = scene["code"]["show"]
        lines = code_text(paths, scene["code"]).splitlines()
        return "\n".join(f"{n:>3}  {lines[n - 1]}" for n in range(a, b + 1))
    if scene["layout"] == "cast":
        from .capture import cast_text

        return cast_text(Path(scene["cast"]["path"]))
    if scene["layout"] == "steps":
        from .steps import expand_play, load_capture

        cap = load_capture(paths, scene["steps"]["id"])
        current = last = scene["steps"]["start"]
        for s in scene["sentences"]:
            for c in s["cues"]:
                if c["verb"] == "play":
                    ks = expand_play(cap, c["target"], current)
                    if ks:
                        current = last = max(last, ks[-1])
        pages = []
        for k in range(scene["steps"]["start"], last + 1):
            dump = Path(cap["dir"]) / cap["steps"][k]["file"].replace(".png", ".txt")
            if dump.exists():
                pages.append(f"[step {cap['steps'][k]['id']}] " + dump.read_text(encoding="utf-8").strip())
        return "\n".join(pages) or None
    if scene["layout"] in ("diagram", "map"):
        d = scene[scene["layout"]]
        nodes = {n["id"]: str(n.get("label", n["id"])).replace("\n", " ") for n in d["nodes"]}
        edges = [f"{nodes[e['from']]} -> {nodes[e['to']]}" + (f" ({e['label']})" if e.get("label") else "")
                 for e in d.get("edges", [])]
        text = "Boxes: " + ", ".join(nodes.values()) + "\nArrows: " + "; ".join(edges)
        if scene["layout"] == "map":
            # Where each box sits, so a sentence like "the app, in the middle" can be checked against the frame.
            gx, gy = d.get("grid", [12, 6])
            cols = {0: "left", 1: "middle", 2: "right"}
            rows = {0: "top", 1: "middle", 2: "bottom"}
            text += "\nLayout: " + "; ".join(
                f"{nodes[n['id']]} at {rows[min(2, int(3 * n['at'][1] / gy))]} {cols[min(2, int(3 * n['at'][0] / gx))]}"
                for n in d["nodes"])
            if scene.get("component"):
                text += f"\nLit when the scene opens: {nodes[scene['component']]}"
        return text
    return None


def judge_items(paths: CoursePaths, plan: dict, claims: list[dict]) -> list[dict]:
    """One item per cited sentence, with all of its evidence, so a sentence backed by two excerpts is judged as a whole."""
    by_id = {c["id"]: c for c in claims}
    items = []
    for sc in plan["scenes"]:
        screen = screen_text(paths, sc)
        for s in sc["sentences"]:
            if not s["claims"] or s.get("no_claim"):
                continue
            evidence = [{"claim": cid, "kind": by_id[cid]["kind"], "excerpt": by_id[cid]["excerpt"].strip(),
                         "source": by_id[cid]["where"]} for cid in s["claims"] if cid in by_id]
            item = {"item": s["id"], "sentence": s["text"], "evidence": evidence}
            if screen:
                item["screen"] = screen
            items.append(item)
    return items


def judge_input(paths: CoursePaths, plan: dict, claims: list[dict]) -> dict:
    return {"lesson": plan["lesson"]["id"], "items": judge_items(paths, plan, claims)}


def validate_judge(output: dict, bundle: dict) -> dict:
    """Check the judge's JSON against the bundle it was given: one integer score from 0 to 3 per item, no extras."""
    if not isinstance(output, dict) or not isinstance(output.get("scores"), list):
        raise LecternError('judge output needs a "scores" list')
    want = {i["item"] for i in bundle["items"]}
    got = {}
    for s in output["scores"]:
        item, score = s.get("item"), s.get("score")
        if item not in want:
            raise LecternError(f"judge scored unknown item {item!r}")
        if not isinstance(score, int) or not 0 <= score <= 3:
            raise LecternError(f"judge score for {item} must be an integer from 0 to 3, got {score!r}")
        if not str(s.get("reason", "")).strip():
            raise LecternError(f"judge gave no reason for {item}")
        got[item] = s
    missing = sorted(want - set(got))
    if missing:
        raise LecternError(f"judge skipped {len(missing)} item(s): {', '.join(missing)}")
    return {"scores": [got[i["item"]] for i in bundle["items"]], "summary": str(output.get("summary", "")),
            "bundle_sha": bundle_sha(bundle)}


def bundle_sha(bundle: dict) -> str:
    return hashlib.sha256(json.dumps(bundle, sort_keys=True).encode()).hexdigest()


def calibration_bundle(house: House) -> tuple[dict, dict]:
    """The planted-claims set: the bundle the judge sees, and the expected band for each item."""
    raw = load_yaml(house.root / "judge-calibration.yaml")
    items, expect = [], {}
    for it in raw["items"]:
        item = {"item": it["item"], "sentence": it["sentence"], "evidence": it["evidence"]}
        if it.get("screen"):
            item["screen"] = it["screen"]
        items.append(item)
        expect[it["item"]] = it["expect"]
    return {"lesson": "calibration", "items": items}, expect


def score_calibration(result: dict, expect: dict) -> list[str]:
    misses = []
    for s in result["scores"]:
        band = expect[s["item"]]
        if band == "good" and s["score"] < 2:
            misses.append(f"{s['item']}: a good claim scored {s['score']} ({s['reason']})")
        if band == "bad" and s["score"] > 1:
            misses.append(f"{s['item']}: a planted bad claim scored {s['score']} ({s['reason']})")
    return misses
