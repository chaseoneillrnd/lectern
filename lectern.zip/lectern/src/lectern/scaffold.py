"""init, course new, lesson new: the toolchain check and the files a course and a lesson start from."""
from __future__ import annotations

import os
import re
import subprocess
from pathlib import Path

import yaml

from . import __version__
from .config import House, load_machine, load_yaml, set_yaml_key, validate_value
from .paths import LecternError, node_bin, node_root

NODE_PACKAGES = ["hyperframes", "gsap", "asciinema-player", "shiki", "vitepress", "vue", "@fontsource/inter",
                 "@fontsource/jetbrains-mono"]


def _version(cmd: list[str], limit: int = 80) -> str | None:
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=20,
                           env={**os.environ, "HYPERFRAMES_NO_TELEMETRY": "1", "DO_NOT_TRACK": "1"})
    except (OSError, subprocess.TimeoutExpired):
        return None
    out = (p.stdout or p.stderr).strip().splitlines()
    return out[-1 if limit == 0 else 0][: limit or None] if p.returncode == 0 and out else None


def check_toolchain(house: House) -> list[dict]:
    """Everything a build needs on this machine. Each row: what, ok, detail, and the fix when it fails."""
    rows = []

    def row(what: str, ok: bool, detail: str, fix: str = "") -> None:
        rows.append({"what": what, "ok": ok, "detail": detail, "fix": "" if ok else fix})

    row("lectern", True, __version__)
    node = _version(["node", "--version"])
    row("node", bool(node), node or "not found", "Install Node 22 or newer")
    for name in NODE_PACKAGES:
        pj = node_root() / "node_modules" / name / "package.json"
        if pj.exists():
            import json

            row(f"npm {name}", True, json.loads(pj.read_text()).get("version", "?"))
        else:
            row(f"npm {name}", False, "missing", f"Run `npm ci` in {node_root()}")
    for tool in ("ffmpeg", "ffprobe"):
        v = _version([tool, "-version"])
        row(tool, bool(v), (v or "not found").replace(" Copyright", "").split(" (c)")[0], "Install FFmpeg 6 or newer")
    hf = node_bin("hyperframes")
    browser = _version([str(hf), "browser", "path"], limit=0) if hf.exists() else None
    row("render browser", bool(browser and Path(browser).exists()), browser or "not found",
        "Run `npx hyperframes browser install` once, online")

    # Kokoro weights and every voice the house uses, in the Hugging Face cache, so synthesis runs offline.
    try:
        from huggingface_hub import try_to_load_from_cache

        needed = ["kokoro-v1_0.pth", "config.json"]
        voices = {house.voices["narrator"]["voice"], house.voices["examiner"]["voice"], *house.voices.get("shortlist", [])}
        needed += [f"voices/{v}.pt" for v in sorted(voices)]
        missing = [f for f in needed if not isinstance(try_to_load_from_cache("hexgrad/Kokoro-82M", f), str)]
        row("kokoro weights", not missing, "cached" if not missing else f"missing {', '.join(missing)}",
            "Run `lectern init` once, online, to download them")
    except Exception as e:  # pragma: no cover
        row("kokoro weights", False, str(e), "pip install the lectern package")
    try:
        import spacy  # noqa: F401
        import en_core_web_sm  # noqa: F401

        row("english model", True, "en_core_web_sm")
    except ImportError:
        row("english model", False, "en_core_web_sm missing", "Run `python -m spacy download en_core_web_sm`")
    gl = _version(["gitleaks", "version"])
    row("gitleaks", bool(gl), gl or "not found", "Install gitleaks 8. Without it the redaction scan is skipped")
    workers = (load_machine().get("render") or {}).get("workers")
    row("render profile", bool(workers), f"{workers} workers" if workers else "not profiled", "Run `lectern profile`")
    return rows


def warm_models(house: House, log=print) -> None:
    """Download Kokoro's weights and the house voices once, so every later run works offline."""
    from huggingface_hub import hf_hub_download

    voices = {house.voices["narrator"]["voice"], house.voices["examiner"]["voice"], *house.voices.get("shortlist", [])}
    for f in ["config.json", "kokoro-v1_0.pth", *[f"voices/{v}.pt" for v in sorted(voices)]]:
        hf_hub_download("hexgrad/Kokoro-82M", f)
        log(f"init: cached {f}")


# ----------------------------------------------------------------------------- course new


def resolve_commit(repo: str, ref: str) -> str | None:
    """The commit a tag or branch points at, from the remote. None when the remote cannot be reached."""
    try:
        p = subprocess.run(["git", "ls-remote", repo, f"refs/tags/{ref}^{{}}", f"refs/tags/{ref}", f"refs/heads/{ref}"],
                           capture_output=True, text=True, timeout=60)
    except (OSError, subprocess.TimeoutExpired):
        return None
    lines = [row.split("\t") for row in p.stdout.splitlines() if "\t" in row]
    peeled = [sha for sha, name in lines if name.endswith("^{}")]
    return (peeled or [sha for sha, _ in lines] or [None])[0]


def parse_source(spec: str) -> tuple[str, str, str]:
    """name=repo@ref, for example ragas=https://github.com/explodinggradients/ragas.git@v0.4.3"""
    m = re.fullmatch(r"([a-z0-9][a-z0-9_-]*)=(.+)@([^@]+)", spec.strip())
    if not m:
        raise LecternError(f"source {spec!r}: expected name=repo@ref")
    return m.group(1), m.group(2), m.group(3)


def new_course(root: Path, house: House, course_id: str, title: str, kind: str, sources: list[str],
               floor: list[str] | None = None, owner: str | None = None, log=print) -> Path:
    validate_value("course.id", course_id, house)
    validate_value("course.kind", kind, house)
    if (root / "course.yaml").exists():
        raise LecternError(f"{root / 'course.yaml'} already exists. Edit it, or use `lectern config set`")
    pins = {}
    for spec in sources:
        name, repo, ref = parse_source(spec)
        from .sources import resolve_repo

        commit = resolve_commit(resolve_repo(repo, root), ref)
        log(f"course: {name} {ref} -> {commit or 'unresolved (offline?) run `lectern sources` later'}")
        pins[name] = {"repo": repo, "ref": ref, **({"commit": commit} if commit else {})}
    floor = floor if floor is not None else (["python", "git", "terminal"] if kind == "stack" else ["python", "terminal"])
    manifest = {
        "id": course_id, "title": title, "kind": kind, "floor": floor, "prerequisites": [], "sources": pins,
        "pins": {"lectern": __version__}, "skeleton": {"quickstart": None, "map": None, "drilldowns": [], "recipes": []},
        "terms": "terms.yaml", "owner": owner or os.environ.get("USER") or None, "defaults": {},
    }
    root.mkdir(parents=True, exist_ok=True)
    head = (f"# {title}. Written by `lectern course new`. Change values with `lectern config set` or /lectern:wizard,\n"
            "# which validate before they write.\n")
    (root / "course.yaml").write_text(head + yaml.safe_dump(manifest, sort_keys=False, allow_unicode=True))
    if not (root / "terms.yaml").exists():
        (root / "terms.yaml").write_text(
            "# Course terms, layered over the house terms. New pronunciations start as `status: proposed`\n"
            "# so `lectern audition voices` plays them before they ship.\n{}\n")
    for d in ("lessons", "diagrams", "capture", "captures", "examples"):
        (root / d).mkdir(exist_ok=True)
    gi = root / ".gitignore"
    if not gi.exists():
        gi.write_text(".lectern/\n.venv/\ndist/\n__pycache__/\n*.pyc\n.env\n")
    ga = root / ".gitattributes"
    if not ga.exists():
        ga.write_text("# Step screenshots are binary and many, so they live in Git LFS.\n"
                      "captures/**/*.png filter=lfs diff=lfs merge=lfs -text\n")
    ci = root / ".gitlab-ci.yml"
    if not ci.exists():
        ci.write_text(CI_TEMPLATE)
    return root / "course.yaml"


CI_TEMPLATE = """# Staleness runs on a schedule in the course repo, never in the stack's merge requests.
# Create a pipeline schedule (CI/CD > Schedules), weekly is plenty. LECTERN_IMAGE is the Lectern container in your registry.
stages: [check]

stale:
  stage: check
  image: {name: $LECTERN_IMAGE, entrypoint: [""]}
  rules:
    - if: $CI_PIPELINE_SOURCE == "schedule"
  script:
    - lectern stale --fail
  artifacts:
    when: always
    paths: [.lectern/stale.json]
    expire_in: 30 days

claims:
  stage: check
  image: {name: $LECTERN_IMAGE, entrypoint: [""]}
  rules:
    - if: $CI_PIPELINE_SOURCE == "merge_request_event"
  script:
    - lectern sources
    - for f in lessons/*.md; do lectern claims "$(basename "$f" .md)" || exit 1; done
"""


# ----------------------------------------------------------------------------- lesson new


SLOT_KEY = {"quickstart": "quickstart", "map": "map", "drilldown": "drilldowns", "recipe": "recipes"}


def new_lesson(root: Path, house: House, course, lesson_id: str, lesson_type: str, objective: str, checkpoint_seed: str,
               title: str | None = None, rung: str = "practitioner", captures: list[str] | None = None,
               cap_minutes: int | None = None, cap_reason: str | None = None, component: str | None = None,
               prerequisites: list[str] | None = None) -> Path:
    validate_value("lesson.type", lesson_type, house)
    validate_value("lesson.objective", objective, house)
    validate_value("lesson.checkpoint_seed", checkpoint_seed, house)
    validate_value("rung", rung, house)
    if not re.fullmatch(r"[a-z0-9][a-z0-9.-]*", lesson_id):
        raise LecternError("lesson ID: use lowercase letters, digits, dots and dashes, such as ragas.faithfulness")
    if cap_minutes is not None:
        validate_value("cap_minutes", cap_minutes, house)
        if not cap_reason:
            raise LecternError("a cap_minutes override needs --cap-reason")
    if component and lesson_type != "drilldown":
        raise LecternError("--component is for drilldowns: it names the Map component the lesson opens on")
    if lesson_type == "drilldown" and course.map:
        # A drilldown opens on the course Map with its component lit, and the course page links that component here.
        ids = [str(n.get("id")) for n in (load_yaml(root / course.map) or {}).get("nodes") or []] \
            if (root / course.map).exists() else []
        if not component:
            raise LecternError("a drilldown covers one component of the course Map. Pass --component with its id: "
                               + ", ".join(ids))
        if ids and component not in ids:
            raise LecternError(f"--component {component} is not on the Map. Components: {', '.join(ids)}")
    script = root / "lessons" / f"{lesson_id}.md"
    if script.exists():
        raise LecternError(f"{script} already exists")
    front = {"id": lesson_id, "title": title or lesson_id.split(".")[-1].replace("-", " ").capitalize(),
             "type": lesson_type, "rung": rung, "pins": course.pin_versions(), "captures": captures or [],
             "objective": objective, "checkpoint_seed": checkpoint_seed}
    if component:
        front["component"] = component
    if prerequisites:
        front["prerequisites"] = list(prerequisites)
    if cap_minutes is not None:
        front.update(cap_minutes=cap_minutes, cap_reason=cap_reason)
    layouts = "title|map|diagram|code|cast|steps|checkpoint" if course.map else "title|diagram|code|cast|steps|checkpoint"
    opening = (f"     A drilldown opens on the Map: make the first scene layout=map, and it opens with {component} lit.\n"
               if component else "")
    body = (
        "\n<!-- Write the lesson with /lectern:lesson " + lesson_id + ".\n"
        "     ## <scene>  layout=<" + layouts + ">  key=value  title=\"...\" opens a scene.\n"
        + opening +
        "     [span]{verb=target} fires a cue on the span's first word. ^claim-id ends a technical sentence.\n"
        "     End with a checkpoint built from checkpoint_seed: > ask: ... then > answer: ... -->\n"
    )
    script.parent.mkdir(parents=True, exist_ok=True)
    script.write_text("---\n" + yaml.safe_dump(front, sort_keys=False, allow_unicode=True, width=1000) + "---\n" + body)
    ledger = root / "lessons" / f"{lesson_id}.claims.yaml"
    if not ledger.exists():
        ledger.write_text(
            f"# Claims ledger for {lesson_id}. Every claim tag in the script resolves here.\n"
            "# kind: doc (a page at a pinned version), code (a repo path at a pinned ref, or a course file),\n"
            "# run (captured output). excerpt: copied verbatim from the cached source, never from memory.\n{}\n")
    slot = SLOT_KEY[lesson_type]
    current = getattr(course.skeleton, slot)
    if slot in ("drilldowns", "recipes"):
        if lesson_id not in current:
            set_yaml_key(root / "course.yaml", f"skeleton.{slot}", [*current, lesson_id])
    elif current != lesson_id:
        set_yaml_key(root / "course.yaml", f"skeleton.{slot}", lesson_id)
    return script
