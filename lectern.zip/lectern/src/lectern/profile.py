"""profile: time a probe render at a few worker counts and keep the fastest for this machine.

HyperFrames' automatic worker choice gives one worker on 4 or fewer CPUs and on any machine where Linux sees 8 GB or
less. An explicit count overrides both limits, so Lectern measures once per machine and passes it on every render.
"""
from __future__ import annotations

import datetime as dt
import os
import shutil
import subprocess
import tempfile
import time
from pathlib import Path

from .config import load_machine, save_machine
from .paths import LecternError, node_bin, node_root

PROBE = """<!doctype html>
<html lang="en"><head><meta charset="UTF-8"><script src="vendor/gsap.min.js"></script>
<style>
@font-face { font-family: "House Sans"; src: url("fonts/inter-latin-600-normal.woff2") format("woff2"); }
@font-face { font-family: "House Mono"; src: url("fonts/jetbrains-mono-latin-400-normal.woff2") format("woff2"); }
body { margin: 0; background: #0b0f14; color: #e6edf3; font-family: "House Sans"; }
#root { position: relative; width: 1920px; height: 1080px; overflow: hidden; }
.box { position: absolute; width: 300px; height: 130px; border-radius: 18px; background: #111823; border: 3px solid #2f3b4a;
       display: grid; place-items: center; font-size: 36px; }
pre { position: absolute; left: 112px; top: 640px; margin: 0; font: 32px/48px "House Mono"; color: #c9d1d9; }
</style></head><body>
<div id="root" data-composition-id="probe" data-start="0" data-width="1920" data-height="1080" data-duration="__SECONDS__">
__BOXES__
<pre id="code">client = AsyncOpenAI(base_url=URL)
scorer = Faithfulness(llm=llm_factory(MODEL, client=client))
result = await scorer.ascore(user_input=q, response=a)</pre>
</div>
<script>
const tl = gsap.timeline({ paused: true });
const n = __N__, S = __SECONDS__;
for (let i = 0; i < n; i++) {
  tl.to(".box", { opacity: 0.32, duration: 0.4 }, i * S / n);
  tl.to("#b" + i, { opacity: 1, scale: 1.06, duration: 0.4, yoyo: true, repeat: 1 }, i * S / n);
}
tl.fromTo("#code", { opacity: 0.4 }, { opacity: 1, duration: S * 0.8 }, 0.5);
window.__timelines["probe"] = tl;
</script></body></html>"""


def probe_dir(seconds: float) -> Path:
    tmp = Path(tempfile.mkdtemp(prefix="lectern-probe-"))
    boxes = "\n".join(f'<div class="box" id="b{i}" style="left:{112 + (i % 4) * 430}px; top:{120 + (i // 4) * 220}px">Node {i + 1}</div>'
                      for i in range(8))
    html = PROBE.replace("__SECONDS__", f"{seconds:g}").replace("__BOXES__", boxes).replace("__N__", "8")
    (tmp / "index.html").write_text(html)
    (tmp / "vendor").mkdir()
    shutil.copyfile(node_root() / "node_modules/gsap/dist/gsap.min.js", tmp / "vendor/gsap.min.js")
    (tmp / "fonts").mkdir()
    shutil.copyfile(node_root() / "node_modules/@fontsource/inter/files/inter-latin-600-normal.woff2", tmp / "fonts/inter-latin-600-normal.woff2")
    shutil.copyfile(node_root() / "node_modules/@fontsource/jetbrains-mono/files/jetbrains-mono-latin-400-normal.woff2",
                    tmp / "fonts/jetbrains-mono-latin-400-normal.woff2")
    return tmp


def mem_gb() -> float:
    try:
        with open("/proc/meminfo") as fh:
            kb = int(next(row for row in fh if row.startswith("MemTotal")).split()[1])
        return round(kb / 1048576, 1)
    except Exception:
        return 0.0


def run_profile(seconds: float = 10.0, log=print) -> dict:
    cpus = os.cpu_count() or 1
    candidates = sorted({1, 2, max(1, cpus // 2)})
    comp = probe_dir(seconds)
    env = {**os.environ, "HYPERFRAMES_NO_TELEMETRY": "1", "DO_NOT_TRACK": "1"}
    timings = {}
    try:
        for w in candidates:
            out = comp / f"probe-{w}.mp4"
            t0 = time.time()
            p = subprocess.run([str(node_bin("hyperframes")), "render", str(comp), "--output", str(out), "--fps", "30",
                                "--workers", str(w)], capture_output=True, text=True, env=env)
            if p.returncode:
                log(f"profile: {w} worker(s) failed, skipping")
                continue
            timings[w] = round(time.time() - t0, 2)
            log(f"profile: {w} worker(s) rendered {seconds:g} s of video in {timings[w]} s")
    finally:
        shutil.rmtree(comp, ignore_errors=True)
    if not timings:
        raise LecternError("every probe render failed. Run `npx hyperframes doctor` in the tool repo")
    best = min(timings, key=timings.get)
    profile = load_machine()
    profile["render"] = {"workers": best, "probed": dt.date.today().isoformat(), "cpus": cpus, "mem_gb": mem_gb(),
                         "seconds_per_probe": {str(k): v for k, v in timings.items()}, "probe_seconds": seconds}
    path = save_machine(profile)
    return {"workers": best, "path": str(path), "timings": timings}
