"""The terms registry: pronunciation, glossary chips and the glossary page all come from one place.

House terms load first, then course terms overlay them by key.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

from .config import load_yaml
from .paths import LecternError

ACRONYM_RE = re.compile(r"\b[A-Z][A-Z0-9]{1,}s?\b")


@dataclass
class Term:
    key: str
    term: str
    define: str | None
    say: str | None
    phonemes: str | None
    aliases: list[str]
    status: str

    @property
    def surfaces(self) -> list[str]:
        forms = {self.term, *self.aliases}
        return sorted({f for f in forms if f}, key=len, reverse=True)


class Registry:
    def __init__(self, entries: dict[str, Term]):
        self.entries = entries
        self._surface = {}
        for t in entries.values():
            for s in t.surfaces:
                self._surface[s.lower()] = t
        forms = sorted(self._surface, key=len, reverse=True)
        self._re = re.compile(r"(?<![\w-])(" + "|".join(re.escape(f) for f in forms) + r")(?![\w-])", re.I) if forms else None

    @classmethod
    def load(cls, house_terms: dict, course_terms_path: Path | None) -> "Registry":
        merged: dict = {}
        sources = [house_terms or {}]
        if course_terms_path and course_terms_path.exists():
            sources.append(load_yaml(course_terms_path) or {})
        for src in sources:
            for key, raw in src.items():
                raw = raw or {}
                merged[key] = Term(
                    key=key,
                    term=str(raw.get("term", key)),
                    define=raw.get("define"),
                    say=raw.get("say"),
                    phonemes=raw.get("phonemes"),
                    aliases=[str(a) for a in raw.get("aliases", [])],
                    status=raw.get("status", "accepted"),
                )
        return cls(merged)

    def get(self, word_or_key: str) -> Term | None:
        return self.entries.get(word_or_key) or self._surface.get(word_or_key.lower())

    def find_all(self, text: str) -> list[tuple[int, int, Term]]:
        if not self._re:
            return []
        return [(m.start(), m.end(), self._surface[m.group(0).lower()]) for m in self._re.finditer(text)]

    def covers(self, word: str) -> bool:
        return word.lower() in self._surface

    def apply(self, text: str) -> tuple[str, list[dict]]:
        """Rewrite a sentence for Kokoro. Phonemes use Kokoro's inline [word](/ipa/) syntax, respellings replace the word.

        Returns the TTS text and one record per replacement, in order, for timestamp alignment.
        """
        out, pos, reps = "", 0, []
        for start, end, term in self.find_all(text):
            out += text[pos:start]
            original = text[start:end]
            if term.phonemes:
                rendered = f"[{original}](/{term.phonemes}/)"
                expect = [original]
            elif term.say and term.say.lower() != original.lower():
                rendered = term.say
                expect = term.say.split()
            else:
                rendered, expect = original, original.split()
            reps.append({"start": start, "end": end, "original": original, "rendered": rendered,
                         "expect": expect, "term": term.key})
            out += rendered
            pos = end
        out += text[pos:]
        return out, reps


@lru_cache(maxsize=1)
def _g2p():
    from misaki import en

    return en.G2P(trf=False, british=False, fallback=None)


def unknown_words(text: str, registry: Registry) -> list[str]:
    """Words Kokoro's dictionary lacks, plus every acronym, that the registry does not cover."""
    found: list[str] = []
    masked = text
    for start, end, _ in registry.find_all(text):
        masked = masked[:start] + " " * (end - start) + masked[end:]
    for m in ACRONYM_RE.finditer(masked):
        found.append(m.group(0))
    _, tokens = _g2p()(masked)
    for t in tokens:
        if t.phonemes is None and re.search(r"[A-Za-z]", t.text or ""):
            found.append(t.text)
    seen, out = set(), []
    for w in found:
        if w.lower() not in seen and not registry.covers(w):
            seen.add(w.lower())
            out.append(w)
    return out


def write_term(path: Path, key: str, fields: dict) -> None:
    """Add or update one registry entry, keeping the rest of the file as written."""
    import yaml

    data = load_yaml(path) if path.exists() else {}
    if not isinstance(data, dict):
        raise LecternError(f"{path} must be a mapping of term keys")
    entry = dict(data.get(key) or {})
    entry.update({k: v for k, v in fields.items() if v is not None})
    data[key] = entry
    path.write_text(yaml.safe_dump(data, sort_keys=False, allow_unicode=True), encoding="utf-8")
