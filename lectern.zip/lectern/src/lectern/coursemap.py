"""coursemap: the course Map, one map.yaml per course.

map.yaml pins every component to a grid, so the Map never moves between lessons. Auto-layout drafts positions once,
for the components that have none. After that, positions are frozen: only a person moves a component, and every lesson
that draws the Map re-renders.
"""
from __future__ import annotations

import hashlib
import re
from itertools import combinations
from pathlib import Path

from .config import CourseManifest, House, load_yaml
from .paths import CoursePaths, LecternError

ID_RE = re.compile(r"[a-z0-9][a-z0-9_-]*")
BOX_GAP = 24  # px that two components keep between them on the 1920x1080 frame


def map_file(paths: CoursePaths, course: CourseManifest) -> Path | None:
    return paths.root / course.map if course.map else None


def map_problems(spec: dict, where: str, need_positions: bool = True) -> list[str]:
    """Everything wrong with a map.yaml, so one run reports all of it."""
    errs: list[str] = []
    grid = spec.get("grid", [12, 6])
    if not (isinstance(grid, list) and len(grid) == 2 and all(isinstance(g, (int, float)) and g > 0 for g in grid)):
        errs.append(f"{where}: grid must be [columns, rows], such as [12, 6]")
        grid = [12, 6]
    nodes, edges = spec.get("nodes") or [], spec.get("edges") or []
    if not nodes:
        errs.append(f"{where}: the Map has no components. List them under nodes")
    seen: set[str] = set()
    node_ids: set[str] = set()
    for n in nodes:
        nid = str(n.get("id", ""))
        if not ID_RE.fullmatch(nid):
            errs.append(f"{where}: component id {nid!r}: use lowercase letters, digits, dashes and underscores")
            continue
        if nid in seen:
            errs.append(f"{where}: id {nid} appears twice")
        seen.add(nid)
        node_ids.add(nid)
        if not str(n.get("label", "")).strip():
            errs.append(f"{where}: component {nid} has no label")
        at = n.get("at")
        if at is None:
            if need_positions:
                errs.append(f"{where}: component {nid} has no position. Run `lectern map draft` once to draft every "
                            "missing one, then positions are frozen")
        elif not (isinstance(at, list) and len(at) == 2 and all(isinstance(v, (int, float)) for v in at)
                  and 0 <= at[0] <= grid[0] and 0 <= at[1] <= grid[1]):
            errs.append(f"{where}: component {nid} sits at {at}, outside the {grid[0]} by {grid[1]} grid")
    for e in edges:
        eid = str(e.get("id", ""))
        if not ID_RE.fullmatch(eid):
            errs.append(f"{where}: edge id {eid!r}: use lowercase letters, digits, dashes and underscores")
            continue
        if eid in seen:
            errs.append(f"{where}: id {eid} appears twice")
        seen.add(eid)
        for end in ("from", "to"):
            if e.get(end) not in node_ids:
                errs.append(f"{where}: edge {eid} points at unknown component {e.get(end)}")
        if e.get("from") == e.get("to"):
            errs.append(f"{where}: edge {eid} starts and ends on {e.get('from')}")
        if e.get("label_side") not in (None, "above", "below", "left", "right"):
            errs.append(f"{where}: edge {eid} label_side is above, below, left or right, not {e.get('label_side')!r}")
    return errs


def load_map(paths: CoursePaths, course: CourseManifest, need_positions: bool = True) -> dict:
    p = map_file(paths, course)
    if p is None:
        raise LecternError("this course has no Map. Add `map: map.yaml` to course.yaml and list its components there")
    spec = load_yaml(p)
    if not isinstance(spec, dict):
        raise LecternError(f"{p}: expected grid, nodes and edges")
    errs = map_problems(spec, p.name, need_positions)
    if errs:
        raise LecternError("\n  ".join(errs))
    spec["_path"], spec["_hash"] = str(p), hashlib.sha256(p.read_bytes()).hexdigest()
    return spec


def map_hash(paths: CoursePaths, course: CourseManifest) -> str | None:
    p = map_file(paths, course)
    return hashlib.sha256(p.read_bytes()).hexdigest() if p and p.exists() else None


# ----------------------------------------------------------------------------- geometry


def map_geometry(spec: dict, tokens: dict, W: int = 1920, H: int = 1080) -> tuple[list, list, dict]:
    """The same boxes and lines a diagram gets, plus a check that no two components overlap. A diagram lives in one
    scene, a Map in every lesson, so a collision here would repeat everywhere."""
    from .render import diagram_geometry

    nodes, edges, boxes = diagram_geometry(spec, tokens, W, H)
    for a, b in combinations(nodes, 2):
        apart_x = max(a["x"], b["x"]) - min(a["x"] + a["w"], b["x"] + b["w"])
        apart_y = max(a["y"], b["y"]) - min(a["y"] + a["h"], b["y"] + b["h"])
        if max(apart_x, apart_y) < BOX_GAP:
            raise LecternError(f"map.yaml: {a['id']} and {b['id']} overlap on screen. Move one of them a row or "
                               "column away")
    return nodes, edges, boxes


def site_map(spec: dict, tokens: dict, W: int = 1920, H: int = 1080, pad: int = 40) -> dict:
    """The Map for a page: the video's own geometry, cropped to what it draws. Labels and lines match the frames."""
    from .render import text_width

    nodes, edges, _ = map_geometry(spec, tokens, W, H)
    small = tokens["size"]["small"]
    xs = [n["x"] for n in nodes] + [n["x"] + n["w"] for n in nodes]
    ys = [n["y"] for n in nodes] + [n["y"] + n["h"] for n in nodes]
    for e in edges:
        if e.get("label"):
            half = text_width(e["label"], small, "400") / 2
            xs += [e["lx"] - half, e["lx"] + half]
            ys += [e["ly"] - small, e["ly"] + small]
    x0, y0 = max(0, min(xs) - pad), max(0, min(ys) - pad)
    x1, y1 = min(W, max(xs) + pad), min(H, max(ys) + pad)
    return {"heading": spec.get("heading"), "viewBox": [round(x0), round(y0), round(x1 - x0), round(y1 - y0)],
            "font": {"node": tokens["size"]["node"], "label": small, "radius": tokens["space"]["radius"]},
            "nodes": [{k: n[k] for k in ("id", "x", "y", "w", "h", "cx", "cy", "lines", "line_h", "role")}
                      for n in nodes],
            "edges": [{k: e[k] for k in ("id", "d", "label", "lx", "ly")} for e in edges]}


# ----------------------------------------------------------------------------- trace paths


def trace_hops(spec: dict, target: str) -> list[dict]:
    """What a trace follows: one edge by id, in its own direction, or a path of components such as browser>app>llm,
    where each step crosses one edge in either direction."""
    edges = spec.get("edges") or []
    by_id = {e["id"]: e for e in edges}
    target = (target or "").strip()
    if ">" not in target:
        e = by_id.get(target)
        if not e:
            raise ValueError(f"{target!r} is not an edge. Name an edge, or a path of components such as a>b>c")
        return [{"edge": e["id"], "from": e["from"], "to": e["to"]}]
    names = [x.strip() for x in target.split(">")]
    known = {n["id"] for n in spec.get("nodes") or []}
    bad = [x for x in names if x not in known]
    if bad:
        raise ValueError(f"{', '.join(bad)}: not a component of this Map")
    hops = []
    for a, b in zip(names, names[1:]):
        e = next((e for e in edges if (e["from"], e["to"]) == (a, b)), None) or \
            next((e for e in edges if (e["from"], e["to"]) == (b, a)), None)
        if e is None:
            raise ValueError(f"no edge joins {a} and {b}")
        hop = {"edge": e["id"], "from": a, "to": b}
        if e["from"] != a:
            hop["reverse"] = True  # crosses the edge against its arrow, as an answer coming back does
        hops.append(hop)
    return hops


# ----------------------------------------------------------------------------- drafting


def draft_positions(spec: dict) -> dict[str, list[float]]:
    """Grid positions for components that have none. Columns follow the edges, sources on the left. Rows spread
    each column evenly. Components that already have a position keep it: drafting never moves the Map."""
    gx, gy = spec.get("grid", [12, 6])
    order = [n["id"] for n in spec.get("nodes") or []]
    preds: dict[str, list[str]] = {n: [] for n in order}
    for e in spec.get("edges") or []:
        if e.get("from") in preds and e.get("to") in preds:
            preds[e["to"]].append(e["from"])
    # Longest path from the sources, in declaration order, so a cycle cannot loop forever.
    layer: dict[str, int] = {}
    remaining = list(order)
    while remaining:
        ready = [n for n in remaining if all(p in layer for p in preds[n])] or remaining[:1]
        for n in ready:
            layer[n] = max((layer[p] + 1 for p in preds[n] if p in layer), default=0)
            remaining.remove(n)
    cols = max(layer.values(), default=0) + 1
    out: dict[str, list[float]] = {}
    row_of: dict[str, float] = {}
    for k in range(cols):
        members = [n for n in order if layer[n] == k]
        # Keep a component level with what feeds it, where it can.
        members.sort(key=lambda n: (sum(row_of.get(p, 0) for p in preds[n]) / len(preds[n]) if preds[n] else 0,
                                    order.index(n)))
        x = gx / 2 if cols == 1 else 1.5 + k * (gx - 3) / (cols - 1)
        for i, n in enumerate(members):
            y = (i + 1) * gy / (len(members) + 1)
            row_of[n] = y
            out[n] = [round(x, 1), round(y, 1)]
    have = {n["id"] for n in spec.get("nodes") or [] if n.get("at") is not None}
    return {n: xy for n, xy in out.items() if n not in have}


def write_positions(path: Path, positions: dict[str, list[float]]) -> None:
    """Add `at` to each drafted component in place, keeping the file's comments and layout. A component written as a
    block mapping gets its own `at:` line under its id."""
    text = path.read_text(encoding="utf-8")
    for nid, (x, y) in positions.items():
        at = f"at: [{x:g}, {y:g}]"
        flow = re.compile(r"(\{\s*id:\s*" + re.escape(nid) + r"\s*(?:,[^{}\n]*?)?)(\s*\})")
        m = flow.search(text)
        if m:
            text = text[:m.start()] + m.group(1) + f", {at}" + m.group(2) + text[m.end():]
            continue
        block = re.compile(r"^(?P<ind>\s*)- id:\s*" + re.escape(nid) + r"\s*$", re.M)
        m = block.search(text)
        if not m:
            raise LecternError(f"{path.name}: cannot find component {nid} to write its position. Add `{at}` by hand")
        text = text[:m.end()] + "\n" + m.group("ind") + "  " + at + text[m.end():]
    path.write_text(text, encoding="utf-8")


def draft_map(paths: CoursePaths, course: CourseManifest, house: House) -> dict[str, list[float]]:
    p = map_file(paths, course)
    if p is None:
        raise LecternError("this course has no Map. Add `map: map.yaml` to course.yaml first")
    spec = load_yaml(p)
    errs = map_problems(spec, p.name, need_positions=False)
    if errs:
        raise LecternError("\n  ".join(errs))
    positions = draft_positions(spec)
    if not positions:
        return positions
    write_positions(p, positions)
    spec = load_map(paths, course)
    try:
        map_geometry(spec, house.tokens)  # a draft that collides says so now, not in the first render
    except LecternError as e:
        raise LecternError(f"drafted {len(positions)} positions into {p.name}, but {e}") from None
    return positions
