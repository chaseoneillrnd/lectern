"""compile: parse the script, validate cues, targets, claim tags and terms, and emit a scene plan."""
from __future__ import annotations

import hashlib
import json
import re
from dataclasses import asdict
from pathlib import Path

from .config import CourseManifest, House, load_yaml
from .paths import CoursePaths, LecternError
from .script import NO_CLAIM, Scene, parse_lesson
from .terms import Registry, unknown_words

LAYOUTS_READY = {"title", "map", "diagram", "code", "cast", "steps", "checkpoint"}
LAYOUTS_LATER = {"chapter": "after the pilot", "split": "after the pilot"}
GRAPH_LAYOUTS = {"diagram", "map"}
# Element ids a lesson page already uses: VitePress's own shell, and the sections and chips Lectern generates. A scene
# id becomes its section's id, so a scene named like one of these would break its link and its place in the video.
PAGE_IDS = {"app", "before", "commands", "local-search", "VPContent", "VPSidebarNav", "main-nav-aria-label",
            "sidebar-aria-label", "doc-outline-aria-label", "check-mac-os", "check-dark-mode"}
VERB_LAYOUTS = {
    "light": {"diagram", "map", "steps"},
    "pulse": {"diagram", "map", "steps"},
    "trace": {"diagram", "map"},
    "callout": {"diagram", "map", "code", "steps"},
    "lines": {"code"},
    "play": {"cast", "steps"},
    "zoom": {"steps"},
    "pan": {"steps"},
    "spotlight": {"steps"},
    "arrow": {"steps"},
    "chip": {"title", "map", "diagram", "code", "cast", "steps", "checkpoint"},
    "mark": {"cast"},
}


# Numbers are written as words for the voice, so a spoken quantity marks a sentence technical just as a digit does.
# "one" is left out because it is everywhere in plain English ("one thing"). "point" catches "zero point five".
NUMBER_WORDS = re.compile(
    r"\b(zero|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|"
    r"eighteen|nineteen|twenty|thirty|forty|fifty|sixty|seventy|eighty|ninety|hundred|thousand|million|billion|"
    r"percent|point (zero|one|two|three|four|five|six|seven|eight|nine))\b", re.I)


class Plan(dict):
    """The scene plan: a JSON-friendly dict with the parsed lesson and everything resolved for later stages."""


def sha(data: bytes | str) -> str:
    return hashlib.sha256(data.encode() if isinstance(data, str) else data).hexdigest()


def load_diagram(paths: CoursePaths, name: str) -> dict:
    p = paths.diagrams / f"{name}.yaml"
    d = load_yaml(p)
    nodes = {n["id"]: n for n in d.get("nodes", [])}
    edges = {e["id"]: e for e in d.get("edges", [])}
    for e in edges.values():
        for end in ("from", "to"):
            if e[end] not in nodes:
                raise LecternError(f"{p}: edge {e['id']} points at unknown node {e[end]}")
    d["_path"], d["_hash"] = str(p), sha(p.read_bytes())
    return d


def parse_range(value: str) -> tuple[int, int]:
    m = re.fullmatch(r"(\d+)(?:-(\d+))?", value or "")
    if not m:
        raise ValueError(f"expected N or N-M, got {value!r}")
    a, b = int(m.group(1)), int(m.group(2) or m.group(1))
    if b < a:
        raise ValueError(f"range {value} runs backwards")
    return a, b


def resolve_label(span: str, candidates: dict[str, dict]) -> str | None:
    """Match a span like 'answer' or 'the answers' to a node or edge by id or label."""
    words = re.sub(r"[^a-z0-9 ]", "", span.lower()).split()
    keys = {k.lower(): k for k in candidates}
    labels: dict[str, str] = {}
    for k, v in candidates.items():
        label = str(v.get("label", "")).lower()
        labels[re.sub(r"\s+", " ", label).strip()] = k
        labels.setdefault(label.split("\n")[0].strip(), k)
    for n in range(len(words), 0, -1):
        for i in range(len(words) - n + 1):
            phrase = " ".join(words[i:i + n])
            for form in (phrase, phrase.rstrip("s"), phrase + "s"):
                if form in keys:
                    return keys[form]
                if form in labels:
                    return labels[form]
    return None


def compile_lesson(paths: CoursePaths, course: CourseManifest, house: House, lesson_id: str) -> tuple[Plan, list[str]]:
    script_path = paths.lesson_script(lesson_id)
    if not script_path.exists():
        raise LecternError(f"No script at {script_path}")
    verbs = set(house.motion["verbs"])
    lesson = parse_lesson(script_path, verbs)
    if lesson.id != lesson_id:
        raise LecternError(f"{script_path}: front matter id {lesson.id!r} does not match the file name")
    registry = Registry.load(house.terms, paths.root / (course.terms or "terms.yaml"))
    errors: list[str] = []
    warnings: list[str] = []

    def err(where, msg):
        errors.append(f"{script_path.name}:{where}: {msg}")

    # A lesson opens on its title card.
    if not lesson.scenes or lesson.scenes[0].layout != "title":
        lesson.scenes.insert(0, Scene(id="title", layout="title", params={}, sentences=[], line=1))

    # The course Map loads once, for every map scene and for a drilldown's opening.
    course_map: dict | None = None
    map_error: str | None = None
    if course.map and (any(s.layout == "map" for s in lesson.scenes) or lesson.front.get("type") == "drilldown"):
        from .coursemap import load_map, map_geometry

        try:
            course_map = load_map(paths, course)
            map_geometry(course_map, house.tokens)
        except LecternError as e:
            map_error = str(e)

    ledger_path = paths.claims_ledger(lesson_id)
    ledger = load_yaml(ledger_path) if ledger_path.exists() else {}
    captures = set(lesson.front.get("captures", []) or [])
    used_claims: set[str] = set()
    used_terms: dict[str, dict] = {}
    unreviewed_nc: list[str] = []
    resolved_scenes = []

    for scene in lesson.scenes:
        info: dict = {"id": scene.id, "layout": scene.layout, "params": dict(scene.params), "line": scene.line}
        if scene.id in PAGE_IDS or scene.id.startswith(("term-", "cp-")):
            err(scene.line, f"scene id `{scene.id}` collides with an id the lesson page already uses. Rename the scene, "
                            f"such as `the-{scene.id}`")
        if scene.layout in LAYOUTS_LATER:
            err(scene.line, f"layout={scene.layout} is not built yet. It arrives {LAYOUTS_LATER[scene.layout]}")
        elif scene.layout not in LAYOUTS_READY:
            err(scene.line, f"unknown layout={scene.layout}")

        targets: dict[str, dict] = {}
        if scene.layout == "map":
            if not course.map:
                err(scene.line, "layout=map draws the course Map, and this course has none. Add `map: map.yaml` to "
                                "course.yaml")
            elif map_error:
                err(scene.line, map_error)
            else:
                info["map"] = course_map
                targets = {n["id"]: n for n in course_map["nodes"]} | {e["id"]: e for e in course_map.get("edges", [])}
                comp = scene.params.get("component")
                if comp is not None:
                    if comp not in {n["id"] for n in course_map["nodes"]}:
                        err(scene.line, f"component={comp} is not on the Map. Components: "
                                        f"{', '.join(n['id'] for n in course_map['nodes'])}")
                    else:
                        info["component"] = comp
        elif scene.layout == "diagram":
            name = scene.params.get("diagram")
            if not name:
                err(scene.line, "a diagram scene needs diagram=<name>")
            else:
                try:
                    d = load_diagram(paths, name)
                    info["diagram"] = d
                    targets = {n["id"]: n for n in d.get("nodes", [])} | {e["id"]: e for e in d.get("edges", [])}
                except LecternError as e:
                    err(scene.line, str(e))
        elif scene.layout == "code":
            src = scene.params.get("src")
            code, source = None, None
            if src and ":" in src and src.split(":", 1)[0] in course.sources:
                # src=<source>:<path> shows a file from a pinned source, such as the stack, at its pinned commit.
                from .sources import read_source

                source, rel = src.split(":", 1)
                try:
                    code = read_source(course, source, rel)
                except LecternError as e:
                    err(scene.line, str(e))
            elif not src or not (paths.root / src).exists():
                err(scene.line, f"code scene needs src=<file> in the course, or src=<source>:<path>, got {src!r}")
            else:
                code = (paths.root / src).read_text(encoding="utf-8")
            if code is not None:
                n_lines = len(code.rstrip("\n").split("\n"))
                try:
                    show = parse_range(scene.params.get("show", f"1-{n_lines}"))
                except ValueError as e:
                    err(scene.line, f"show: {e}")
                    show = (1, n_lines)
                if show[1] > n_lines:
                    err(scene.line, f"show={show[0]}-{show[1]} runs past the file's {n_lines} lines")
                window = show[1] - show[0] + 1
                floor = house.tokens["floor"]["code_lines"]
                if window > floor:
                    err(scene.line, f"{window} code lines on screen, the floor is {floor}. Narrow it with show=a-b")
                info["code"] = {"src": src, "lang": scene.params.get("lang", Path(src).suffix.lstrip(".") or "text"),
                                "show": list(show), "hash": sha(code)}
                if source:
                    pin = course.sources[source]
                    from .sources import repo_name

                    info["code"].update(source=source, path=src.split(":", 1)[1], ref=pin.ref, commit=pin.commit,
                                        text=code, folder=repo_name(pin.repo))
        elif scene.layout == "cast":
            cap = scene.params.get("capture")
            if not cap:
                err(scene.line, "a cast scene needs capture=<id>")
            else:
                cast = paths.captures / f"{cap}.cast"
                if cap not in captures:
                    err(scene.line, f"capture {cap} is not listed in front matter captures")
                if not cast.exists():
                    err(scene.line, f"no cast at {cast.relative_to(paths.root)}. Run `lectern capture {cap}`")
                else:
                    info["cast"] = {"id": cap, "path": str(cast), "hash": sha(cast.read_bytes())}
        elif scene.layout == "steps":
            cap = scene.params.get("capture")
            if not cap:
                err(scene.line, "a steps scene needs capture=<id>")
            else:
                from .steps import load_capture, step_index

                if cap not in captures:
                    err(scene.line, f"capture {cap} is not listed in front matter captures")
                try:
                    capture = load_capture(paths, cap)
                    start = step_index(capture, scene.params["from"]) if scene.params.get("from") else 0
                    files = [paths.captures / cap / "meta.json", paths.captures / cap / "targets.json"]
                    info["steps"] = {"id": cap, "start": start, "hash": sha(b"".join(f.read_bytes() for f in files))}
                    targets = {t: {"id": t, "label": t.replace("-", " ")} for t in capture["targets"]}
                except LecternError as e:
                    err(scene.line, str(e))
        elif scene.layout == "checkpoint":
            seq = [s.kind for s in scene.sentences]
            if "ask" not in seq or "answer" not in seq:
                err(scene.line, "a checkpoint needs both > ask: and > answer:")
            if "narration" in seq:
                err(scene.line, "a checkpoint scene holds only > ask: and > answer: lines. Move narration to the scene before")
            if "answer" in seq and "ask" in seq[seq.index("answer"):]:
                err(scene.line, "one question per checkpoint scene. Start another checkpoint scene for the next question")

        sentences_out = []
        for s in scene.sentences:
            # Terms: every unknown word and acronym needs a registry entry.
            for w in unknown_words(s.text, registry):
                err(s.line, f"`{w}` is not in Kokoro's dictionary or the terms registry. Add it to terms.yaml and audition it")
            for _, _, term in registry.find_all(s.text):
                used_terms[term.key] = asdict(term)
            # Claims: technical sentences carry a tag, every tag exists in the ledger.
            technical = (bool(registry.find_all(s.text)) or bool(re.search(r"\d", s.text))
                         or bool(NUMBER_WORDS.search(s.text)) or s.kind == "answer")
            real_claims = [c for c in s.claims if c != NO_CLAIM]
            if NO_CLAIM in s.claims:
                unreviewed_nc.append(f"{s.id}: {s.text}")
            if technical and not s.claims and s.kind != "ask":
                err(s.line, f"technical sentence without a claim tag: \"{s.text}\"")
            for c in real_claims:
                used_claims.add(c)
                if c not in ledger:
                    err(s.line, f"claim ^{c} is not in {ledger_path.name}")
            # Cues: known, ready verbs on valid targets.
            cues_out = []
            for cue in s.cues:
                spec = house.motion["verbs"].get(cue.verb)
                if spec is None:
                    err(cue.line, f"unknown verb `{cue.verb}`. The vocabulary is closed: {', '.join(house.motion['verbs'])}")
                    continue
                if not spec.get("ready"):
                    err(cue.line, f"verb `{cue.verb}` is not built yet")
                    continue
                if scene.layout not in VERB_LAYOUTS.get(cue.verb, set()):
                    err(cue.line, f"`{cue.verb}` does not work in a {scene.layout} scene")
                    continue
                target = cue.target
                if scene.layout == "steps" and cue.verb != "chip":
                    if "steps" not in info:
                        continue
                    if cue.verb == "play":
                        from .steps import expand_play, load_capture

                        try:
                            expand_play(load_capture(paths, info["steps"]["id"]), target, info["steps"]["start"])
                        except LecternError as e:
                            err(cue.line, f"`play`: {e}")
                            continue
                    elif cue.verb in ("zoom", "pan") and target == "page":
                        pass
                    else:
                        target = target or resolve_label(cue.span, targets)
                        if target not in targets:
                            err(cue.line, f"`{cue.verb}` target {cue.target or cue.span!r} is not a target of capture "
                                          f"{info['steps']['id']}. Targets: {', '.join(targets)}")
                            continue
                elif cue.verb == "trace":
                    graph = info.get("diagram") or info.get("map")
                    if graph is None:
                        continue
                    if not target:
                        target = resolve_label(cue.span, {e["id"]: e for e in graph.get("edges", [])})
                    from .coursemap import trace_hops

                    try:
                        cue.params["hops"] = trace_hops(graph, target or "")
                    except ValueError as e:
                        err(cue.line, f"`trace` {cue.target or cue.span!r}: {e}")
                        continue
                elif cue.verb in ("light", "pulse") or (cue.verb == "callout" and scene.layout in GRAPH_LAYOUTS):
                    graph = info.get("diagram") or info.get("map")
                    if graph is None:
                        continue
                    target = target or resolve_label(cue.span, targets)
                    where = "on the Map" if scene.layout == "map" else "in this diagram"
                    if target not in targets:
                        err(cue.line, f"`{cue.verb}` target {cue.target or cue.span!r} is not a node or edge {where}")
                        continue
                    if cue.verb == "callout" and target not in {n["id"] for n in graph["nodes"]}:
                        err(cue.line, f"a callout points at a box, and {target!r} is an arrow. Name a box with callout=<id>")
                        continue
                elif cue.verb in ("lines",) or (cue.verb == "callout" and scene.layout == "code"):
                    try:
                        a, b = parse_range(target or "")
                        show = info.get("code", {}).get("show", [1, 10 ** 6])
                        if a < show[0] or b > show[1]:
                            raise ValueError(f"lines {a}-{b} fall outside the shown window {show[0]}-{show[1]}")
                        target = f"{a}-{b}"
                    except ValueError as e:
                        err(cue.line, f"`{cue.verb}`: {e}")
                        continue
                elif cue.verb == "play":
                    # A cast plays whole (play=<capture>), one command at a time (play=<step id>, or a bare play for
                    # the next command), or a run of commands (play=<a>..<b>).
                    cap = scene.params.get("capture")
                    if target and target != cap:
                        from .capture import load_meta

                        ids = [m["id"] for m in load_meta(paths, cap).get("marks", [])]
                        wanted = target.split("..", 1) if ".." in target else [target]
                        missing = [w for w in wanted if w not in ids]
                        if missing:
                            err(cue.line, f"`play` target {target} is not a step of capture {cap}. Steps: "
                                          f"{', '.join(ids) or 'none recorded, so play the whole capture'}")
                            continue
                elif cue.verb == "mark":
                    # Outline text the terminal prints. It must be in the capture, and render checks it is on screen
                    # at the cue's word.
                    if not target:
                        err(cue.line, "`mark` needs the text to outline, such as {mark=\"0.734\"}")
                        continue
                    if cue.params.get("trail", "dim") not in ("dim", "clear"):
                        err(cue.line, f"`mark` trail is dim or clear, not {cue.params['trail']!r}")
                        continue
                    from .capture import cast_text

                    cap = scene.params.get("capture")
                    if cap and (paths.captures / f"{cap}.cast").exists() and \
                            target not in cast_text(paths.captures / f"{cap}.cast"):
                        err(cue.line, f"`mark` text {target!r} never appears in the output of capture {cap}")
                        continue
                elif cue.verb == "chip":
                    term = registry.get(target or cue.span)
                    if not term:
                        err(cue.line, f"`chip` needs a registry term, {target or cue.span!r} is not one")
                        continue
                    if not term.define:
                        err(cue.line, f"term {term.key} has no definition for its chip")
                        continue
                    target = term.key
                    used_terms[term.key] = asdict(term)
                if cue.verb == "callout":
                    text = cue.params.get("text", cue.span)
                    limit = house.tokens["floor"]["callout_words"]
                    if len(text.split()) > limit:
                        err(cue.line, f"callout \"{text}\" runs past {limit} words")
                        continue
                    cue.params["text"] = text
                cues_out.append({"verb": cue.verb, "target": target, "params": cue.params, "span": cue.span,
                                 "word_index": cue.word_index, "line": cue.line})
            d = asdict(s)
            if d["shown"] is None:
                del d["shown"]
            d["cues"] = cues_out
            d["claims"] = real_claims
            d["no_claim"] = NO_CLAIM in s.claims
            sentences_out.append(d)
        info["sentences"] = sentences_out
        resolved_scenes.append(info)

    # A drilldown opens on the course Map with its component lit, so the viewer always knows where they are.
    if course.map and lesson.front.get("type") == "drilldown":
        comp = lesson.front.get("component")
        first = next((s for s in resolved_scenes if s["layout"] != "title"), None)
        if not comp:
            err(1, "a drilldown names the Map component it covers in front matter: component: <id>")
        elif course_map and comp not in {n["id"] for n in course_map["nodes"]}:
            err(1, f"component: {comp} is not on the Map")
        elif first is None or first["layout"] != "map":
            err(first["line"] if first else 1, "a drilldown opens on the Map. Make its first scene layout=map")
        else:
            first.setdefault("component", comp)
    known = {x for x in (course.skeleton.quickstart, course.skeleton.map, *course.skeleton.drilldowns,
                         *course.skeleton.recipes) if x}
    for pre in lesson.front.get("prerequisites") or []:
        if pre not in known:
            warnings.append(f"prerequisite {pre} is not a lesson in this course's skeleton")

    for c in sorted(set(ledger) - used_claims):
        warnings.append(f"claim {c} is in the ledger but no sentence cites it")
    from . import __version__

    pinned_tool = course.pin_version("lectern")
    if pinned_tool and pinned_tool != __version__:
        warnings.append(f"course pins lectern {pinned_tool}, this is {__version__}. Frames may differ from the last build")

    # Rough length estimate before synthesis: Kokoro reads about 2.6 words a second at speed 1.0.
    words = sum(len(s["words"]) for sc in resolved_scenes for s in sc["sentences"])
    estimate_min = words / 2.6 / 60 + len(resolved_scenes) * 1.6 / 60
    plan = Plan(
        lesson={"id": lesson.id, "front": lesson.front, "path": lesson.path, "script_hash": sha(script_path.read_bytes())},
        course={"id": course.id, "title": course.title},
        scenes=resolved_scenes,
        terms=used_terms,
        claims_ledger=str(ledger_path),
        no_claim_sentences=unreviewed_nc,
        estimate_minutes=round(estimate_min, 2),
        warnings=warnings,
        map={"path": course_map["_path"], "hash": course_map["_hash"]} if course_map and any(
            s["layout"] == "map" for s in resolved_scenes) else None,
    )
    if errors:
        raise LecternError("compile failed:\n  " + "\n  ".join(errors))
    out = paths.build_dir(lesson_id)
    out.mkdir(parents=True, exist_ok=True)
    (out / "plan.json").write_text(json.dumps(plan, indent=1, ensure_ascii=False, default=str))
    return plan, warnings
