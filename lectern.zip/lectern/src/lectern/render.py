"""render: the renderer adapter. timeline.json + templates + captures -> one HyperFrames composition per scene.

Each scene renders on its own, cached under a hash of everything that shapes its frames, so editing one sentence
re-renders only the scenes whose frames changed. Scene videos are whole frames long and concatenate losslessly.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import shutil
import subprocess
import time
from functools import lru_cache
from pathlib import Path

import jinja2

from .capture import cast_text
from .config import House, load_machine
from .paths import CoursePaths, LecternError, node_bin, node_root, PACKAGE_DIR

PALETTE = ["#0d141d", "#ff7b72", "#3fb950", "#e3b341", "#4cc2ff", "#d2a8ff", "#56d4dd", "#c9d1d9",
           "#6e7681", "#ffa198", "#56d364", "#f2cc60", "#79c0ff", "#e2c5ff", "#76e3ea", "#ffffff"]
RUNG_LABEL = {"eli5": "ELI5", "foundations": "Foundations", "practitioner": "Practitioner", "expert": "Expert",
              "internals": "Internals"}
TYPE_LABEL = {"quickstart": "Quick start", "map": "Map", "drilldown": "Drilldown", "recipe": "Recipe"}


def sha(data: bytes | str) -> str:
    return hashlib.sha256(data.encode() if isinstance(data, str) else data).hexdigest()


@lru_cache(maxsize=1)
def node_versions() -> dict:
    out = {}
    for pkg in ("hyperframes", "gsap", "asciinema-player", "@fontsource/inter", "@fontsource/jetbrains-mono", "shiki"):
        p = node_root() / "node_modules" / pkg / "package.json"
        out[pkg] = json.loads(p.read_text())["version"] if p.exists() else None
    if not out["hyperframes"]:
        raise LecternError(f"HyperFrames is not installed under {node_root()}. Run npm ci in the tool repo")
    return out


@lru_cache(maxsize=1)
def browser_id() -> str:
    env_path = os.environ.get("HYPERFRAMES_BROWSER_PATH")
    if env_path:
        return env_path
    p = subprocess.run([str(node_bin("hyperframes")), "browser", "path"], capture_output=True, text=True,
                       env={**os.environ, "HYPERFRAMES_NO_TELEMETRY": "1", "DO_NOT_TRACK": "1"})
    return p.stdout.strip().splitlines()[-1] if p.returncode == 0 and p.stdout.strip() else "unknown"


# ----------------------------------------------------------------------------- text measurement


@lru_cache(maxsize=8)
def _font(weight: str, size: int):
    from PIL import ImageFont

    files = {"400": "inter-latin-400-normal.woff2", "600": "inter-latin-600-normal.woff2", "700": "inter-latin-700-normal.woff2"}
    path = node_root() / "node_modules/@fontsource/inter/files" / files[weight]
    try:
        return ImageFont.truetype(str(path), size)
    except Exception:
        return None


def text_width(text: str, size: int, weight: str = "600") -> float:
    f = _font(weight, size)
    if f is not None:
        return f.getlength(text)
    return len(text) * size * 0.58


# ----------------------------------------------------------------------------- layout geometry


def diagram_geometry(spec: dict, tokens: dict, W: int, H: int) -> tuple[list, list, dict]:
    gx, gy = spec.get("grid", [12, 6])
    pad = tokens["space"]["frame_pad"]
    x0, x1, y0, y1 = pad, W - pad, 150, H - 170
    cw, ch = (x1 - x0) / gx, (y1 - y0) / gy
    fs = tokens["size"]["node"]
    line_h = round(fs * 1.25)
    label_fs = tokens["size"]["small"]
    sizes, centers = {}, {}
    for n in spec.get("nodes", []):
        lines = str(n.get("label", n["id"])).split("\n")
        sizes[n["id"]] = (max(260, max(text_width(part, fs) for part in lines) + 84), 60 + line_h * len(lines), lines)
        centers[n["id"]] = (x0 + n["at"][0] * cw, y0 + n["at"][1] * ch)
    centers = _relax_columns(spec, sizes, centers, label_fs, x0, x1)
    nodes, boxes = [], {}
    for n in spec.get("nodes", []):
        w, h, lines = sizes[n["id"]]
        cx, cy = centers[n["id"]]
        box = {"id": n["id"], "x": round(cx - w / 2, 1), "y": round(cy - h / 2, 1), "w": round(w, 1), "h": round(h, 1),
               "cx": round(cx, 1), "cy": round(cy, 1), "lines": lines, "line_h": line_h, "role": n.get("role")}
        nodes.append(box)
        boxes[n["id"]] = box
    edges = []
    for e in spec.get("edges", []):
        a, b = boxes[e["from"]], boxes[e["to"]]
        sx, sy = _exit_point(a, b["cx"], b["cy"])
        ex, ey = _exit_point(b, a["cx"], a["cy"])
        dx, dy = ex - sx, ey - sy
        length = math.hypot(dx, dy) or 1
        ux, uy = dx / length, dy / length
        sx, sy = sx + ux * 8, sy + uy * 8
        ex, ey = ex - ux * 10, ey - uy * 10
        mx, my = (sx + ex) / 2, (sy + ey) / 2
        # label sits beside the line: above a horizontal edge, right of a vertical one
        lx, ly = (mx, my - 30) if abs(ux) >= abs(uy) else (mx + 18 + text_width(e.get("label", ""), tokens["size"]["small"], "400") / 2, my)
        side = e.get("label_side")
        if e.get("label") and min(abs(ux), abs(uy)) > DIAGONAL:
            # A slanted line runs through either spot, so the label steps off the line along its upward normal, or
            # its downward one when the edge asks for label_side: below.
            lw, lh = text_width(e["label"], tokens["size"]["small"], "400"), tokens["size"]["small"] * 1.2
            nx, ny = (uy, -ux) if ux > 0 else (-uy, ux)
            if side == "below":
                nx, ny = -nx, -ny
            off = 14 + abs(nx) * lw / 2 + abs(ny) * lh / 2
            lx, ly = mx + nx * off, my + ny * off
        elif e.get("label") and side == "below":
            lx, ly = mx, my + 30
        elif e.get("label") and side == "left":
            lx, ly = mx - 18 - text_width(e["label"], tokens["size"]["small"], "400") / 2, my
        edges.append({"id": e["id"], "d": f"M{sx:.1f},{sy:.1f} L{ex:.1f},{ey:.1f}", "label": e.get("label"),
                      "lx": round(lx, 1), "ly": round(ly, 1)})
    return nodes, edges, boxes


MIN_GAP = 100  # px between two boxes in one row with no labelled edge between them
LABEL_PAD = 28  # px either side of an edge label
DIAGONAL = 0.02  # sin 1°: an edge further than this from both axes is slanted, and its label moves off the line


def _relax_columns(spec: dict, sizes: dict, centers: dict, label_fs: int, x0: float, x1: float) -> dict:
    """Spread grid columns until every pair of boxes in a row clears its gap, labels included, then centre the
    diagram. Columns move as a whole, so boxes stacked in one column stay aligned and vertical edges stay vertical."""
    col_of = {n["id"]: float(n["at"][0]) for n in spec.get("nodes", [])}
    row_of = {n["id"]: float(n["at"][1]) for n in spec.get("nodes", [])}
    cols = sorted(set(col_of.values()))
    pos = {c: next(centers[i][0] for i in col_of if col_of[i] == c) for c in cols}
    labels = {}
    for e in spec.get("edges", []):
        if e.get("label") and row_of[e["from"]] == row_of[e["to"]]:
            pair = tuple(sorted((col_of[e["from"]], col_of[e["to"]])))
            labels[pair] = max(labels.get(pair, 0), text_width(e["label"], label_fs, "400") + 2 * LABEL_PAD)
    need: dict[float, list[tuple[float, float]]] = {c: [] for c in cols}
    for r in set(row_of.values()):
        ids = sorted((i for i in row_of if row_of[i] == r), key=lambda i: col_of[i])
        for a, b in zip(ids, ids[1:]):
            ca, cb = col_of[a], col_of[b]
            gap = max(MIN_GAP, labels.get((ca, cb), 0))
            need[cb].append((ca, (sizes[a][0] + sizes[b][0]) / 2 + gap))
    for c in cols:
        for ca, dist in need[c]:
            pos[c] = max(pos[c], pos[ca] + dist)
    left = min(pos[col_of[i]] - sizes[i][0] / 2 for i in col_of)
    right = max(pos[col_of[i]] + sizes[i][0] / 2 for i in col_of)
    if right - left > x1 - x0:
        raise LecternError(f"diagram is {right - left:.0f}px wide and the frame allows {x1 - x0:.0f}px. "
                           "Shorten labels or move boxes to another row")
    shift = (x0 + x1) / 2 - (left + right) / 2
    return {i: (pos[col_of[i]] + shift, centers[i][1]) for i in centers}


def _exit_point(box: dict, tx: float, ty: float) -> tuple[float, float]:
    cx, cy, hw, hh = box["cx"], box["cy"], box["w"] / 2, box["h"] / 2
    dx, dy = tx - cx, ty - cy
    if dx == 0 and dy == 0:
        return cx, cy
    scale = min(hw / abs(dx) if dx else math.inf, hh / abs(dy) if dy else math.inf)
    return cx + dx * scale, cy + dy * scale


# ----------------------------------------------------------------------------- code highlighting


def highlight(paths: CoursePaths, code: str, lang: str, theme: str = "dark-plus") -> list[list]:
    key = sha(json.dumps([code, lang, theme, node_versions()["shiki"]]))
    cached = paths.highlight_cache / f"{key}.json"
    if cached.exists():
        return json.loads(cached.read_text())
    # Run the script as --eval source from node_root, so `import "shiki"` resolves against the tool's node_modules
    # wherever the Python package itself is installed.
    script = (PACKAGE_DIR / "node" / "highlight.mjs").read_text(encoding="utf-8")
    p = subprocess.run(["node", "--input-type=module", "--eval", script],
                       input=json.dumps({"code": code, "lang": lang, "theme": theme}),
                       capture_output=True, text=True, cwd=node_root())
    if p.returncode:
        raise LecternError(f"code highlighting failed: {p.stderr[-500:]}")
    cached.parent.mkdir(parents=True, exist_ok=True)
    cached.write_text(p.stdout)
    return json.loads(p.stdout)


# ----------------------------------------------------------------------------- verbs


class Verbs:
    """Turns cues into GSAP calls. Only one lit target and one callout show at a time."""

    def __init__(self, motion: dict, tokens: dict):
        self.motion, self.tokens = motion, tokens
        self.js: list[str] = []
        self.lit: list[tuple[str, str]] = []  # (selector, node | edge), lit by the last light or trace
        self.reversed: set[str] = set()  # edges lit against their arrow, with the arrowhead moved to the start
        self.callout: str | None = None
        self.chip: str | None = None
        self.focus_started = False
        self.focus_origin = (0.0, 1.0)

    def spec(self, verb: str) -> tuple[float, str]:
        v = self.motion["verbs"][verb]
        return float(v["duration"]), v["ease"]

    def emit(self, line: str) -> None:
        self.js.append(line)

    def unlight(self, t: float, d: float, keep: set[str] = frozenset()) -> None:
        """Return every lit box and line to its resting stroke, except those in keep."""
        edge = self.tokens["color"]["edge"]
        for psel, pkind in self.lit:
            if psel in keep:
                continue
            if pkind == "node":
                self.emit(f'tl.to("{psel} .box", {{ stroke: "{edge}", strokeWidth: 3, duration: {d} }}, {t:.3f});')
            else:
                self.emit(f'tl.to("{psel} .line", {{ stroke: "{edge}", duration: {d} }}, {t:.3f});')
                if psel in self.reversed:
                    self.emit(f'tl.set("{psel} .line", {{ attr: {{ "marker-start": "none", "marker-end": "url(#arrow)" }} }}, '
                              f'{t:.3f});')
                    self.reversed.discard(psel)
                else:
                    self.emit(f'tl.set("{psel} .line", {{ attr: {{ "marker-end": "url(#arrow)" }} }}, {t:.3f});')
        self.lit = [x for x in self.lit if x[0] in keep]

    def stroke_lit(self, t: float, sel: str, kind: str, d: float, reverse: bool = False, marker_at: float | None = None,
                   both: bool = False) -> None:
        """Light a box or a line. A line crossed against its arrow gets its lit arrowhead at the start instead, so the
        lit path points the way the flow goes, and a line crossed both ways in one trace gets both."""
        accent = self.tokens["color"]["accent"]
        m = t if marker_at is None else marker_at
        if kind == "node":
            self.emit(f'tl.to("{sel} .box", {{ stroke: "{accent}", strokeWidth: 5, duration: {d} }}, {t:.3f});')
        else:
            self.emit(f'tl.to("{sel} .line", {{ stroke: "{accent}", duration: {d} }}, {t:.3f});')
            if both:
                self.emit(f'tl.set("{sel} .line", {{ attr: {{ "marker-end": "url(#arrow-lit)", "marker-start": "url(#arrow-lit)" }} }}, '
                          f'{m:.3f});')
                self.reversed.add(sel)
            elif reverse:
                self.emit(f'tl.set("{sel} .line", {{ attr: {{ "marker-end": "none", "marker-start": "url(#arrow-lit)" }} }}, '
                          f'{m:.3f});')
                self.reversed.add(sel)
            elif sel in self.reversed:
                self.emit(f'tl.set("{sel} .line", {{ attr: {{ "marker-start": "none", "marker-end": "url(#arrow-lit)" }} }}, '
                          f'{m:.3f});')
                self.reversed.discard(sel)
            else:
                self.emit(f'tl.set("{sel} .line", {{ attr: {{ "marker-end": "url(#arrow-lit)" }} }}, {m:.3f});')
        if (sel, kind) not in self.lit:
            self.lit.append((sel, kind))

    def light(self, t: float, target: str, kind: str) -> None:
        d, ease = self.spec("light")
        sel = f"#n-{target}" if kind == "node" else f"#e-{target}"
        self.emit(f'tl.to(".dimmable", {{ opacity: DIM, duration: {d}, ease: "{ease}" }}, {t:.3f});')
        self.emit(f'tl.to("{sel}", {{ opacity: 1, duration: {d}, ease: "{ease}" }}, {t:.3f});')
        self.unlight(t, d, keep={sel})
        self.stroke_lit(t, sel, kind, d)

    def trace(self, t: float, hops: list[dict], boxes: dict, tracer: str) -> float:
        """Flow along a path: dim the rest, then a dot runs centre to centre, lighting each line as it starts and
        each box as it arrives. The dot passes under the boxes, so it leaves one and enters the next. The path stays
        lit until the next light or trace. Returns when the dot arrives."""
        d, ease = self.spec("trace")
        ld, lease = self.spec("light")
        nodes = list(dict.fromkeys([hops[0]["from"], *(h["to"] for h in hops)]))
        sels = [f"#n-{n}" for n in nodes] + [f"#e-{e}" for e in dict.fromkeys(h["edge"] for h in hops)]
        self.emit(f'tl.to(".dimmable", {{ opacity: DIM, duration: {ld}, ease: "{lease}" }}, {t:.3f});')
        self.emit(f'tl.to("{", ".join(sels)}", {{ opacity: 1, duration: {ld}, ease: "{lease}" }}, {t:.3f});')
        # Whatever the new path shares with the last one stays lit. Reverting it here and lighting it again in the same
        # instant would leave two stroke tweens on one line, and the longer revert would win.
        self.unlight(t, ld, keep=set(sels))
        self.stroke_lit(t, f"#n-{hops[0]['from']}", "node", ld)
        a = boxes[hops[0]["from"]]
        self.emit(f'tl.set("#{tracer}", {{ x: {a["cx"]}, y: {a["cy"]}, opacity: 1 }}, {t:.3f});')
        ways: dict[str, set[bool]] = {}
        for k, h in enumerate(hops):
            tk = t + k * d
            b = boxes[h["to"]]
            ways.setdefault(h["edge"], set()).add(bool(h.get("reverse")))
            self.stroke_lit(tk, f"#e-{h['edge']}", "edge", 0.2, reverse=bool(h.get("reverse")), marker_at=tk + 0.1,
                            both=len(ways[h["edge"]]) == 2)
            self.emit(f'tl.to("#{tracer}", {{ x: {b["cx"]}, y: {b["cy"]}, duration: {d}, ease: "{ease}" }}, {tk:.3f});')
            self.stroke_lit(tk + d * 0.8, f"#n-{h['to']}", "node", 0.2)
        end = t + len(hops) * d
        self.emit(f'tl.set("#{tracer}", {{ opacity: 0 }}, {end:.3f});')
        return end

    def settle(self, t: float, d: float = 0.3) -> None:
        """Back to the plain Map, so the next map scene picks it up without a cut."""
        self.emit(f'tl.to(".dimmable", {{ opacity: 1, duration: {d}, ease: "power1.inOut" }}, {t:.3f});')
        self.unlight(t, d)

    def pulse(self, t: float, sel: str) -> None:
        d, ease = self.spec("pulse")
        self.emit(f'tl.to("{sel}", {{ scale: 1.06, duration: {d / 2:.3f}, ease: "{ease}", yoyo: true, repeat: 1, '
                  f'transformOrigin: "50% 50%" }}, {t:.3f});')

    def show_callout(self, t: float, cid: str, side: str) -> None:
        d, ease = self.spec("callout")
        xp, yp = {"": (-50, -100), "below": (-50, 0), "right": (0, -50)}[side]
        self.emit(f'tl.set("#{cid}", {{ xPercent: {xp}, yPercent: {yp} }}, 0);')
        if self.callout:
            self.emit(f'tl.to("#{self.callout}", {{ opacity: 0, duration: 0.2 }}, {t:.3f});')
        dy = 10 if side != "below" else -10
        self.emit(f'tl.fromTo("#{cid}", {{ opacity: 0, y: {dy} }}, {{ opacity: 1, y: 0, duration: {d}, ease: "{ease}" }}, {t:.3f});')
        self.callout = cid

    def show_chip(self, t: float, cid: str, hide_at: float | None = None) -> None:
        """A chip stays until the next chip replaces it, or until the narration moves on to something else, but
        never less than CHIP_MIN seconds, so it can be read."""
        d, ease = self.spec("chip")
        if self.chip:
            self.emit(f'tl.to("#{self.chip}", {{ opacity: 0, duration: 0.2 }}, {t:.3f});')
        self.emit(f'tl.fromTo("#{cid}", {{ opacity: 0, y: 12 }}, {{ opacity: 1, y: 0, duration: {d}, ease: "{ease}" }}, {t:.3f});')
        self.chip = cid
        if hide_at is not None:
            self.emit(f'tl.to("#{cid}", {{ opacity: 0, duration: 0.3 }}, {hide_at:.3f});')
            self.chip = None

    def lines(self, t: float, a: int, b: int, top: float, height: float) -> None:
        d, ease = self.spec("lines")
        sel = ", ".join(f"#ln-{n}" for n in range(a, b + 1))
        self.emit(f'tl.to(".ln", {{ opacity: DIM, duration: {d}, ease: "{ease}" }}, {t:.3f});')
        self.emit(f'tl.to("{sel}", {{ opacity: 1, duration: {d}, ease: "{ease}" }}, {t:.3f});')
        if not self.focus_started:
            self.emit(f'tl.set("#focus", {{ top: {top:.1f}, height: {height:.1f} }}, {t:.3f});')
            self.emit(f'tl.to("#focus", {{ opacity: 1, duration: {d}, ease: "{ease}" }}, {t:.3f});')
            self.focus_started = True
            self.focus_origin = (top, height)
        else:
            # Later moves use transforms: top and height snap to whole pixels while frames are captured one by one, so the
            # band would stutter, and HyperFrames refuses that motion.
            top0, h0 = self.focus_origin
            self.emit(f'tl.to("#focus", {{ y: {top - top0:.1f}, scaleY: {height / h0:.4f}, transformOrigin: "0% 0%", '
                      f'duration: {d}, ease: "{ease}" }}, {t:.3f});')


# ----------------------------------------------------------------------------- composing scenes


def code_text(paths: CoursePaths, code: dict) -> str:
    """The text a code scene shows: a course file, or a pinned source file the plan carries verbatim."""
    if code.get("text") is not None:
        return code["text"]
    return (paths.root / code["src"]).read_text(encoding="utf-8")


def terminal_font_px(width: int, tokens: dict, cols: int) -> float:
    """The terminal font size a cast renders at: the player scales the font so every column fits the window."""
    return (width - 2 * tokens["space"]["frame_pad"] - 56) / (cols * 0.6)


def code_columns(width: int, tokens: dict) -> int:
    """Characters a code row holds: the panel inside the frame pad, less its border, line numbers and right margin.
    House Mono advances 0.6 em a character."""
    return int((width - 2 * tokens["space"]["frame_pad"] - 4 - 96 - 56) // (tokens["size"]["code"] * 0.6))


HASH_COMMENTS = {"python", "py", "bash", "sh", "shell", "zsh", "console", "yaml", "yml", "dotenv", "toml", "ruby", "rb",
                 "perl", "r", "make", "makefile", "dockerfile", "ini", "conf", "properties", "powershell", "ps1"}


def code_shape(text: str, lang: str | None = None) -> tuple[list[bool], list[int], list[int]]:
    """How a reader sees one line of code: which characters sit in a string or a comment, the innermost bracket open
    before each character (-1 for none), and the brackets the line opens and leaves open, innermost last."""
    quoted, inner, stack = [False] * len(text), [-1] * len(text), []
    hash_comments = lang is None or lang.lower() in HASH_COMMENTS
    quote, i = None, 0
    while i < len(text):
        inner[i] = stack[-1] if stack else -1
        c = text[i]
        if quote:
            if text.startswith(quote, i):
                quoted[i:i + len(quote)] = [True] * len(quote)
                i, quote = i + len(quote), None
                continue
            span = 2 if c == "\\" and i + 1 < len(text) else 1
            quoted[i:i + span] = [True] * span
            i += span
            continue
        if (c == "#" and hash_comments) or (not hash_comments and text.startswith("//", i)):
            quoted[i:] = [True] * (len(text) - i)
            for k in range(i, len(text)):
                inner[k] = stack[-1] if stack else -1
            break
        if c in "\"'`":
            quote = text[i:i + 3] if text[i:i + 3] in ('"""', "'''") else c
            quoted[i:i + len(quote)] = [True] * len(quote)
            i += len(quote)
            continue
        if c in "([{":
            stack.append(i)
        elif c in ")]}" and stack:
            stack.pop()
        i += 1
    return quoted, inner, stack


def wrap_tokens(tokens: list[dict], cols: int, ink: str, lang: str | None = None) -> list[list[dict]]:
    """Split one highlighted line into rows of at most `cols` characters, as a careful editor would.

    A line that leaves a bracket open goes on, in the source, on a line aligned one column past that bracket. So its
    own rows align there too: they break after a comma or space directly inside the bracket, and the bracket keeps its
    column. Any other line breaks after its last space, comma or open bracket that fits, or after a `\\n` inside a
    string, where a template starts its own new line, and goes on at its indent plus four. Returns one row, unchanged,
    when the line fits."""
    text = "".join(t["text"] for t in tokens)
    if len(text) <= cols:
        return [tokens]
    styles = [t for t in tokens for _ in t["text"]]
    indent = len(text) - len(text.lstrip(" "))
    quoted, inner, still_open = code_shape(text, lang)

    def cut_anywhere(hi: int, lo: int) -> int:
        def ok(i: int) -> bool:
            if text[i - 1] == " ":
                return True
            if quoted[i - 1]:
                return text[i - 2:i] == "\\n" and quoted[i - 2]
            return text[i - 1] in ",([{"
        return next((i for i in range(hi, lo, -1) if ok(i)), hi)

    # A row that goes on starts at the line's indent plus four, so it reads as part of its line and never as a line
    # of the block around it. Only a line too deep to leave twenty characters there goes on further left.
    hang = next((c for c in (indent + 4, indent) if c <= cols - 20), cols // 2)

    def pieces_for(align: int | None) -> list[tuple[str, int, int]] | None:
        cont = " " * (align if align is not None else hang)
        out, start, prefix = [], 0, ""
        while len(prefix) + len(text) - start > cols:
            room = cols - len(prefix)
            hi, lo = start + room, start + max(room // 3, 1)
            if align is not None:
                inside = [i for i in range(hi, max(lo, align), -1)
                          if not quoted[i - 1] and inner[i - 1] == align - 1 and text[i - 1] in ", "]
                cut = next((i for i in inside if text[i - 1] == ","), None) or (inside[0] if inside else None)
                if cut is None:
                    return None
            else:
                cut = cut_anywhere(hi, lo)
            out.append((prefix, start, cut))
            start = cut
            while start < len(text) and text[start] == " ":
                start += 1
            prefix = cont
        out.append((prefix, start, len(text)))
        return out

    align = still_open[-1] + 1 if still_open and still_open[-1] + 1 <= cols - 20 else None
    pieces = (pieces_for(align) if align is not None else None) or pieces_for(None)
    rows = []
    for pre, a, b in pieces:
        row = [{"text": pre, "color": ink, "italic": False, "bold": False}] if pre else []
        for i in range(a, b):
            st = styles[i]
            if row and row[-1].get("_src") is st:
                row[-1]["text"] += text[i]
            else:
                row.append({**{k: st[k] for k in ("color", "italic", "bold")}, "text": text[i], "_src": st})
        for t in row:
            t.pop("_src", None)
        rows.append(row)
    return rows


CHIP_MIN = 3.5      # seconds a glossary chip stays up at least, so its definition can be read
MARK_DIM = 0.35     # opacity of a terminal mark once a newer one takes the accent
STEPS_PAD = 160     # px each side of the browser window
STEPS_BAR = 52      # px of browser chrome above the page
ZOOM_MAX = 1.8      # screenshots are 2x, so zooming past this starts to blur
SHADE = {"spotlight": "rgba(4, 7, 11, 0.74)", "light": "rgba(4, 7, 11, 0.52)"}


def zoom_for(box: list[float], view_w: float, view_h: float, z: float | None = None) -> tuple[float, float, float]:
    """Camera that frames a display-space box: scale and the layer offset that centres the box, clamped to the page."""
    x, y, w, h = box
    if z is None:
        z = min(0.72 * view_w / max(w, 1), 0.5 * view_h / max(h, 1))
        z = max(1.25, min(ZOOM_MAX, z))
    cx, cy = x + w / 2, y + h / 2
    tx = min(0.0, max(view_w * (1 - z), view_w / 2 - cx * z))
    ty = min(0.0, max(view_h * (1 - z), view_h / 2 - cy * z))
    return round(z, 4), round(tx, 1), round(ty, 1)


def compose_steps(paths: CoursePaths, scene: dict, tokens: dict, motion: dict, W: int, H: int):
    """GSAP for a steps scene from the timeline's planned actions: crossfades, cursor, bursts, camera and accents."""
    from .steps import images_used, load_capture

    plan = scene["steps"]
    cap = load_capture(paths, plan["capture"])
    vw, vh = cap["viewport"]
    view_w = W - 2 * STEPS_PAD
    view_h = round(view_w * vh / vw)
    k = view_w / vw
    top = round((H - (STEPS_BAR + view_h)) / 2)
    accent = tokens["color"]["accent"]

    def disp(box: list[float]) -> list[float]:
        return [round(b * k, 1) for b in box]

    files = images_used(cap, plan["actions"], plan["start"])
    img_id = {f: f"img-{i}" for i, f in enumerate(files)}
    step_img = {i: img_id.get(s["file"]) for i, s in enumerate(cap["steps"])}
    images = [{"id": img_id[f], "src": f"cap/{Path(f).name}", "initial": f == cap["steps"][plan["start"]]["file"]}
              for f in files]
    assets = {f"cap/{Path(f).name}": Path(cap["dir"]) / f for f in files}

    # The address bar follows the page: each image carries the URL its step ended on.
    def address_of(img: int) -> str:
        url = cap["steps"][img].get("url") or cap.get("url", "")
        return url.split("://", 1)[-1].rstrip("/")

    urls = []
    for img in [plan["start"]] + [a["image"] for a in plan["actions"] if a["do"] in ("show", "play")]:
        if address_of(img) not in urls:
            urls.append(address_of(img))
    addr_id = {u: f"addr-{i}" for i, u in enumerate(urls)}
    shown_addr = addr_id[address_of(plan["start"])]

    js: list[str] = []
    notes: list[str] = []
    accents, callouts = [], []
    current_accent = None
    camera = (1.0, 0.0, 0.0)
    cursor_on = False

    def emit(line: str) -> None:
        js.append(line)

    def clear_accent(t: float) -> None:
        nonlocal current_accent
        if current_accent:
            emit(f'tl.to("#{current_accent}", {{ opacity: 0, duration: 0.25 }}, {t:.3f});')
            current_accent = None

    def crossfade(t: float, a: str, b: str, d: float = 0.35) -> None:
        if a == b:
            return
        emit(f'tl.to("#{b}", {{ autoAlpha: 1, duration: {d} }}, {t:.3f});')
        emit(f'tl.to("#{a}", {{ autoAlpha: 0, duration: {d} }}, {t:.3f});')

    def address(t: float, k: int) -> None:
        nonlocal shown_addr
        new = addr_id[address_of(k)]
        if new != shown_addr:
            emit(f'tl.set("#{new}", {{ autoAlpha: 1 }}, {t:.3f});')
            emit(f'tl.set("#{shown_addr}", {{ autoAlpha: 0 }}, {t:.3f});')
            shown_addr = new

    play_starts = [a["t"] for a in plan["actions"] if a["do"] == "play"]
    for n, a in enumerate(plan["actions"]):
        t = a["t"]
        verb = a["do"]
        if verb == "show":
            clear_accent(t)
            crossfade(t, step_img[a["from"]], step_img[a["image"]])
            address(t, a["image"])
        elif verb == "play":
            clear_accent(t)
            box = disp(a["box"])
            cx, cy = round(box[0] + box[2] / 2), round(box[1] + box[3] / 2)
            if not cursor_on:
                emit(f'tl.to("#cursor", {{ opacity: 1, duration: 0.2 }}, {t:.3f});')
                cursor_on = True
            emit(f'tl.to("#cursor", {{ x: {cx - 3}, y: {cy - 3}, duration: {a["click_at"] - t:.3f}, ease: "power2.inOut" }}, {t:.3f});')
            emit(f'tl.set("#ripple", {{ x: {cx}, y: {cy}, scale: 0, opacity: 0.95 }}, {a["click_at"]:.3f});')
            emit(f'tl.to("#ripple", {{ scale: 1.5, opacity: 0, duration: 0.45, ease: "power2.out" }}, {a["click_at"]:.3f});')
            frm, to = step_img[a["from"]], step_img[a["image"]]
            if a["frames"]:
                prev = frm
                for f in a["frames"]:
                    fid = img_id[f["file"]]
                    emit(f'tl.set("#{fid}", {{ autoAlpha: 1 }}, {f["t"]:.3f});')
                    emit(f'tl.set("#{prev}", {{ autoAlpha: 0 }}, {f["t"]:.3f});')
                    prev = fid
                emit(f'tl.set("#{to}", {{ autoAlpha: 1 }}, {a["settle_at"]:.3f});')
                emit(f'tl.set("#{prev}", {{ autoAlpha: 0 }}, {a["settle_at"]:.3f});')
            else:
                crossfade(a["click_at"] + 0.15, frm, to)
            address(a["click_at"] + 0.15, a["image"])
            # Keep the cursor up when the next step follows soon, so its fades never overlap.
            next_play = next((p for p in play_starts if p > t), None)
            if next_play is None or next_play > a["settle_at"] + 1.2:
                emit(f'tl.to("#cursor", {{ opacity: 0, duration: 0.3 }}, {a["settle_at"] + 0.4:.3f});')
                cursor_on = False
        elif verb in ("zoom", "pan"):
            clear_accent(t)  # a camera move is a new focus, so the last accent steps aside
            d = float(motion["verbs"][verb]["duration"])
            ease = motion["verbs"][verb]["ease"]
            if a["box"] is None:
                camera = (1.0, 0.0, 0.0)
            else:
                z = None if verb == "zoom" else max(camera[0], 1.4)
                camera = zoom_for(disp(a["box"]), view_w, view_h, z)
            emit(f'tl.to("#layer", {{ x: {camera[1]}, y: {camera[2]}, scale: {camera[0]}, duration: {d}, ease: "{ease}" }}, {t:.3f});')
        else:  # accents: one at a time
            clear_accent(t)
            aid = f"acc-{n}"
            x, y, w, h = disp(a["box"])
            # An accent never lands off camera: if the zoomed view cuts its target, step back out first.
            z, tx, ty = camera
            margin = 110 if verb == "callout" else 24
            if z > 1.0 and not (x * z + tx >= 0 and (x + w) * z + tx <= view_w
                                and (y - margin) * z + ty >= 0 and (y + h + margin) * z + ty <= view_h):
                camera = (1.0, 0.0, 0.0)
                emit(f'tl.to("#layer", {{ x: 0, y: 0, scale: 1, duration: 0.8, ease: "power2.inOut" }}, {t:.3f});')
                t = round(t + 0.8, 3)
                notes.append(f"{verb} on {a.get('target')} was off camera, so the view zoomed out first")
            padb = 10
            d = float(motion["verbs"][verb]["duration"])
            # Keep the padded box inside the page, so a full-width element never runs off the window's edge.
            bx0, by0 = max(x - padb, 4.0), max(y - padb, 4.0)
            bx1, by1 = min(x + w + padb, view_w - 4.0), min(y + h + padb, view_h - 4.0)
            if verb in ("spotlight", "light"):
                accents.append({"id": aid, "kind": verb, "x": round(bx0, 1), "y": round(by0, 1),
                                "w": round(bx1 - bx0, 1), "h": round(by1 - by0, 1), "shade": SHADE[verb]})
                emit(f'tl.to("#{aid}", {{ opacity: 1, duration: {d}, ease: "power2.out" }}, {t:.3f});')
            elif verb == "pulse":
                accents.append({"id": aid, "kind": "pulse", "x": round(bx0, 1), "y": round(by0, 1),
                                "w": round(bx1 - bx0, 1), "h": round(by1 - by0, 1)})
                emit(f'tl.fromTo("#{aid}", {{ opacity: 0 }}, {{ opacity: 1, duration: {d / 2:.3f}, yoyo: true, repeat: 3 }}, {t:.3f});')
                aid = None  # a pulse ends by itself
            elif verb == "arrow":
                ex, ey = x + w / 2, y + h  # tip at the middle of the box's bottom edge
                left_side = x + w / 2 > view_w / 2
                sx = ex + (-170 if left_side else 170)
                sy = min(ey + 150, view_h - 30)
                if sy - ey < 60:  # no room below: come from above instead
                    ey = y
                    sy = max(ey - 150, 30)
                import math as _m
                length = round(_m.hypot(ex - sx, ey - sy), 1)
                ux, uy = (ex - sx) / length, (ey - sy) / length
                hx, hy = ex - ux * 22, ey - uy * 22
                px, py = -uy * 13, ux * 13
                head = f"{ex:.1f},{ey:.1f} {hx + px:.1f},{hy + py:.1f} {hx - px:.1f},{hy - py:.1f}"
                accents.append({"id": aid, "kind": "arrow", "sx": round(sx, 1), "sy": round(sy, 1),
                                "ex": round(hx, 1), "ey": round(hy, 1), "len": round(length - 22, 1), "head": head})
                # Show the arrow a frame after its shaft starts drawing, so the round cap never sits alone.
                emit(f'tl.set("#{aid}", {{ opacity: 1 }}, {t + 0.034:.3f});')
                emit(f'tl.to("#{aid} .shaft", {{ strokeDashoffset: 0, duration: {d}, ease: "power2.out" }}, {t:.3f});')
                emit(f'tl.to("#{aid} .head", {{ opacity: 1, duration: 0.15 }}, {t + d - 0.1:.3f});')
            elif verb == "callout":
                below = y - 90 < 20
                callouts.append({"id": aid, "x": round(x + w / 2, 1), "y": round(y + h + 18 if below else y - 18, 1),
                                 "text": a.get("text", ""), "below": below})
                emit(f'tl.fromTo("#{aid}", {{ opacity: 0, scale: 0.92 }}, {{ opacity: 1, scale: 1, duration: {d}, ease: "power3.out" }}, {t:.3f});')
            current_accent = aid

    addresses = [{"id": addr_id[u], "text": u, "initial": addr_id[u] == addr_id[address_of(plan["start"])]}
                 for u in urls]
    ctx = {"view_w": view_w, "view_h": view_h, "bar_h": STEPS_BAR, "left": STEPS_PAD, "top": top, "images": images,
           "accents": accents, "layer_callouts": callouts, "accent": accent, "addresses": addresses,
           "cursor0": {"x": round(view_w * 0.78), "y": round(view_h * 0.86)}, "notes": notes}
    return js, ctx, assets


def cast_time(t: float, segments: list[dict], hold: float) -> float:
    """The cast time a scene shows at scene time t: the same mapping the cast template runs in the browser."""
    tau = hold
    for s in segments:
        if t < s["at"]:
            break
        tau = min(s["from"] + (t - s["at"]), s["to"])
    return tau


def terminal_screen(cast_path: Path, cols: int, rows: int, tau: float) -> list[str]:
    """The terminal's rows at cast time tau, as the player draws them: every output event up to tau, replayed through
    a terminal emulator the same size as the player."""
    import pyte

    screen = pyte.Screen(cols, rows)
    stream = pyte.Stream(screen)
    with open(cast_path, encoding="utf-8") as fh:
        next(fh)
        for line in fh:
            if not line.strip():
                continue
            ev = json.loads(line)
            if ev[0] > tau + 1e-6:
                break
            if ev[1] == "o":
                stream.feed(ev[2])
    return screen.display


def fit_rows(text: str, cols: int, rows: int) -> int:
    """Rows the cast actually fills, plus one, so a short run does not sit in a mostly empty window."""
    used = sum(max(1, -(-len(line) // cols)) for line in text.split("\n"))
    return max(4, min(rows, used + 1))


class SceneComposer:
    def __init__(self, paths: CoursePaths, house: House, plan: dict, timeline: dict, registry_terms: dict):
        self.paths, self.house, self.plan, self.timeline = paths, house, plan, timeline
        self.tokens, self.motion = house.tokens, house.motion
        self.W, self.H, self.fps = timeline["width"], timeline["height"], timeline["fps"]
        self.terms = registry_terms
        self.env = jinja2.Environment(loader=jinja2.FileSystemLoader(house.root / "templates"), autoescape=True,
                                      undefined=jinja2.StrictUndefined)
        self.plan_scenes = {s["id"]: s for s in plan["scenes"]}
        self.layout_warnings: list[str] = []
        order = [s["id"] for s in timeline["scenes"]]
        layouts = {s["id"]: s["layout"] for s in timeline["scenes"]}
        # Back-to-back map scenes share one Map that holds still: no fade between them, only the highlights move.
        self.map_before = {sid: i > 0 and layouts[order[i - 1]] == "map" == layouts[sid] for i, sid in enumerate(order)}
        self.map_after = {sid: i + 1 < len(order) and layouts[order[i + 1]] == "map" == layouts[sid]
                          for i, sid in enumerate(order)}

    def compose(self, scene: dict) -> tuple[str, dict[str, Path]]:
        layout = scene["layout"]
        pscene = self.plan_scenes[scene["id"]]
        duration = scene["frames"] / self.fps
        verbs = Verbs(self.motion, self.tokens)
        callouts, chips = [], []
        ctx = {"W": self.W, "H": self.H, "fps": self.fps, "tokens": self.tokens, "scene": scene,
               "lesson_id": self.timeline["lesson"], "duration_attr": f"{duration:.6f}",
               "fade_out_at": round(max(duration - 0.25, 0), 3),
               "stage_in": not self.map_before.get(scene["id"]), "stage_out": not self.map_after.get(scene["id"])}
        assets: dict[str, Path] = {}
        occupied: tuple[float, float] | None = None

        if layout == "title":
            front = self.plan["lesson"]["front"]
            minutes = max(1, round(self.timeline["duration_ms"] / 60000))
            ctx.update(kicker=f"{self.plan['course']['title']} · {TYPE_LABEL.get(front.get('type'), front.get('type', ''))}",
                       title=front.get("title", self.plan["lesson"]["id"]),
                       subtitle=f"{RUNG_LABEL.get(front.get('rung', 'practitioner'), '')} · {minutes} min")
        elif layout == "diagram":
            nodes, edges, boxes = diagram_geometry(pscene["diagram"], self.tokens, self.W, self.H)
            ctx.update(nodes=nodes, edges=edges, heading=pscene["diagram"].get("heading"))
            occupied = (min(n["y"] for n in nodes), max(n["y"] + n["h"] for n in nodes))
        elif layout == "map":
            from .coursemap import map_geometry

            nodes, edges, boxes = map_geometry(pscene["map"], self.tokens, self.W, self.H)
            tracers = [f"tr-{i}" for i, c in enumerate(scene["cues"]) if c["verb"] == "trace"]
            ctx.update(nodes=nodes, edges=edges, heading=pscene["map"].get("heading"), tracers=tracers)
            occupied = (min(n["y"] for n in nodes), max(n["y"] + n["h"] for n in nodes))
            if pscene.get("component"):
                verbs.light(0.0, pscene["component"], "node")  # opens with its component lit
        elif layout == "code":
            code = code_text(self.paths, pscene["code"])
            a, b = pscene["code"]["show"]
            toks = highlight(self.paths, code.rstrip("\n"), pscene["code"]["lang"])
            line_h = round(self.tokens["size"]["code"] * 1.5)
            cols = code_columns(self.W, self.tokens)
            lines, row_at = [], 0
            for no in range(a, b + 1):
                row = toks[no - 1] if no - 1 < len(toks) else []
                tokens = [{"text": t[0], "color": t[1] or self.tokens["color"]["ink"],
                           "italic": bool(t[2] & 1), "bold": bool(t[2] & 2)} for t in row]
                rows = wrap_tokens(tokens, cols, self.tokens["color"]["ink"], pscene["code"]["lang"])
                lines.append({"no": no, "tokens": tokens, "rows": rows, "wrapped": len(rows) > 1, "row": row_at,
                              "width": max(sum(len(t["text"]) for t in r) for r in rows) if rows else 0})
                row_at += len(rows)
            floor = self.tokens["floor"]["code_lines"]
            if row_at > floor:
                raise LecternError(f"code scene {scene['id']} wraps to {row_at} rows, over the floor of {floor}. Show fewer "
                                   "lines with show=a-b")
            panel_h = 64 + 56 + line_h * row_at
            panel_top = max(96, round((self.H - panel_h) / 2) - 20)
            c = pscene["code"]
            # A pinned source's file reads as it would in a clone, at the ref the lesson teaches.
            tab = f"{c['folder']}/{c['path']} @ {c['ref']}" if c.get("source") and c.get("folder") else c["src"]
            ctx.update(src=tab, lines=lines, line_h=line_h, panel_top=panel_top)
            occupied = (panel_top, panel_top + panel_h)
            boxes = {}
        elif layout == "cast":
            cast_path = Path(pscene["cast"]["path"])
            header = json.loads(cast_path.read_text(encoding="utf-8").split("\n", 1)[0])
            cols, rows = header["width"], header["height"]
            rows = fit_rows(cast_text(cast_path), cols, rows)
            term_w = self.W - 2 * self.tokens["space"]["frame_pad"] - 56
            font = terminal_font_px(self.W, self.tokens, cols)
            term_h = round(rows * 1.3333 * font + 2)
            top = max(96, round((self.H - (64 + 48 + term_h)) / 2) - 10)
            occupied = (top, top + 64 + 48 + term_h)
            play = scene.get("play") or {}
            # Scene-relative times straight from the timeline, so a scene renders the same wherever it sits.
            segments = [{"at": s["t"], "from": s["from"], "to": s["to"]} for s in play.get("segments", [])]
            cast_view = {"path": cast_path, "cols": cols, "rows": rows, "segments": segments, "hold": play.get("hold", 0.0)}
            ctx.update(term_w=term_w, term_h=term_h, top=top, palette=PALETTE, rows=rows, cols=cols,
                       bar_title=f"bash · {header.get('title') or self.plan['course']['id']}",
                       hold=play.get("hold", 0.0), segments_json=json.dumps(segments),
                       cast_json=json.dumps(cast_path.read_text(encoding="utf-8")).replace("</", "<\\/"))
            assets["vendor/asciinema-player.min.js"] = node_root() / "node_modules/asciinema-player/dist/bundle/asciinema-player.min.js"
            assets["vendor/asciinema-player.css"] = self._patched_player_css()
            boxes = {}
        elif layout == "checkpoint":
            cd = scene["countdown"]
            asks = [s for s in scene["sentences"] if s["kind"] == "ask"]
            answers = [s for s in scene["sentences"] if s["kind"] == "answer"]
            seconds = int(round(cd["t1"] - cd["t0"]))
            ring = round(2 * math.pi * 94, 2)
            ctx.update(question=" ".join(s.get("shown") or s["text"] for s in asks),
                       answer_card=pscene["params"].get("card") or
                       ((answers[0].get("shown") or answers[0]["text"]) if answers else ""),
                       cd_start=cd["t0"], cd_end=cd["t1"], cd_len=round(seconds, 3),
                       countdown_numbers=list(range(seconds, 0, -1)), ring_len=ring,
                       answer_at=answers[0]["t"] if answers else cd["t1"])
            boxes = {}
        elif layout == "steps":
            steps_js, steps_ctx, steps_assets = compose_steps(self.paths, scene, self.tokens, self.motion, self.W, self.H)
            self.layout_warnings += [f"{scene['id']}: {m}" for m in steps_ctx.pop("notes")]
            ctx.update(steps_ctx)
            assets.update(steps_assets)
            occupied = (steps_ctx["top"], steps_ctx["top"] + steps_ctx["bar_h"] + steps_ctx["view_h"])
            verbs.js.extend(steps_js)
            boxes = {}
        else:
            raise LecternError(f"no template for layout {layout}")

        # Cues -> GSAP
        marks: list[dict] = []
        for i, cue in enumerate(scene["cues"]):
            t = max(cue["t"], 0.0)
            verb, target = cue["verb"], cue["target"]
            if layout == "steps" and verb != "chip":
                continue  # planned once in the timeline, composed by compose_steps
            if verb == "light":
                graph = pscene.get("diagram") or pscene.get("map") or {}
                kind = "node" if target in {n["id"] for n in graph.get("nodes", [])} else "edge"
                verbs.light(t, target, kind)
            elif verb == "trace":
                verbs.trace(t, cue["params"]["hops"], boxes, f"tr-{i}")
            elif verb == "pulse":
                sel = f"#n-{target}" if target in boxes else f"#e-{target}"
                verbs.pulse(t, sel)
            elif verb == "lines":
                a, b = (int(x) for x in target.split("-"))
                by_no = {ln["no"]: ln for ln in ctx["lines"]}
                first, last = by_no[a]["row"], by_no[b]["row"] + len(by_no[b]["rows"])
                verbs.lines(t, a, b, 28 + first * ctx["line_h"], (last - first) * ctx["line_h"])
            elif verb == "callout":
                cid = f"callout-{i}"
                if layout in ("diagram", "map"):
                    box = boxes[target]
                    side = "" if box["y"] - 90 > 120 else "below"
                    x, y = box["cx"], (box["y"] - 18) if side == "" else (box["y"] + box["h"] + 18)
                else:  # code: to the right of the focused lines
                    a, b = (int(v) for v in target.split("-"))
                    by_no = {ln["no"]: ln for ln in ctx["lines"]}
                    longest = max(by_no[n]["width"] for n in range(a, b + 1) if n in by_no)
                    char_w = self.tokens["size"]["code"] * 0.6
                    x = self.tokens["space"]["frame_pad"] + 2 + 96 + longest * char_w + 48
                    first, last = by_no[a]["row"], by_no[b]["row"] + len(by_no[b]["rows"])
                    y = ctx["panel_top"] + 64 + 28 + (first + last) / 2 * ctx["line_h"]
                    side = "right"
                callouts.append({"id": cid, "x": round(x, 1), "y": round(y, 1), "text": cue["params"]["text"],
                                 "side": side})
                verbs.show_callout(t, cid, side)
            elif verb == "chip":
                term = self.terms[target]
                cid = f"chip-{i}"
                chips.append({"id": cid, "term": term["term"], "define": term["define"],
                              "top": self.chip_top(term["define"], occupied)})
                later = [c for c in scene["cues"][i + 1:] if c["t"] > t]
                next_chip = next((c["t"] for c in later if c["verb"] == "chip"), None)
                next_focus = next((c["t"] for c in later if c["verb"] != "chip"), None)
                hide_at = max(t + CHIP_MIN, next_focus) if next_focus is not None else None
                if hide_at is not None and next_chip is not None and hide_at + 0.3 > next_chip:
                    hide_at = None  # the next chip replaces this one anyway
                verbs.show_chip(t, cid, hide_at)
            elif verb == "play":
                pass  # the cast template maps HyperFrames time to cast time from PLAY_AT
            elif verb == "mark":
                marks.append({"id": f"mark-{i}", "text": target, "on": round(t, 4), "span": cue["span"],
                              "trail": cue["params"].get("trail", "dim")})
        if layout == "cast":
            for m in marks:
                # A mark holds until the next command plays, because new output can move or scroll its text away.
                off = next((s["at"] for s in cast_view["segments"] if s["at"] > m["on"]), None)
                m["off"] = round(off, 4) if off is not None else None
            for m in marks:
                # A newer mark takes the accent: an older one still lit fades to a quiet outline, so the frame always
                # singles out what the narration is on. A newer mark with trail=clear fades the older ones out
                # instead, for when a trail would group things the narration does not. Marks cued within half a
                # second of each other stay a group.
                later = [n for n in sorted(marks, key=lambda x: x["on"])
                         if n["on"] >= m["on"] + 0.5 and (m["off"] is None or n["on"] < m["off"])]
                m["fades"] = []
                if later and later[0]["trail"] != "clear":
                    m["fades"].append((later[0]["on"], MARK_DIM))
                    later = later[1:]
                clear = next((n for n in later if n["trail"] == "clear"), None)
                if clear:
                    m["fades"].append((clear["on"], 0))
                shown = terminal_screen(cast_view["path"], cast_view["cols"], cast_view["rows"],
                                        cast_time(m["on"], cast_view["segments"], cast_view["hold"]))
                if m["text"] not in "".join(shown):
                    raise LecternError(f"{scene['id']}: [{m['span']}] outlines {m['text']!r}, but at that word the "
                                       "terminal does not show it. Mark it after the command that prints it, and "
                                       "before the next one plays")
                both = f'["#{m["id"]}", "#{m["id"]}-b"]'
                verbs.js.append(f'tl.fromTo({both}, {{ opacity: 0 }}, {{ opacity: 1, duration: 0.35, '
                                f'ease: "power2.out" }}, {m["on"]:.3f});')
                for at, level in m["fades"]:
                    verbs.js.append(f'tl.to({both}, {{ opacity: {level}, duration: 0.3, ease: "power1.out" }}, '
                                    f'{at:.3f});')
                if m["off"] is not None:
                    verbs.js.append(f'tl.to({both}, {{ opacity: 0, duration: 0.25, ease: "power1.in" }}, '
                                    f'{max(m["off"] - 0.25, m["on"] + 0.35):.3f});')
            ctx.update(marks=marks, marks_json=json.dumps([{k: m[k] for k in ("id", "text")} for m in marks])
                       .replace("</", "<\\/"))
        if layout == "map" and not ctx["stage_out"]:
            verbs.settle(round(max(duration - 0.4, 0), 3))
        ctx.update(callouts=callouts, chips=chips, verbs_js="\n".join(verbs.js))
        html = self.env.get_template(f"{layout}.html.j2").render(**ctx)

        fonts = node_root() / "node_modules/@fontsource"
        for f in self.tokens["font"]["sans_files"].values():
            assets[f"fonts/{f}"] = fonts / "inter/files" / f
        for f in self.tokens["font"]["mono_files"].values():
            assets[f"fonts/{f}"] = fonts / "jetbrains-mono/files" / f
        assets["vendor/gsap.min.js"] = node_root() / "node_modules/gsap/dist/gsap.min.js"
        return html, assets

    def chip_top(self, define: str, occupied: tuple[float, float] | None) -> float | None:
        """Place a chip in the free band below the scene's main content, else above it. None keeps the default
        bottom-right spot, and adds a layout warning when that spot covers content."""
        size = self.tokens["size"]["chip"]
        per_line = max(1, int((620 - 48) / (size * 0.52)))
        lines = 1 + -(-len(define) // per_line)
        h = 36 + lines * size * 1.32
        if not occupied:
            return None
        top, bottom = occupied
        if self.H - bottom - 24 >= h + 40:
            return round(bottom + 24)
        if top - 24 >= h + 40:
            return round(top - 24 - h)
        self.layout_warnings.append(f"a chip ({define[:40]}...) covers part of the scene. Shorten the definition "
                                    "or show fewer lines")
        return None

    @lru_cache(maxsize=1)
    def _patched_player_css(self) -> Path:
        import re

        src = (node_root() / "node_modules/asciinema-player/dist/bundle/asciinema-player.css").read_text()
        src = re.sub(r'font-family:\s*"Cascadia Code"[^;]*;', 'font-family: "House Mono";', src)
        src = src.replace("font-family: sans-serif", 'font-family: "House Sans"')
        src = re.sub(r"transition:[^;}]*;?", "", src)
        out = self.paths.cache / "asciinema-player.patched.css"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(src)
        return out


# ----------------------------------------------------------------------------- rendering


def scene_key(html: str, assets: dict[str, Path], settings: dict) -> str:
    h = hashlib.sha256()
    h.update(html.encode())
    for name in sorted(assets):
        h.update(name.encode())
        h.update(hashlib.sha256(assets[name].read_bytes()).digest())
    h.update(json.dumps({**settings, "node": node_versions(), "browser": browser_id()}, sort_keys=True).encode())
    return h.hexdigest()[:24]


def render_scene(comp_dir: Path, out: Path, settings: dict, log) -> float:
    cmd = [str(node_bin("hyperframes")), "render", str(comp_dir), "--output", str(out), "--fps", str(settings["fps"]),
           "--quality", settings["quality"], "--strict"]
    if settings.get("workers"):
        cmd += ["--workers", str(settings["workers"])]
    env = {**os.environ, "HYPERFRAMES_NO_TELEMETRY": "1", "DO_NOT_TRACK": "1"}
    t0 = time.time()
    p = subprocess.run(cmd, capture_output=True, text=True, env=env)
    if p.returncode != 0 or not out.exists():
        (comp_dir / "render.log").write_text(p.stdout + p.stderr)
        raise LecternError(f"HyperFrames failed on {comp_dir.name}; see {comp_dir / 'render.log'}\n{(p.stdout + p.stderr)[-1500:]}")
    (comp_dir / "render.log").write_text(p.stdout + p.stderr)
    return time.time() - t0


def probe_frames(path: Path) -> int:
    p = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-count_packets", "-show_entries",
                        "stream=nb_read_packets", "-of", "csv=p=0", str(path)], capture_output=True, text=True)
    return int(p.stdout.strip() or 0)


def render_lesson(paths: CoursePaths, house: House, plan: dict, timeline: dict, eff, log=print) -> dict:
    lesson_id = timeline["lesson"]
    build = paths.build_dir(lesson_id)
    scenes_dir = build / "scenes"
    scenes_dir.mkdir(parents=True, exist_ok=True)
    machine = load_machine()
    settings = {"fps": timeline["fps"], "width": timeline["width"], "height": timeline["height"],
                "quality": eff["quality"], "workers": (machine.get("render") or {}).get("workers")}
    composer = SceneComposer(paths, house, plan, timeline, plan.get("terms", {}))
    report = {"scenes": [], "rendered": 0, "cached": 0}
    outputs = []
    for scene in timeline["scenes"]:
        html, assets = composer.compose(scene)
        render_settings = {k: v for k, v in settings.items() if k != "workers"}  # workers never change pixels
        key = scene_key(html, assets, render_settings)
        cached = paths.scene_cache / f"{key}.mp4"
        comp = scenes_dir / scene["id"]
        if comp.exists():
            shutil.rmtree(comp)
        comp.mkdir(parents=True)
        (comp / "index.html").write_text(html, encoding="utf-8")
        for name, src in assets.items():
            dst = comp / name
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(src, dst)
        status, seconds = "cached", 0.0
        if not cached.exists():
            tmp = cached.with_suffix(".tmp.mp4")
            seconds = render_scene(comp, tmp, settings, log)
            n = probe_frames(tmp)
            if n != scene["frames"]:
                raise LecternError(f"scene {scene['id']} rendered {n} frames, the timeline expects {scene['frames']}")
            tmp.rename(cached)
            status = "rendered"
            report["rendered"] += 1
        else:
            report["cached"] += 1
        log(f"render: {scene['id']:<12} {scene['frames']:>5} frames  {status}{f' in {seconds:.1f} s' if seconds else ''}")
        report["scenes"].append({"id": scene["id"], "key": key, "status": status, "seconds": round(seconds, 1),
                                 "frames": scene["frames"], "composition": str(comp)})
        outputs.append(cached)

    concat = build / "concat.txt"
    concat.write_text("".join(f"file '{p}'\n" for p in outputs))
    video = build / "video.mp4"
    p = subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", str(concat), "-map", "0:v",
                        "-c", "copy", str(video)], capture_output=True, text=True)
    if p.returncode:
        raise LecternError(f"concatenating scenes failed: {p.stderr[-800:]}")
    total = probe_frames(video)
    if total != timeline["frames"]:
        raise LecternError(f"the joined video has {total} frames, the timeline expects {timeline['frames']}")
    report["video"] = str(video)
    report["settings"] = settings
    report["warnings"] = composer.layout_warnings
    (build / "render.json").write_text(json.dumps(report, indent=1))
    return report
