"""stale: compare a course's pins against upstream and flag the lessons that may now teach the old way.

A lesson goes stale when an excerpt it cites is missing at its source's HEAD, when a stack file it shows or a capture
depends on changed upstream, or when a newer release of a pinned source or library exists. Stale never blocks a build.
It flags the lesson in `lectern status` and puts a banner on its page. Run it on a schedule, not inside the stack's
merge requests, so the stack repo stays clean.
"""
from __future__ import annotations

import datetime as dt
import json
import re
import subprocess
import urllib.request
from pathlib import Path

import yaml

from .config import CourseManifest, PinSpec, load_yaml
from .paths import CoursePaths, LecternError
from .sources import git, resolve_repo, slug, sources_root


def stale_path(paths: CoursePaths) -> Path:
    return paths.state / "stale.json"


def basis(paths: CoursePaths, lesson_id: str, captures: list[str] | None = None) -> str:
    """A hash of everything a staleness verdict was reached against: the course pins, the script, the ledger and the
    captures' records. When any of them changes, the old verdict no longer applies."""
    import hashlib

    h = hashlib.sha256()
    files = [paths.root / "course.yaml", paths.lesson_script(lesson_id), paths.claims_ledger(lesson_id)]
    files += [paths.captures / c / "meta.json" for c in sorted(captures or [])]
    for f in files:
        h.update(f.name.encode())
        h.update(f.read_bytes() if f.exists() else b"-")
    return h.hexdigest()[:16]


def lesson_flag(paths: CoursePaths, lesson_id: str) -> str | bool:
    """The banner text for a stale lesson, or False. A verdict reached against older pins or captures is dropped."""
    p = stale_path(paths)
    if not p.exists():
        return False
    entry = json.loads(p.read_text()).get("lessons", {}).get(lesson_id) or {}
    if not entry.get("stale") or entry.get("basis") != basis(paths, lesson_id, entry.get("captures")):
        return False
    return " ".join(entry["reasons"])


# ----------------------------------------------------------------------------- upstream lookups


def version_key(text: str):
    from packaging.version import InvalidVersion, Version

    try:
        return Version(text.strip().lstrip("vV"))
    except InvalidVersion:
        return None


def newer_versions(candidates: list[str], pinned: str) -> list[str]:
    """Releases newer than the pin, oldest first. Pre-releases never count."""
    base = version_key(pinned)
    if base is None:
        return []
    newer = [(v, c) for c in candidates if (v := version_key(c)) is not None and not v.is_prerelease and v > base]
    return [c for _, c in sorted(newer)]


def ls_remote(url: str, *refs: str, options: tuple[str, ...] = ()) -> dict[str, str]:
    """ref name -> commit. Annotated tags resolve to the commit they point at."""
    p = subprocess.run(["git", "ls-remote", *options, url, *refs], capture_output=True, text=True, timeout=120)
    if p.returncode != 0:
        raise LecternError(f"git ls-remote {url} failed: {p.stderr.strip()[-300:]}")
    out: dict[str, str] = {}
    for line in p.stdout.splitlines():
        sha, _, name = line.partition("\t")
        if name.endswith("^{}"):
            out[name[:-3]] = sha  # the peeled commit wins over the tag object
        else:
            out.setdefault(name, sha)
    return out


def head_checkout(name: str, repo: str, url: str, pinned: str) -> tuple[Path, str]:
    """A shallow checkout of the source's default branch, beside the pinned cache, with the pinned commit fetched too
    so the two can be diffed."""
    dest = sources_root() / f"{slug(repo)}@HEAD"
    if not (dest / ".git").exists():
        dest.parent.mkdir(parents=True, exist_ok=True)
        git("clone", "-q", "--depth", "1", url, str(dest))
    else:
        git("fetch", "-q", "--depth", "1", "origin", "HEAD", cwd=dest)
        git("-c", "advice.detachedHead=false", "checkout", "-q", "-f", "FETCH_HEAD", cwd=dest)
    head = git("rev-parse", "HEAD", cwd=dest)
    try:
        git("cat-file", "-e", f"{pinned}^{{commit}}", cwd=dest)
    except LecternError:
        git("fetch", "-q", "--depth", "1", "origin", pinned, cwd=dest)
    return dest, head


def changed_paths(checkout: Path, pinned: str, head: str, watch: list[str]) -> list[str]:
    if not watch or pinned == head:
        return []
    out = git("diff", "--name-only", pinned, head, "--", *watch, cwd=checkout)
    return [line for line in out.splitlines() if line]


def _get_json(url: str) -> dict:
    req = urllib.request.Request(url, headers={"Accept": "application/json", "User-Agent": "lectern-stale"})
    with urllib.request.urlopen(req, timeout=20) as r:  # noqa: S310 (fixed registry hosts)
        return json.load(r)


def latest_release(pin: PinSpec) -> tuple[str | None, str]:
    """(latest version, where it came from). Raises on network failure."""
    if pin.pypi:
        return _get_json(f"https://pypi.org/pypi/{pin.pypi}/json")["info"]["version"], f"PyPI {pin.pypi}"
    if pin.npm:
        return _get_json(f"https://registry.npmjs.org/{pin.npm}/latest")["version"], f"npm {pin.npm}"
    if pin.github:
        # Tags over git, not the GitHub API: no token, no rate limit, and it works wherever git does.
        tags = [n.removeprefix("refs/tags/") for n in
                ls_remote(f"https://github.com/{pin.github}.git", options=("--tags", "--refs"))]
        releases = sorted((v, tag) for tag in tags if (v := version_key(tag)) is not None and not v.is_prerelease)
        if not releases:
            raise LecternError(f"no release tags at github.com/{pin.github}")
        return releases[-1][1].lstrip("vV"), f"GitHub {pin.github}"
    return None, ""


# ----------------------------------------------------------------------------- what each lesson depends on


def norm_ws(s: str) -> str:
    return re.sub(r"\s+", " ", s).strip()


def lesson_deps(paths: CoursePaths, house, lesson_id: str) -> dict:
    """Claims, captures, shown source files and library pins of one lesson, read from its script and ledger."""
    from .script import parse_lesson

    lesson = parse_lesson(paths.lesson_script(lesson_id), set(house.motion["verbs"]))
    ledger_p = paths.claims_ledger(lesson_id)
    ledger = load_yaml(ledger_p) if ledger_p.exists() else {}
    captures = set(lesson.front.get("captures") or [])
    shown = []
    for sc in lesson.scenes:
        if sc.params.get("capture"):
            captures.add(sc.params["capture"])
        src = sc.params.get("src", "")
        if sc.layout == "code" and ":" in src:
            shown.append(tuple(src.split(":", 1)))
    return {"claims": ledger, "captures": sorted(captures), "shown": shown,
            "pins": dict(lesson.front.get("pins") or {})}


# ----------------------------------------------------------------------------- the check


def run_stale(paths: CoursePaths, course: CourseManifest, house, log=print) -> dict:
    report: dict = {"checked": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat(),
                    "sources": {}, "pins": {}, "captures": {}, "lessons": {}, "unchecked": []}
    heads: dict[str, tuple[Path, str]] = {}

    for name, pin in course.sources.items():
        url = resolve_repo(pin.repo, paths.root)
        entry: dict = {"ref": pin.ref, "pinned": pin.commit}
        try:
            refs = ls_remote(url, "HEAD", f"refs/tags/{pin.ref}", f"refs/tags/{pin.ref}^{{}}", f"refs/heads/{pin.ref}")
            entry["ref_now"] = refs.get(f"refs/tags/{pin.ref}") or refs.get(f"refs/heads/{pin.ref}")
            tags = [n.removeprefix("refs/tags/") for n in ls_remote(url, options=("--tags", "--refs"))]
            entry["newer"] = newer_versions(tags, pin.ref)
            if pin.commit:
                heads[name] = head_checkout(name, pin.repo, url, pin.commit)
                entry["head"] = heads[name][1]
        except (LecternError, subprocess.TimeoutExpired) as e:
            entry["error"] = str(e)
            report["unchecked"].append(f"source {name}: {e}")
        report["sources"][name] = entry
        log(f"stale: {name} pinned {pin.ref} ({str(pin.commit)[:12]}), upstream HEAD {str(entry.get('head', '?'))[:12]}"
            + (f", newer: {', '.join(entry['newer'])}" if entry.get("newer") else ""))

    for name, pin in course.pins.items():
        if not isinstance(pin, PinSpec) or not (pin.pypi or pin.npm or pin.github):
            continue
        entry = {"version": pin.version}
        try:
            latest, where = latest_release(pin)
            entry.update(latest=latest, registry=where, newer=bool(newer_versions([latest], pin.version)))
        except Exception as e:  # network, rate limits, a renamed package
            entry["error"] = str(e)
            report["unchecked"].append(f"pin {name}: {e}")
        report["pins"][name] = entry
        log(f"stale: {name} pinned {pin.version}, latest {entry.get('latest', '?')}")

    from .capture import load_meta

    for meta_p in sorted(paths.captures.glob("*/meta.json")):
        meta = json.loads(meta_p.read_text())
        stack = meta.get("stack") or {}
        if not stack.get("source"):
            continue
        entry = {"source": stack["source"], "commit": stack.get("commit"), "watch": stack.get("paths") or []}
        if stack["source"] in heads and stack.get("commit"):
            checkout, head = heads[stack["source"]]
            try:
                entry["changed"] = changed_paths(checkout, stack["commit"], head, entry["watch"])
            except LecternError as e:
                entry["error"] = str(e)
        report["captures"][meta_p.parent.name] = entry

    for script in sorted(paths.lessons.glob("*.md")):
        lid = script.stem
        try:
            deps = lesson_deps(paths, house, lid)
        except LecternError as e:
            report["unchecked"].append(f"lesson {lid}: {e}")
            continue
        reasons: list[str] = []
        used_sources = {c.get("source", {}).get("repo") for c in deps["claims"].values() if isinstance(c, dict)}
        used_sources |= {s for s, _ in deps["shown"]}
        used_sources |= {(load_meta(paths, c).get("stack") or {}).get("source") for c in deps["captures"]}
        used_sources.discard(None)
        for name in sorted(used_sources):
            src = report["sources"].get(name) or {}
            if src.get("newer"):
                reasons.append(f"{name} has a newer release than {src['ref']}: {src['newer'][-1]}.")
            if src.get("ref_now") and src.get("pinned") and src["ref_now"] != src["pinned"]:
                reasons.append(f"{name} {src['ref']} now points at {src['ref_now'][:12]}, not the pinned "
                               f"{src['pinned'][:12]}.")
        missing = []
        for cid, c in sorted(deps["claims"].items()):
            if not isinstance(c, dict) or c.get("kind") not in ("doc", "code"):
                continue
            name, rel = (c.get("source") or {}).get("repo"), (c.get("source") or {}).get("path")
            if name not in heads or not rel:
                continue
            f = heads[name][0] / rel
            if not f.is_file() or norm_ws(c.get("excerpt", "")) not in norm_ws(f.read_text(encoding="utf-8")):
                missing.append(cid)
        if missing:
            reasons.append(f"Excerpts missing at upstream HEAD: {', '.join(missing)}.")
        changed = sorted({p for cap in deps["captures"] for p in (report["captures"].get(cap) or {}).get("changed", [])})
        for name, rel in deps["shown"]:
            if name in heads:
                checkout, head = heads[name]
                pinned = course.sources[name].commit
                try:
                    changed += [p for p in changed_paths(checkout, pinned, head, [rel]) if p not in changed]
                except LecternError:
                    pass
        if changed:
            reasons.append(f"Stack files this lesson shows changed upstream: {', '.join(changed)}.")
        for name, version in deps["pins"].items():
            entry = report["pins"].get(name) or {}
            if entry.get("latest") and newer_versions([entry["latest"]], str(version)):
                reasons.append(f"{name} {entry['latest']} is out. This lesson teaches {version}.")
        report["lessons"][lid] = {"stale": bool(reasons), "reasons": reasons, "captures": deps["captures"],
                                  "basis": basis(paths, lid, deps["captures"])}
        log(f"stale: {lid}: " + ("STALE. " + " ".join(reasons) if reasons else "current"))

    stale_path(paths).parent.mkdir(parents=True, exist_ok=True)
    stale_path(paths).write_text(json.dumps(report, indent=1, ensure_ascii=False))
    for lid, entry in report["lessons"].items():
        flag_page(paths, course.id, lid, " ".join(entry["reasons"]) if entry["stale"] else False)
    return report


def flag_page(paths: CoursePaths, course_id: str, lesson_id: str, flag: str | bool) -> bool:
    """Set the stale flag in a packaged page's front matter, so the StaleBanner shows without a rebuild."""
    page = paths.dist_dir(course_id, lesson_id) / "page.md"
    if not page.exists():
        return False
    text = page.read_text(encoding="utf-8")
    if not text.startswith("---\n"):
        return False
    fm_text, _, body = text[4:].partition("\n---\n")
    fm = yaml.safe_load(fm_text)
    if fm.get("lectern", {}).get("stale") == flag:
        return False
    fm.setdefault("lectern", {})["stale"] = flag
    page.write_text("---\n" + yaml.safe_dump(fm, sort_keys=False, allow_unicode=True, width=1000) + "---\n" + body,
                    encoding="utf-8")
    return True
