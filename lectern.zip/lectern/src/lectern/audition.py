"""audition: render voice and term comparisons into one self-contained page with a player per take.

The page ends in a picks line, for example `narrator=af_heart@1.0 examiner=bf_emma@1.0 term.ragas=ɹˈæɡəs`.
`lectern audition apply "<line>"` writes those picks into voices.yaml and terms.yaml.
"""
from __future__ import annotations

import base64
import json
import datetime as dt
import re
import subprocess
import tempfile
from pathlib import Path

import jinja2
import numpy as np
import soundfile as sf

from .config import House, set_yaml_key
from .paths import LecternError
from .terms import Registry, write_term
from .tts import SR, synthesize

# Kokoro's own voice grades (hexgrad/Kokoro-82M, VOICES.md). Accent and voice come from the ID prefix.
GRADES = {"af_heart": "A", "af_bella": "A-", "af_nicole": "B-", "bf_emma": "B-", "am_fenrir": "C+",
          "am_michael": "C+", "am_puck": "C+", "bm_george": "C", "bm_fable": "C"}
ACCENT = {"a": "American", "b": "British"}
VOICE = {"f": "female", "m": "male"}

NARRATOR_TEXT = ("Ragas scores each answer with an LLM judge. Faithfulness checks every claim against the retrieved "
                 "context, so a score of zero point five means only half the claims held up. Run it on every merge "
                 "request, and a regression shows up before it ships.")
EXAMINER_TEXT = "Checkpoint. An answer scores a perfect one on faithfulness, and it is still wrong. How?"


def to_m4a(audio: np.ndarray) -> bytes:
    with tempfile.TemporaryDirectory() as tmp:
        wav, m4a = Path(tmp) / "a.wav", Path(tmp) / "a.m4a"
        sf.write(wav, audio, SR, subtype="PCM_16")
        p = subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", str(wav), "-c:a", "aac", "-b:a", "48k", "-ac", "1",
                            "-movflags", "+faststart", str(m4a)], capture_output=True, text=True)
        if p.returncode:
            raise LecternError(f"ffmpeg failed: {p.stderr[-300:]}")
        return m4a.read_bytes()


def data_uri(m4a: bytes) -> str:
    return "data:audio/mp4;base64," + base64.b64encode(m4a).decode()


def describe(voice: str) -> dict:
    return {"id": voice, "name": voice.split("_", 1)[1].capitalize(), "accent": ACCENT.get(voice[0], voice[0]),
            "voice": VOICE.get(voice[1], ""), "grade": GRADES.get(voice, "?")}


def render_takes(house: House, registry: Registry, voices: list[str], speeds: list[float], log=print) -> dict:
    seed = int(house.voices.get("seed", 0))
    narr_text, _ = registry.apply(NARRATOR_TEXT)
    exam_text, _ = registry.apply(EXAMINER_TEXT)
    takes: dict = {"narrator": {}, "examiner": {}}
    for v in voices:
        for s in speeds:
            log(f"audition: {v} at {s}x")
            a, _ = synthesize(narr_text, v, s, seed)
            takes["narrator"][f"{v}@{s}"] = {"uri": data_uri(to_m4a(a)), "seconds": round(len(a) / SR, 1)}
            b, _ = synthesize(exam_text, v, s, seed)
            takes["examiner"][f"{v}@{s}"] = {"uri": data_uri(to_m4a(b)), "seconds": round(len(b) / SR, 1)}
    return takes


def render_terms(house: House, registry: Registry, raw_terms: dict, voice: str, log=print) -> list[dict]:
    """Every proposed term, read in context with each candidate pronunciation."""
    seed = int(house.voices.get("seed", 0))
    out = []
    for key, raw in raw_terms.items():
        raw = raw or {}
        if raw.get("status", "accepted") != "proposed":
            continue
        term = registry.get(key)
        context = raw.get("context") or f"We checked the answer with {term.term} before it shipped."
        options = [{"label": raw.get("label") or "proposed", "phonemes": term.phonemes, "say": term.say}]
        options += [dict(o) for o in raw.get("alternatives", [])]
        rendered = []
        for opt in options:
            word = term.term
            if opt.get("phonemes"):
                sentence = re.sub(re.escape(word), f"[{word}](/{opt['phonemes']}/)", context, count=1)
            elif opt.get("say"):
                sentence = re.sub(re.escape(word), opt["say"], context, count=1)
            else:
                sentence = context
            log(f"audition: term {key} as {opt.get('phonemes') or opt.get('say') or 'default'}")
            a, _ = synthesize(sentence, voice, 1.0, seed)
            if opt.get("phonemes"):
                value = opt["phonemes"]
            elif opt.get("say"):
                value = f"say:{opt['say']}"
            else:
                value = "default"
            rendered.append({**opt, "uri": data_uri(to_m4a(a)), "value": value})
        out.append({"key": key, "term": term.term, "define": term.define, "context": context, "options": rendered})
    return out


def build_page(house: House, takes: dict, terms: list[dict], voices: list[str], speeds: list[float], course_title: str) -> str:
    env = jinja2.Environment(loader=jinja2.FileSystemLoader(house.root / "templates"), autoescape=True)
    tpl = env.get_template("audition.html.j2")
    alt = {role: {k: v["uri"] for k, v in takes[role].items() if not k.endswith("@1.0")} for role in takes}
    return tpl.render(
        voices=[describe(v) for v in voices], speeds=speeds, takes=takes, terms=terms,
        alt_takes_json=json.dumps(alt).replace("</", "<\\/"),
        narrator_text=NARRATOR_TEXT, examiner_text=EXAMINER_TEXT, current=house.voices,
        course_title=course_title, today=dt.date.today().isoformat(),
    )


def apply_picks(house: House, course_terms: Path, line: str) -> list[str]:
    """Write a picks line from the audition page into voices.yaml and the course terms."""
    changes = []
    for item in line.split():
        key, _, value = item.partition("=")
        if key in ("narrator", "examiner"):
            m = re.fullmatch(r"([abjzefhip][fm]_[a-z]+)@([0-9.]+)", value)
            if not m:
                raise LecternError(f"cannot read {item!r}: expected {key}=<voice>@<speed>")
            speed = float(m.group(2))
            if not 0.5 <= speed <= 2.0:
                raise LecternError(f"{key} speed {speed} is outside 0.5 to 2.0")
            set_yaml_key(house.root / "voices.yaml", f"{key}.voice", m.group(1))
            set_yaml_key(house.root / "voices.yaml", f"{key}.speed", speed)
            changes.append(f"{key}: {m.group(1)} at {speed}x")
        elif key.startswith("term."):
            term_key = key[5:]
            if value.startswith("say:"):
                write_term(course_terms, term_key, {"say": value[4:], "phonemes": None, "status": "auditioned"})
                _drop_field(course_terms, term_key, "phonemes")
            elif value == "default":
                write_term(course_terms, term_key, {"status": "auditioned"})
                _drop_field(course_terms, term_key, "phonemes")
            else:
                write_term(course_terms, term_key, {"phonemes": value, "status": "auditioned"})
            changes.append(f"term {term_key}: {value}")
        else:
            raise LecternError(f"unknown pick {item!r}")
    if any(c.startswith(("narrator", "examiner")) for c in changes):
        set_yaml_key(house.root / "voices.yaml", "status", "auditioned")
    return changes


def _drop_field(path: Path, key: str, field: str) -> None:
    import yaml

    data = yaml.safe_load(path.read_text()) or {}
    if key in data and field in (data[key] or {}):
        del data[key][field]
        path.write_text(yaml.safe_dump(data, sort_keys=False, allow_unicode=True))


def term_snippets(ctx, plan: dict) -> list[dict]:
    """Each new term as the lesson actually says it: the first narrated sentence that uses it, from the TTS cache."""
    from .config import load_yaml
    from .tts import run_tts

    course_terms = ctx.paths.root / (ctx.course.terms or "terms.yaml")
    raw = load_yaml(course_terms) if course_terms.exists() else {}
    tts = run_tts(ctx.paths, ctx.house, plan, ctx.registry(), log=lambda *_: None)
    sentences = [s for sc in plan["scenes"] for s in sc["sentences"]]
    out = []
    for key, term in plan["terms"].items():
        status = (raw.get(key) or {}).get("status", term.get("status", "accepted"))
        if status != "proposed":
            continue
        names = [term["term"], *term.get("aliases", [])]
        pat = re.compile(r"\b(" + "|".join(re.escape(n) for n in names) + r")\b", re.I)
        hit = next((s for s in sentences if pat.search(s["text"])), None)
        if not hit:
            continue
        audio, _ = sf.read(tts["sentences"][hit["id"]]["wav"], dtype="float32")
        how = (f"/{term['phonemes']}/" if term.get("phonemes") else
               f"respelled \"{term['say']}\"" if term.get("say") else "Kokoro's default")
        out.append({"key": key, "term": term["term"], "define": term.get("define"), "how": how,
                    "label": (raw.get(key) or {}).get("label"), "sentence": hit["text"], "uri": data_uri(to_m4a(audio))})
    return out
