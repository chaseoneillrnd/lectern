"""package: the MP4 with chapters, captions, transcript, slides PDF, VitePress page, contact sheet and QA report."""
from __future__ import annotations

import datetime as dt
import json
import re
import shutil
import subprocess
from pathlib import Path

import yaml
from PIL import Image, ImageDraw, ImageFont

from . import __version__
from .config import CourseManifest, House, load_yaml
from .paths import CoursePaths, LecternError
from .script import WORD_RE

LABEL_FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"


def mmss(ms: float) -> str:
    s = int(round(ms / 1000))
    return f"{s // 60}:{s % 60:02d}"


def ts(ms: float) -> str:
    ms = max(0, int(round(ms)))
    return f"{ms // 3600000:02d}:{ms // 60000 % 60:02d}:{ms // 1000 % 60:02d}.{ms % 1000:03d}"


def scene_title(scene: dict) -> str:
    t = scene.get("params", {}).get("title")
    if t:
        return t
    if scene["layout"] == "checkpoint":
        return "Checkpoint"
    if scene["layout"] == "title":
        return "Title"
    return scene["id"].replace("-", " ").capitalize()


def media_path(course_id: str, lesson_id: str) -> str:
    """Where a lesson's media lives on the site. Never the page's own path: a folder named like a page shadows it on
    static hosts that try the folder before the .html file."""
    return f"/academy/{course_id}/media/{lesson_id}/"


def chapter_list(timeline: dict) -> list[dict]:
    """Chapters from scenes. A title card folds into the scene after it, so no chapter is three silent seconds."""
    out, pending = [], None
    for s in timeline["scenes"]:
        if s["layout"] == "title" and not s["sentences"]:
            pending = pending if pending is not None else s["start_ms"]
            continue
        start = pending if pending is not None else s["start_ms"]
        pending = None
        out.append({"id": s["id"], "title": scene_title(s), "start_ms": start, "end_ms": s["end_ms"]})
    if pending is not None and out:
        out[-1]["end_ms"] = timeline["duration_ms"]
    return out


def run(cmd: list[str], what: str) -> subprocess.CompletedProcess:
    p = subprocess.run(cmd, capture_output=True, text=True)
    if p.returncode:
        raise LecternError(f"{what} failed: {p.stderr[-800:]}")
    return p


# ----------------------------------------------------------------------------- captions


def word_spans(text: str) -> list[tuple[int, int]]:
    return [(m.start(), m.end()) for m in WORD_RE.finditer(text)]


def balanced_cuts(text: str, spans: list[tuple[int, int]], words: list[dict], max_chars: int,
                  max_seconds: float) -> list[tuple[int, int]]:
    """Split one sentence into the fewest caption cues that fit, with cues of even length, preferring to cut after
    a comma. Returns (first word, last word) index pairs."""
    import math

    n_words = len(words)

    def fits(a: int, b: int) -> bool:
        chars = spans[b][1] - spans[a][0]
        secs = (words[b]["end_ms"] - words[a]["start_ms"]) / 1000
        return chars <= max_chars and (secs <= max_seconds or a == b)

    total = spans[-1][1] - spans[0][0]
    secs = (words[-1]["end_ms"] - words[0]["start_ms"]) / 1000
    n = max(1, math.ceil(total / max_chars), math.ceil(secs / max_seconds))
    while n <= n_words:
        groups, a = [], 0
        bonus = max(14.0, 0.4 * total / n)  # a comma may pull the cut this far from the even split
        for k in range(1, n):
            target = spans[0][0] + total * k / n
            best, best_score = None, None
            for j in range(a, n_words - (n - k)):
                pos = spans[j][1]
                score = abs(pos - target) - (bonus if text[pos:pos + 1] in ",;:" else 0)
                if best_score is None or score < best_score:
                    best, best_score = j, score
            groups.append((a, best))
            a = best + 1
        groups.append((a, n_words - 1))
        if all(fits(x, y) for x, y in groups):
            return groups
        n += 1
    return [(i, i) for i in range(n_words)]


def build_vtt(timeline: dict, max_line: int = 42, max_seconds: float = 6.0) -> str:
    cues = []
    for scene in timeline["scenes"]:
        for s in scene["sentences"]:
            spans, words = word_spans(s["text"]), s["words"]
            if not words or len(spans) != len(words):
                if s["text"].strip():
                    cues.append((s["start_ms"], s["end_ms"], s["text"]))
                continue
            for i, j in balanced_cuts(s["text"], spans, words, 2 * max_line, max_seconds):
                end_char = spans[j][1]
                tail = re.match(r"[^\w\s]*", s["text"][end_char:]).group(0)
                text = s["text"][spans[i][0]:end_char] + tail
                cues.append((words[i]["start_ms"], words[j]["end_ms"], text))
    out = ["WEBVTT", ""]
    for n, (a, b, text) in enumerate(cues, 1):
        nxt = cues[n][0] if n < len(cues) else b + 600
        b = min(max(b + 250, a + 900), nxt - 10) if nxt > a else b
        out += [str(n), f"{ts(a)} --> {ts(b)}", wrap_two(text, max_line), ""]
    return "\n".join(out)


def wrap_two(text: str, max_line: int) -> str:
    if len(text) <= max_line:
        return text
    mid = len(text) // 2
    left, right = text.rfind(" ", 0, mid + 1), text.find(" ", mid)
    cut = left if right < 0 or (left >= 0 and mid - left <= right - mid) else right
    return text[:cut].strip() + "\n" + text[cut:].strip()


# ----------------------------------------------------------------------------- transcript and page


def transcript_md(timeline: dict, plan: dict) -> str:
    front = plan["lesson"]["front"]
    lines = [f"# {front.get('title', plan['lesson']['id'])}", "",
             f"{plan['course']['title']} · {front.get('type', '').capitalize()} · {front.get('rung', 'practitioner').capitalize()} · "
             f"{mmss(timeline['duration_ms'])}", ""]
    for scene in timeline["scenes"]:
        if not scene["sentences"]:
            continue
        lines += [f"## {scene_title(scene)}", ""]
        if scene["layout"] == "checkpoint":
            for kind, tag in (("ask", "Ask"), ("answer", "Answer")):
                said = [(s.get("shown") or s["text"]) + "".join(f" ^{c}" for c in s["claims"] if c != "nc")
                        for s in scene["sentences"] if s["kind"] == kind]
                if said:
                    lines += [f"> **{tag}:** {' '.join(said)}", ">"]
            lines[-1] = ""
            continue
        para = []
        for s in scene["sentences"]:
            para.append((s.get("shown") or s["text"]) + "".join(f" ^{c}" for c in s["claims"]))
        lines += [" ".join(para), ""]
    return "\n".join(lines)


def lesson_commands(paths: CoursePaths, plan: dict, course: CourseManifest | None = None) -> list[dict]:
    """What a viewer types to follow along: every terminal capture the lesson plays, in scene order.

    Commands, step ids and stops come from what the capture recorded. Notes come from the capture spec, because a note
    is page text, not output, so rewording one needs no new capture.
    """
    from .capture import load_meta

    # A capture that is not fresh runs where the course's Quick start left the stack, so the page points there.
    setup, qs = None, course.skeleton.quickstart if course else None
    if qs and qs != plan["lesson"]["id"]:
        from .site import _front, lesson_url

        setup = {"title": _front(paths, qs).get("title", qs), "url": lesson_url(course.id, qs)}
    out, seen = [], set()
    for sc in plan["scenes"]:
        if sc["layout"] != "cast" or sc["cast"]["id"] in seen:
            continue
        cid = sc["cast"]["id"]
        seen.add(cid)
        meta = load_meta(paths, cid)
        if not meta.get("commands"):
            continue
        spec_file = paths.capture_scripts / f"{cid}.yaml"
        spec = (load_yaml(spec_file) or {}) if spec_file.exists() else {}
        steps = spec.get("steps") or []
        notes = {str(s.get("id") or f"step{i}"): " ".join(str(s["note"]).split())
                 for i, s in enumerate(steps, 1) if isinstance(s, dict) and s.get("note")}
        stack = dict(meta["stack"]) if meta.get("stack") else None
        if stack and course and stack["source"] in course.sources:
            # The page tells a teammate where to clone from today, so course.yaml wins over what the capture recorded.
            pin = course.sources[stack["source"]]
            stack.update(repo=pin.repo, ref=pin.ref, clone=pin.clone)
        out.append({"capture": cid, "commands": meta["commands"], "ids": [m["id"] for m in meta.get("marks", [])],
                    "notes": notes, "stack": stack, "stopped": meta.get("stopped") or {},
                    "fresh": bool(spec.get("fresh")), "setup": setup})
    return out


def clone_url(stack: dict) -> str | None:
    """Where a teammate clones the stack from: its clone URL, or its repo when that is a URL. None for a local path."""
    from .sources import is_remote

    return stack.get("clone") or (stack["repo"] if is_remote(stack["repo"]) else None)


def commands_block(groups: list[dict]) -> list[str]:
    """Every command the lesson's terminal captures ran, in order, after the clone a stack capture starts from.

    Notes are whole comment lines, never trailing ones: zsh passes a trailing `# ...` to the command as arguments.
    """
    import textwrap

    from .sources import repo_name

    lines, stacks = [], set()
    for g in groups:
        st = g.get("stack")
        if st and st["source"] not in stacks:
            stacks.add(st["source"])
            if g.get("fresh", True):  # a capture that starts where another left off starts in that folder, no clone
                name = repo_name(st["repo"])
                lines += [f"git clone --branch {st['ref']} {clone_url(st) or f'<{name} repo URL>'}", f"cd {name}"]
        ids = g.get("ids") or [None] * len(g["commands"])
        for cmd, sid in zip(g["commands"], ids):
            lines.append(cmd)
            if sid is not None and sid in (g.get("stopped") or {}):
                lines.append("# keeps running until you press Ctrl-C")
            if note := (g.get("notes") or {}).get(sid):
                lines += [f"# {part}" for part in textwrap.wrap(note, 100)]
    return lines


def lesson_pages(paths: CoursePaths, plan: dict) -> list[dict]:
    """The pages a lesson's browser captures open, by title and address, so a viewer can find them without a click."""
    from urllib.parse import urlsplit

    from .capture import load_meta

    out, seen = [], set()
    for sc in plan["scenes"]:
        if sc["layout"] != "steps":
            continue
        for step in load_meta(paths, sc["steps"]["id"]).get("steps", []):
            parts = urlsplit(step.get("url") or "")
            if not parts.netloc:
                continue
            origin = f"{parts.scheme}://{parts.netloc}/"  # one entry per app, titled by the first page seen there
            if origin not in seen:
                seen.add(origin)
                # "✔ 5/5 ┊ Tilt" or "Settings | GitLab": the site's name is the last part of the title.
                name = re.split(r"\s[┊|·—–-]\s", step.get("title") or "")[-1].strip()
                out.append({"title": name or parts.netloc, "url": origin})
    return out


def before_block(front: dict, commands: list[dict], pages: list[dict]) -> list[str]:
    """What a viewer needs before following along: the lesson's stated needs, where to start, and the pages it opens."""
    from .sources import repo_name

    body = []
    needs = front.get("needs") or []
    if needs:
        body += ["You need:", ""] + [f"- {n}" for n in needs] + [""]
    first = next((g for g in commands if g.get("stack")), None)
    if first:
        name, ref = repo_name(first["stack"]["repo"]), first["stack"]["ref"]
        if first.get("fresh", True):
            body += [f"Start from a fresh clone of `{name}` at tag `{ref}`. Run every command from that folder.", ""]
        elif first.get("setup"):
            s = first["setup"]
            body += [f"Start in the `{name}` folder you set up in [{s['title']}]({s['url']}), at tag `{ref}`. Run every "
                     "command from that folder.", ""]
        else:
            body += [f"Start in your `{name}` folder at tag `{ref}`, with the stack set up. Run every command from "
                     "that folder.", ""]
    if pages:
        body += ["The pages it opens: " + ", ".join(f"[{p['title']}]({p['url']})" for p in pages) + ".", ""]
    return (["## Before you start {#before}", ""] + body) if body else []


def page_md(timeline: dict, plan: dict, claims: list[dict], media_base: str, built: str,
            commands: list[dict] | None = None, stale: str | bool = False, pages: list[dict] | None = None) -> str:
    front = plan["lesson"]["front"]
    terms = plan.get("terms", {})
    chapters = [{"id": c["id"], "title": c["title"], "start": round(c["start_ms"] / 1000, 2)}
                for c in chapter_list(timeline)]
    claim_map = {c["id"]: {"kind": c["kind"], "where": c["where"], "url": c["url"], "excerpt": c["excerpt"].strip()}
                 for c in claims}
    checkpoints = {}
    for s in timeline["scenes"]:
        if s["layout"] == "checkpoint":
            checkpoints[s["id"]] = {
                "question": " ".join(x.get("shown") or x["text"] for x in s["sentences"] if x["kind"] == "ask"),
                "answer": " ".join(x.get("shown") or x["text"] for x in s["sentences"] if x["kind"] == "answer"),
                "claims": [c for x in s["sentences"] if x["kind"] == "answer" for c in x["claims"]],
            }
    fm = {
        "title": front.get("title", plan["lesson"]["id"]),
        "description": front.get("objective", ""),
        "outline": [2, 2],
        "lectern": {
            "generated": True, "lesson": plan["lesson"]["id"], "course": plan["course"],
            "type": front.get("type"), "rung": front.get("rung", "practitioner"),
            "duration": mmss(timeline["duration_ms"]), "media": media_base,
            "chapters": chapters, "claims": claim_map,
            "terms": {k: {"term": v["term"], "define": v["define"]} for k, v in terms.items() if v.get("define")},
            "checkpoints": checkpoints, "stale": stale, "built": built, "tool": f"lectern {__version__}",
            "pins": front.get("pins", {}),
        },
    }
    body = [
        "<!-- Generated by `lectern build` from lessons/" + plan["lesson"]["id"] + ".md. Do not edit: the next build overwrites this page. -->",
        "",
        f"# {fm['title']}",
        "",
        "<StaleBanner />",
        "",
        "<LessonPlayer />",
        "",
    ]
    body += before_block(front, commands or [], pages or [])
    if commands:
        first = next((g for g in commands if g.get("stack")), None)
        ran = ("Every command after the clone ran in the captures this lesson plays, in this order."
               if first and first.get("fresh", True) else
               f"Every command here ran in the capture{'s' if len(commands) > 1 else ''} this lesson plays, in this order.")
        body += ["## Commands {#commands}", "", ran, "", "```bash", *commands_block(commands), "```", ""]
    chipped: set[str] = set()
    for scene in timeline["scenes"]:
        if not scene["sentences"]:
            continue
        body += [f"## {scene_title(scene)} {{#{scene['id']}}}", ""]
        if scene["layout"] == "checkpoint":
            body += [f'<Checkpoint id="{scene["id"]}" />', ""]
            continue
        para = []
        for s in scene["sentences"]:
            text = mark_terms(s.get("shown") or s["text"], terms, chipped)
            para.append(text + "".join(f' <Claim id="{c}" />' for c in s["claims"] if c != "nc"))
        body += [" ".join(para), ""]
    return "---\n" + yaml.safe_dump(fm, sort_keys=False, allow_unicode=True, width=1000) + "---\n\n" + "\n".join(body)


def mark_terms(text: str, terms: dict, chipped: set) -> str:
    """Wrap the first mention of each defined term in a Term chip. Escape anything Vue would read as markup."""
    text = text.replace("{", "&#123;").replace("}", "&#125;").replace("<", "&lt;")
    for key, t in sorted(terms.items(), key=lambda kv: -len(kv[1]["term"])):
        if key in chipped or not t.get("define"):
            continue
        forms = sorted({t["term"], *t.get("aliases", [])}, key=len, reverse=True)
        pat = re.compile(r"(?<![\w-])(" + "|".join(re.escape(f) for f in forms) + r")(?![\w-])", re.I)
        m = pat.search(text)
        if m:
            text = text[:m.start()] + f'<Term id="{key}">{m.group(0)}</Term>' + text[m.end():]
            chipped.add(key)
    return text


# ----------------------------------------------------------------------------- frames


def grab(video: Path, at_s: float, out: Path) -> None:
    run(["ffmpeg", "-v", "error", "-y", "-ss", f"{max(at_s, 0):.3f}", "-i", str(video), "-frames:v", "1", str(out)],
        f"frame grab at {at_s:.2f}s")


def slides_pdf(video: Path, timeline: dict, out: Path, tmp: Path) -> int:
    pages = []
    for scene in timeline["scenes"]:
        at = scene["end_ms"] / 1000 - 0.45
        png = tmp / f"slide-{scene['id']}.png"
        grab(video, at, png)
        pages.append(Image.open(png).convert("RGB"))
    pages[0].save(out, save_all=True, append_images=pages[1:], resolution=144)
    return len(pages)


def contact_sheet(video: Path, timeline: dict, motion: dict, out: Path, tmp: Path) -> int:
    shots = []
    for scene in timeline["scenes"]:
        base = {"scene": scene["id"], "layout": scene["layout"]}
        moments = [(scene["start_ms"] / 1000 + 1.0, f"{scene['id']} · opens", "", {**base, "moment": "opens"})]
        if scene.get("countdown"):
            moments.append((scene["countdown"]["start_ms"] / 1000 + 1.5, f"{scene['id']} · countdown", "",
                            {**base, "moment": "countdown"}))
            answer = next((s for s in scene["sentences"] if s["kind"] == "answer"), None)
            if answer:
                moments.append((answer["start_ms"] / 1000 + 1.2, f"{scene['id']} · answer", "",
                                {**base, "moment": "answer"}))
        # In a steps scene a cue can wait for the step before it, so look where its action actually lands.
        acted: dict[int, list[dict]] = {}
        for a in (scene.get("steps") or {}).get("actions", []):
            if "cue" in a:
                acted.setdefault(a["cue"], []).append(a)
        for ci, c in enumerate(scene["cues"]):
            settle = float(motion["verbs"][c["verb"]]["duration"]) + 0.2
            if c["verb"] == "trace":  # after the dot arrives, with the whole path lit
                settle = float(motion["verbs"]["trace"]["duration"]) * len((c.get("params") or {}).get("hops") or [1]) + 0.3
            at = c["at_ms"] / 1000
            if ci in acted:
                last = acted[ci][-1]
                at = scene["start_ms"] / 1000 + last["t"]
                if c["verb"] == "play":
                    settle = max(0.6, last.get("settle_at", last["t"]) - last["t"] + 0.3)
            elif c["verb"] == "play":
                settle = 2.5
            label = f"{scene['id']} · {c['verb']} {c['target'] or ''}".strip()
            moments.append((at + settle, label, f"[{c['span']}]",
                            {**base, "moment": "cue", "verb": c["verb"], "target": c["target"],
                             "params": c.get("params") or {}, "span": c["span"]}))
        for at, label, span, info in moments:
            at = min(at, scene["end_ms"] / 1000 - 0.4)
            png = tmp / f"cue-{len(shots):03d}.png"
            grab(video, at, png)
            shots.append((png, f"{mmss(at * 1000)}  {label}", span, {**info, "time": mmss(at * 1000)}))
    font = ImageFont.truetype(LABEL_FONT, 26) if Path(LABEL_FONT).exists() else ImageFont.load_default()
    small = ImageFont.truetype(LABEL_FONT, 22) if Path(LABEL_FONT).exists() else ImageFont.load_default()
    tw, th, cols, rows = 880, 495, 2, 3
    page_w, page_h = 60 + cols * (tw + 40), 90 + rows * (th + 110)
    pages = []
    for i in range(0, len(shots), cols * rows):
        page = Image.new("RGB", (page_w, page_h), "white")
        d = ImageDraw.Draw(page)
        d.text((40, 30), f"{timeline['lesson']} · contact sheet · page {i // (cols * rows) + 1}", fill="black", font=font)
        for k, (png, label, span, _) in enumerate(shots[i:i + cols * rows]):
            x, y = 40 + (k % cols) * (tw + 40), 90 + (k // cols) * (th + 110)
            page.paste(Image.open(png).convert("RGB").resize((tw, th)), (x, y))
            d.rectangle([x - 1, y - 1, x + tw, y + th], outline="#888888")
            d.text((x, y + th + 10), label, fill="black", font=font)
            d.text((x, y + th + 46), span, fill="#444444", font=small)
        pages.append(page)
    pages[0].save(out, save_all=True, append_images=pages[1:], resolution=144)
    index = [{"png": png.name, "label": label, "span": span, **info} for png, label, span, info in shots]
    (out.parent / "contact-sheet.json").write_text(json.dumps(index, indent=1, ensure_ascii=False))
    return len(shots)


# ----------------------------------------------------------------------------- QA report


def qa_report(plan: dict, timeline: dict, check: dict, render: dict, tts: dict) -> str:
    L = [f"# QA report: {plan['lesson']['id']}", ""]
    status = "PASS" if check["ok"] else "BROKEN"
    L += [f"**{status}.** {len(timeline['scenes'])} scenes, {mmss(timeline['duration_ms'])} long, "
          f"{sum(1 for c in check['claims'] if c['status'] == 'ok')} of {len(check['claims'])} claims verified, "
          f"{len(check['warnings'])} warnings.", ""]
    if check["broken"]:
        L += ["## Broken", ""] + [f"- {b}" for b in check["broken"]] + [""]
    if check["warnings"]:
        L += ["## Warnings", ""] + [f"- {w}" for w in check["warnings"]] + [""]
    L += ["## Claims", "", "| Claim | Kind | Source | Status |", "| --- | --- | --- | --- |"]
    for c in check["claims"]:
        src = f"[{c['where']}]({c['url']})" if c.get("url") else c["where"]
        L.append(f"| {c['id']} | {c['kind']} | {src} | {c['status']} |")
    L += ["", "## Code on screen ran", ""]
    L += [f"- {c['scene']}: `{c['file']}` {'matches a captured run' if c['ran'] else 'DOES NOT match any captured run'}"
          for c in check["code_ran"]] or ["- No code scenes."]
    leg = check["legibility"]
    L += ["", "## Legibility", "", f"- Smallest body text {leg['body_px']} px, code {leg['code_px']} px.",
          "- Contrast: " + ", ".join(f"{k} {v}:1" for k, v in leg["contrast"].items()) + ".",
          "- Prose words on screen per scene: " + ", ".join(f"{k} {v}" for k, v in leg["words"].items()) + "."]
    loud = check["loudness"]
    L += ["", "## Audio", "", f"- Integrated loudness {loud['integrated']} LUFS against {loud['target']}, true peak {loud['true_peak']} dBTP.",
          f"- Voices: Narrator {tts['voices']['narrator']['voice']} at {tts['voices']['narrator']['speed']}x, "
          f"Examiner {tts['voices']['examiner']['voice']} at {tts['voices']['examiner']['speed']}x.",
          f"- {check['timestamps']['words']} words timed, {check['timestamps']['fallback']} fell back to an estimate."]
    red = check["redaction"]
    L += ["", "## Redaction", "", f"- {red.get('tool') or 'gitleaks not installed'}: {red['findings']} findings."]
    L += ["", "## Render", "", f"- {render['rendered']} scenes rendered, {render['cached']} from cache.",
          f"- Settings: {render['settings']}."]
    for s in render["scenes"]:
        took = f" in {s['seconds']} s" if s["seconds"] else ""
        L.append(f"- {s['id']}: {s['frames']} frames, {s['status']}{took}.")
    if plan.get("no_claim_sentences"):
        L += ["", "## Sentences marked ^nc", ""] + [f"- {s}" for s in plan["no_claim_sentences"]]
    return "\n".join(L) + "\n"


# ----------------------------------------------------------------------------- package


def package_lesson(paths: CoursePaths, course: CourseManifest, house: House, plan: dict, timeline: dict,
                   check: dict, render: dict, tts: dict, eff, log=print) -> Path:
    lesson_id = plan["lesson"]["id"]
    build = paths.build_dir(lesson_id)
    dist = paths.dist_dir(course.id, lesson_id)
    review = dist / "review"
    tmp = build / "frames"
    for d in (dist, review, tmp):
        d.mkdir(parents=True, exist_ok=True)
    front = plan["lesson"]["front"]

    chapters = [";FFMETADATA1", f"title={front.get('title', lesson_id)}", f"artist={course.title}", ""]
    for c in chapter_list(timeline):
        chapters += ["[CHAPTER]", "TIMEBASE=1/1000", f"START={round(c['start_ms'])}", f"END={round(c['end_ms'])}",
                     f"title={c['title']}", ""]
    (build / "chapters.txt").write_text("\n".join(chapters))
    mp4 = dist / "lesson.mp4"
    run(["ffmpeg", "-v", "error", "-y", "-i", render["video"], "-i", str(build / "narration.norm.wav"),
         "-i", str(build / "chapters.txt"), "-map", "0:v", "-map", "1:a", "-map_metadata", "2", "-map_chapters", "2",
         "-c:v", "copy", "-c:a", "aac", "-b:a", "128k", "-ac", "1", "-movflags", "+faststart", str(mp4)], "muxing the MP4")

    (dist / "lesson.vtt").write_text(build_vtt(timeline))
    (dist / "transcript.md").write_text(transcript_md(timeline, plan))
    shutil.copyfile(build / "timeline.json", dist / "timeline.json")
    n_slides = slides_pdf(mp4, timeline, dist / "slides.pdf", tmp)
    poster = Image.open(tmp / f"slide-{timeline['scenes'][0]['id']}.png").convert("RGB")
    poster.thumbnail((1280, 720))
    poster.save(dist / "poster.jpg", quality=85)
    n_shots = contact_sheet(mp4, timeline, house.motion, review / "contact-sheet.pdf", tmp)
    built = dt.date.today().isoformat()
    media_base = media_path(course.id, lesson_id)
    from .stale import lesson_flag

    (dist / "page.md").write_text(page_md(timeline, plan, check["claims"], media_base, built,
                                          lesson_commands(paths, plan, course), lesson_flag(paths, lesson_id),
                                          lesson_pages(paths, plan)))
    (review / "qa-report.md").write_text(qa_report(plan, timeline, check, render, tts))
    shutil.copyfile(build / "check.json", review / "check.json")
    # What produced this MP4, so gate two can refuse a render of anything but the approved script at full quality.
    import hashlib

    def sha(p: Path) -> str:
        return hashlib.sha256(p.read_bytes()).hexdigest()

    (dist / "build.json").write_text(json.dumps({
        "lesson": lesson_id, "script": sha(paths.lesson_script(lesson_id)), "claims": sha(paths.claims_ledger(lesson_id)),
        "mp4": sha(mp4), "quality": eff["quality"], "fidelity": eff["fidelity"], "checks_ok": bool(check["ok"]),
        "built": built, "tool": __version__,
        # The Map this lesson draws, so a later edit to map.yaml reopens it until it is rebuilt.
        "map": ({"path": Path(plan["map"]["path"]).relative_to(paths.root).as_posix(), "hash": plan["map"]["hash"]}
                if plan.get("map") else None),
    }, indent=1))
    log(f"package: {mp4.relative_to(paths.root)}, captions, transcript, {n_slides} slides, contact sheet of {n_shots} frames, page.md")
    return dist
