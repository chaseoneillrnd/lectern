"""status: what differs from the house defaults, where each lesson stands, and which gates are open. Changes nothing."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

from .config import flatten, load_machine
from .gates import gate_state
from .preview import lesson_order


def _sha(p: Path) -> str | None:
    return hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None


def lesson_status(ctx, lesson_id: str) -> dict:
    paths = ctx.paths
    script = paths.lesson_script(lesson_id)
    if not script.exists():
        return {"id": lesson_id, "state": "planned", "detail": "no script yet"}
    build = paths.build_dir(lesson_id)
    dist = paths.dist_dir(ctx.course.id, lesson_id)
    script_sha = _sha(script)
    plan = json.loads((build / "plan.json").read_text()) if (build / "plan.json").exists() else None
    check = json.loads((build / "check.json").read_text()) if (build / "check.json").exists() else None
    gates = gate_state(paths, ctx.course.id, lesson_id)
    out = {"id": lesson_id, "gate_one": gates["one"]["approved"], "gate_two": gates["two"]["approved"]}
    if gates["one"]["record"] and not gates["one"]["approved"]:
        out["reopened"] = "gate one reopened: the script or ledger changed after approval"
    from .gates import build_record, render_problem

    record = build_record(paths, ctx.course.id, lesson_id)
    built = bool(record) and record.get("script") == script_sha and record.get("mp4") == _sha(dist / "lesson.mp4")
    if gates["two"]["approved"]:
        out["state"] = "approved"
    elif built:
        problem = render_problem(paths, ctx.course.id, lesson_id)
        out["state"] = ("built" if gates["one"]["approved"] else "built before gate one") if not problem else "built, not gate-ready"
        if problem:
            out["note"] = problem
    elif plan is not None and plan["lesson"]["script_hash"] == script_sha:
        out["state"] = "compiled"
    else:
        out["state"] = "draft"
    if (dist / "lesson.mp4").exists():
        tl = dist / "timeline.json"
        if tl.exists():
            out["minutes"] = round(json.loads(tl.read_text())["duration_ms"] / 60000, 2)
    if check:
        out["warnings"] = len(check.get("warnings", []))
    from .stale import lesson_flag

    flag = lesson_flag(paths, lesson_id)
    if flag:
        out["stale"] = flag
    return out


def course_status(ctx) -> dict:
    house_flat = flatten(ctx.house.config)
    course_layer = flatten(ctx.course.defaults)
    differs = {k: {"course": v, "house": house_flat.get(k)} for k, v in course_layer.items() if house_flat.get(k) != v}
    machine = load_machine().get("render") or {}
    lessons = [lesson_status(ctx, lid) for lid in lesson_order(ctx.course)]
    known = set(lesson_order(ctx.course))
    for script in sorted(ctx.paths.lessons.glob("*.md")):
        if script.stem not in known:
            lessons.append({**lesson_status(ctx, script.stem), "note": "not in the course skeleton"})
    open_gates = [f"{x['id']}: gate {'one' if not x.get('gate_one') else 'two'}" for x in lessons
                  if x.get("state") not in ("planned", "approved")]
    unpinned = [name for name, pin in ctx.course.sources.items() if not pin.commit]
    stale_file = ctx.paths.state / "stale.json"
    stale_checked = json.loads(stale_file.read_text()).get("checked") if stale_file.exists() else None
    return {"course": {"id": ctx.course.id, "title": ctx.course.title, "kind": ctx.course.kind},
            "machine": machine, "differs": differs, "lessons": lessons, "open_gates": open_gates,
            "unpinned_sources": unpinned, "stale_checked": stale_checked,
            "voices": {r: ctx.house.voices[r] for r in ("narrator", "examiner")},
            "voices_status": ctx.house.voices.get("status", ""), "tts_cache": str(ctx.paths.tts_cache)}


def format_status(st: dict) -> str:
    L = [f"{st['course']['title']} ({st['course']['id']}, {st['course']['kind']})"]
    m = st["machine"]
    L.append(f"  machine: {m.get('workers', '?')} render workers, profiled {m.get('probed', 'never')}")
    v = st["voices"]
    L.append(f"  voices: Narrator {v['narrator']['voice']} at {v['narrator']['speed']}x, Examiner "
             f"{v['examiner']['voice']} at {v['examiner']['speed']}x"
             + (f" ({st['voices_status']})" if st["voices_status"] else ""))
    if st.get("tts_cache"):
        L.append(f"  narration cache: {st['tts_cache']}")
    if st["differs"]:
        L.append("  course overrides: " + ", ".join(f"{k}={d['course']!r} (house {d['house']!r})" for k, d in st["differs"].items()))
    if st["unpinned_sources"]:
        L.append("  unpinned sources: " + ", ".join(st["unpinned_sources"]) + ". Run `lectern sources`")
    L.append("  lessons:")
    for les in st["lessons"]:
        extra = []
        if "minutes" in les:
            extra.append(f"{les['minutes']:.1f} min")
        if les.get("warnings"):
            extra.append(f"{les['warnings']} warnings")
        if les.get("reopened"):
            extra.append(les["reopened"])
        if les.get("note"):
            extra.append(les["note"])
        if les.get("stale"):
            extra.append(f"STALE: {les['stale']}")
        L.append(f"    {les['id']:<28} {les['state']}" + (f"  ({'; '.join(extra)})" if extra else ""))
    L.append("  open gates: " + (", ".join(st["open_gates"]) if st["open_gates"] else "none"))
    L.append("  staleness: " + (f"checked {st['stale_checked']}" if st.get("stale_checked") else
                                "never checked. Run `lectern stale`"))
    return "\n".join(L)
