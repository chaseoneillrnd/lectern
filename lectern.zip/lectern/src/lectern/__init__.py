"""Lectern: one Markdown lesson script in, a narrated, verified video lesson and a VitePress page out."""
__version__ = "0.2.0"
