"""timeline: place every sentence, map each cue to its word's start time, and emit timeline.json.

timeline.json is the engine-agnostic contract between the compiler and the renderer adapter.
Scene lengths are whole frames, so concatenated scene videos and the narration track stay in step.
"""
from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np
import soundfile as sf

from .config import House
from .paths import CoursePaths
from .tts import SR


def cast_duration(path: Path) -> float:
    last = 0.0
    with open(path, encoding="utf-8") as fh:
        next(fh)
        for line in fh:
            line = line.strip()
            if line:
                last = max(last, float(json.loads(line)[0]))
    return last


def frames(seconds: float, fps: int) -> int:
    return int(math.ceil(round(seconds * fps, 6)))


def plan_cast(paths: CoursePaths, capture_id: str, cues: list[dict], duration: float, default_at: float):
    """Map each play cue to a stretch of the cast. A cast plays at its recorded pace, one command at a time when the
    capture recorded where each command starts, and holds still between plays.

    Returns (segments, hold, busy_until, late): segments are {at, from, to, step} with `at` in scene seconds and
    `from`/`to` in cast seconds, hold is the cast time shown before the first play.
    """
    from .capture import load_meta

    marks = load_meta(paths, capture_id).get("marks") or []
    ids = [m["id"] for m in marks]

    def stretch(k: int) -> tuple[float, float]:
        nxt = marks[k + 1]["prompt"] + 0.01 if k + 1 < len(marks) else duration
        return marks[k]["start"], nxt

    plays = [c for c in cues if c["verb"] == "play"]
    if not plays:
        plays = [{"target": capture_id, "at": default_at, "span": "(scene start)"}]
    segments, late, busy, nxt = [], [], 0.0, 0
    for c in plays:
        target = c.get("target")
        at = max(float(c["at"]), busy)
        if at - float(c["at"]) > 0.5:
            late.append((c.get("span", ""), at - float(c["at"])))
        if not marks or target == capture_id and nxt == 0:
            segments.append({"at": at, "from": 0.0, "to": duration, "step": capture_id})
            busy, nxt = at + duration, len(marks)
            continue
        if not target:
            ks = [nxt] if nxt < len(marks) else []
        elif target == capture_id:
            ks = list(range(nxt, len(marks)))
        elif ".." in target:
            a, b = target.split("..", 1)
            ks = list(range(ids.index(a), ids.index(b) + 1))
        else:
            ks = [ids.index(target)]
        for k in ks:
            frm, to = stretch(k)
            segments.append({"at": at, "from": frm, "to": to, "step": ids[k]})
            at += to - frm
        busy, nxt = at, (ks[-1] + 1 if ks else nxt)
    # Before its first play, a scene shows the terminal at that command's prompt, with everything the capture printed
    # before it. So a lesson can split one capture across scenes, and the later scene picks up where the terminal was.
    if not segments or segments[0]["from"] == 0.0:
        hold = 0.0
    else:
        first = ids.index(segments[0]["step"]) if segments[0]["step"] in ids else 0
        hold = round(marks[first]["prompt"] + 0.01, 4)
    return segments, hold, busy, late


def build_timeline(paths: CoursePaths, house: House, plan: dict, tts: dict, eff) -> tuple[dict, list[str]]:
    fps = int(eff["video.fps"])
    pauses = house.voices["pauses"]
    breathing = float(house.motion.get("breathing_seconds", 1.0))
    warnings: list[str] = []
    scenes_out = []
    cursor_frames = 0

    for scene in plan["scenes"]:
        layout = scene["layout"]
        start = cursor_frames / fps
        t = float(pauses["scene_lead_in"]) if scene["sentences"] else 0.0
        placed = []
        countdown = None

        def place(sentences):
            nonlocal t
            for i, s in enumerate(sentences):
                rec = tts["sentences"][s["id"]]
                offset = t
                placed.append((s, rec, offset))
                t += rec["duration"]
                if i < len(sentences) - 1:
                    t += float(pauses["paragraph"] if s["paragraph_end"] else pauses["sentence"])

        if layout == "checkpoint":
            asks = [s for s in scene["sentences"] if s["kind"] == "ask"]
            answers = [s for s in scene["sentences"] if s["kind"] == "answer"]
            place(asks)
            c0 = t + 0.4
            countdown = (c0, c0 + float(pauses["countdown"]))
            t = countdown[1] + 0.35
            place(answers)
        else:
            place(scene["sentences"])
        end = t + (float(pauses["scene_tail"]) if scene["sentences"] else 0.0)
        if layout == "title":
            end = max(end, float(eff["title_seconds"]))

        cues = []
        for s, rec, offset in placed:
            for cue in s["cues"]:
                w = rec["words"][min(cue["word_index"], len(rec["words"]) - 1)] if rec["words"] else None
                at = offset + (w["start"] if w else 0.0)
                fallback = bool(w is None or w["fallback"])
                if fallback:
                    at = offset
                    warnings.append(f"{s['id']}: no word timestamp for cue [{cue['span']}], fell back to the sentence start")
                cues.append({**cue, "at": at, "sentence": s["id"], "word": w["word"] if w else None,
                             "fallback": fallback})
        cues.sort(key=lambda c: c["at"])

        # The scene's own entrance is a visual change too. Hold the first cue until the scene has settled.
        first_visual = next((c["at"] for c in cues if c["verb"] != "play"), None)
        if first_visual is not None and first_visual < breathing:
            delta = breathing - first_visual
            placed = [(s, rec, offset + delta) for s, rec, offset in placed]
            for c in cues:
                c["at"] += delta
            countdown = (countdown[0] + delta, countdown[1] + delta) if countdown else None
            t += delta
            end += delta

        steps_plan = None
        if layout == "steps":
            from .steps import load_capture, plan as plan_steps

            cap = load_capture(paths, scene["steps"]["id"])
            actions, steps_end = plan_steps(cap, cues, scene["steps"]["start"])
            steps_plan = {"capture": cap["id"], "start": scene["steps"]["start"], "actions": actions}
            end = max(end, steps_end + 0.6)
            for ci, c in enumerate(cues):
                mine = [a["t"] for a in actions if a.get("cue") == ci]
                late = (min(mine) - c["at"]) if mine else 0.0
                if late > 0.5:
                    warnings.append(f"{scene['id']}: [{c['span']}] lands {late:.1f} s after its word, because the "
                                    "step before it is still running. Give that step more narration")

        play = None
        if layout == "cast":
            dur = cast_duration(Path(scene["cast"]["path"]))
            default_at = t if not placed else placed[0][2]
            segments, hold, busy, late = plan_cast(paths, scene["cast"]["id"], cues, dur, default_at)
            for span, seconds in late:
                warnings.append(f"{scene['id']}: [{span}] plays {seconds:.1f} s after its word, because the command "
                                "before it is still running. Give that command more narration")
            play = {"capture": scene["cast"]["id"], "hold": hold, "segments": segments, "duration": dur}
            end = max(end, busy + 1.2)

        visual = [c for c in cues if c["verb"] != "play"]
        hop_s = float(house.motion["verbs"]["trace"]["duration"])
        for a, b in zip(visual, visual[1:]):
            if b["at"] - a["at"] < breathing * 0.6:
                warnings.append(f"{scene['id']}: cues [{a['span']}] and [{b['span']}] are {b['at'] - a['at']:.2f} s apart, "
                                f"under the {breathing:.1f} s breathing room")
            elif a["verb"] == "trace" and b["at"] < a["at"] + hop_s * len(a["params"].get("hops") or [1]) - 0.05:
                warnings.append(f"{scene['id']}: [{b['span']}] lands while the trace on [{a['span']}] is still "
                                "moving. Give the trace more narration, or trace fewer steps")
        last_trace = next((c for c in reversed(visual) if c["verb"] == "trace"), None)
        if last_trace and last_trace["at"] + hop_s * len(last_trace["params"].get("hops") or [1]) > end:
            end = last_trace["at"] + hop_s * len(last_trace["params"]["hops"]) + 0.6  # let the last trace arrive

        n_frames = frames(end, fps)
        sentences = []
        for s, rec, offset in placed:
            sentences.append({
                "id": s["id"], "text": s["text"], **({"shown": s["shown"]} if s.get("shown") else {}),
                "kind": s["kind"], "voice": s["voice"], "claims": s["claims"],
                "t": round(offset, 4),
                "start_ms": round((start + offset) * 1000, 1),
                "end_ms": round((start + offset + rec["duration"]) * 1000, 1),
                "wav": rec["wav"],
                "words": [{"word": w["word"], "start_ms": round((start + offset + w["start"]) * 1000, 1),
                           "end_ms": round((start + offset + w["end"]) * 1000, 1), "fallback": w["fallback"]}
                          for w in rec["words"]],
            })
        scenes_out.append({
            "id": scene["id"], "layout": layout, "params": scene["params"],
            "start_ms": round(start * 1000, 3), "end_ms": round((cursor_frames + n_frames) / fps * 1000, 3),
            "frames": n_frames,
            "sentences": sentences,
            "cues": [{"verb": c["verb"], "target": c["target"], "params": c["params"], "span": c["span"],
                      "t": round(c["at"], 4), "at_ms": round((start + c["at"]) * 1000, 1), "sentence": c["sentence"],
                      "word": c["word"], "fallback": c["fallback"]} for c in cues],
            **({"countdown": {"t0": round(countdown[0], 4), "t1": round(countdown[1], 4),
                              "start_ms": round((start + countdown[0]) * 1000, 1),
                              "end_ms": round((start + countdown[1]) * 1000, 1)}} if countdown else {}),
            **({"play": {"capture": play["capture"], "hold": play["hold"], "duration_ms": round(play["duration"] * 1000, 1),
                         "at_ms": round((start + play["segments"][0]["at"]) * 1000, 1),
                         "segments": [{"t": round(s["at"], 4), "at_ms": round((start + s["at"]) * 1000, 1),
                                       "from": s["from"], "to": s["to"], "step": s["step"]} for s in play["segments"]]}}
               if play else {}),
            **({"steps": steps_plan} if steps_plan else {}),
        })
        cursor_frames += n_frames

    timeline = {
        "version": 1,
        "lesson": plan["lesson"]["id"],
        "course": plan["course"],
        "title": plan["lesson"]["front"].get("title", plan["lesson"]["id"]),
        "fps": fps, "width": int(eff["video.width"]), "height": int(eff["video.height"]),
        "frames": cursor_frames,
        "duration_ms": round(cursor_frames / fps * 1000, 3),
        "voices": tts["voices"],
        "scenes": scenes_out,
        "warnings": warnings,
    }
    out = paths.build_dir(plan["lesson"]["id"])
    (out / "timeline.json").write_text(json.dumps(timeline, indent=1, ensure_ascii=False))
    write_narration(timeline, out / "narration.wav")
    return timeline, warnings


def write_narration(timeline: dict, path: Path) -> None:
    """One mono track, sample-exact against the frame grid: 30 fps at 24 kHz is 800 samples a frame."""
    total = int(round(timeline["frames"] / timeline["fps"] * SR))
    track = np.zeros(total, dtype=np.float32)
    for scene in timeline["scenes"]:
        for s in scene["sentences"]:
            audio, sr = sf.read(s["wav"], dtype="float32")
            assert sr == SR
            at = int(round(s["start_ms"] / 1000 * SR))
            n = min(len(audio), total - at)
            track[at:at + n] = audio[:n]
    sf.write(path, track, SR, subtype="PCM_16")
