"""Steps scenes: turn a browser capture and its cues into timed actions, once, for the timeline and the renderer.

A capture's images run 0..n: image 0 is the page as it loaded, image k is the page after step k. A target touched by
step k was measured before the action, so it lives on image k-1. A target recorded after step k lives on image k.
"""
from __future__ import annotations

import json
from pathlib import Path

from .paths import CoursePaths, LecternError

GLIDE = 0.7       # cursor travel to the element
CLICK = 0.15      # ripple lead before the page reacts
FADE = 0.35       # crossfade between images
HOLD = 0.5        # settle after a step before the next can start
VIEW_VERBS = ("zoom", "pan")
ACCENT_VERBS = ("spotlight", "light", "arrow", "pulse", "callout")
STEP_VERBS = ("play", *VIEW_VERBS, *ACCENT_VERBS)


def load_capture(paths: CoursePaths, capture_id: str) -> dict:
    d = paths.captures / capture_id
    meta_p, targets_p = d / "meta.json", d / "targets.json"
    if not meta_p.exists() or not targets_p.exists():
        raise LecternError(f"capture {capture_id} has not run. Run `lectern capture {capture_id}`")
    meta = json.loads(meta_p.read_text())
    if meta.get("kind") != "browser":
        raise LecternError(f"capture {capture_id} is not a browser capture")
    meta["targets"] = json.loads(targets_p.read_text())
    meta["dir"] = str(d)
    return meta


def step_index(cap: dict, step_id: str) -> int:
    ids = [s["id"] for s in cap["steps"]]
    if step_id not in ids:
        raise LecternError(f"capture {cap['id']} has no step {step_id}. Steps: {', '.join(ids)}")
    return ids.index(step_id)


def target_image(cap: dict, target: str) -> tuple[int, list[float]]:
    t = cap["targets"].get(target)
    if t is None:
        raise LecternError(f"capture {cap['id']} has no target {target}. Targets: {', '.join(cap['targets'])}")
    k = step_index(cap, t["step"])
    return (k - 1 if t["phase"] == "before" else k), t["box"]


def expand_play(cap: dict, target: str | None, current: int) -> list[int]:
    n = len(cap["steps"])
    if not target:
        return [current + 1] if current + 1 < n else []
    if target == cap["id"]:
        return list(range(max(current + 1, 1), n))
    if ".." in target:
        a, b = target.split("..", 1)
        ia, ib = step_index(cap, a), step_index(cap, b)
        if ib < ia:
            raise LecternError(f"play range {target} runs backwards")
        return list(range(ia, ib + 1))
    return [step_index(cap, target)]


def clicks(step: dict) -> bool:
    """A step the cursor performs: it touched an element. goto, wait and the first page simply crossfade in."""
    return step.get("action") is not None and bool(step.get("touched"))


def step_length(step: dict) -> float:
    if not clicks(step):
        return FADE + HOLD
    burst = step.get("burst") or []
    tail = burst[-1]["t"] + 0.25 if burst else FADE
    return GLIDE + CLICK + tail + HOLD


def plan(cap: dict, cues: list[dict], start: int = 0) -> tuple[list[dict], float]:
    """Timed actions for one steps scene. `cues` carry scene-relative `at` seconds, sorted. Returns (actions, end)."""
    actions: list[dict] = []
    image, busy_until = start, 0.0

    def show(t: float, k: int) -> bool:
        nonlocal image
        if k == image:
            return False
        actions.append({"t": round(t, 3), "do": "show", "image": k, "from": image})
        image = k
        return True

    for ci, cue in enumerate(cues):
        verb, target, t = cue["verb"], cue.get("target"), max(float(cue["at"]), 0.0)
        if verb not in STEP_VERBS:
            continue
        first = len(actions)
        if verb == "play":
            t = max(t, busy_until)
            for k in expand_play(cap, target, image):
                step = cap["steps"][k]
                if not clicks(step):
                    show(t, k)
                    t += FADE + HOLD
                    continue
                show(t, k - 1)
                frames = [{"t": round(t + GLIDE + CLICK + f["t"], 3), "file": f["file"]} for f in step.get("burst") or []]
                actions.append({"t": round(t, 3), "do": "play", "step": k, "box": step.get("touched"),
                                "click_at": round(t + GLIDE, 3), "frames": frames,
                                "settle_at": round(t + step_length(step) - HOLD, 3), "image": k, "from": image})
                image = k
                t += step_length(step)
            busy_until = t
            for a in actions[first:]:
                a["cue"] = ci
            continue
        t = max(t, busy_until)
        if verb in ("zoom", "pan") and target == "page":
            actions.append({"t": round(t, 3), "do": verb, "box": None, "cue": ci})
            continue
        k, box = target_image(cap, target)
        if show(t, k):
            t += FADE  # let the right image land before the camera or an accent moves
        act = {"t": round(t, 3), "do": verb, "box": box, "target": target}
        if verb == "callout":
            act["text"] = cue["params"].get("text", "")
        actions.append(act)
        for a in actions[first:]:
            a["cue"] = ci
    end = max([busy_until] + [a["t"] + 1.2 for a in actions])
    return actions, round(end, 3)


def images_used(cap: dict, actions: list[dict], start: int) -> list[str]:
    files = {cap["steps"][start]["file"]}
    for a in actions:
        if a["do"] in ("show", "play"):
            files.add(cap["steps"][a["image"]]["file"])
            files.add(cap["steps"][a["from"]]["file"])
        for f in a.get("frames", []):
            files.add(f["file"])
    return sorted(files)


def asset_path(cap: dict, file: str) -> Path:
    return Path(cap["dir"]) / file
