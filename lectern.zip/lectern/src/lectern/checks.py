"""check: the deterministic gates. A broken result blocks the build, a warning lands in the QA report."""
from __future__ import annotations

import hashlib
import json
import re
import subprocess
from pathlib import Path

from .capture import capture_text, load_meta, scan_secrets
from .config import CourseManifest, House, load_yaml
from .paths import CoursePaths, LecternError
from .sources import read_source, web_url


def norm_ws(s: str) -> str:
    return re.sub(r"\s+", " ", s).strip()


def contrast(fg: str, bg: str) -> float:
    def lum(hex_color: str) -> float:
        h = hex_color.lstrip("#")
        rgb = [int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)]
        lin = [c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4 for c in rgb]
        return 0.2126 * lin[0] + 0.7152 * lin[1] + 0.0722 * lin[2]

    a, b = sorted([lum(fg), lum(bg)], reverse=True)
    return (a + 0.05) / (b + 0.05)


def measure_loudness(wav: Path) -> dict:
    p = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-i", str(wav), "-af",
                        "loudnorm=I=-16:TP=-1.5:LRA=11:print_format=json", "-f", "null", "-"],
                       capture_output=True, text=True)
    m = re.search(r"\{[^{}]*\"input_i\"[^{}]*\}", p.stderr, re.S)
    if not m:
        raise LecternError(f"could not measure loudness of {wav}")
    return json.loads(m.group(0))


def normalize_loudness(src: Path, dst: Path, target: float, true_peak: float) -> dict:
    """Two-pass EBU R128 normalization, linear so speech keeps its dynamics."""
    m = measure_loudness(src)
    af = (f"loudnorm=I={target}:TP={true_peak}:LRA=11:measured_I={m['input_i']}:measured_TP={m['input_tp']}:"
          f"measured_LRA={m['input_lra']}:measured_thresh={m['input_thresh']}:offset={m['target_offset']}:linear=true:"
          f"print_format=json")
    p = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-y", "-i", str(src), "-af", af, "-ar", "48000",
                        "-c:a", "pcm_s16le", str(dst)], capture_output=True, text=True)
    if p.returncode:
        raise LecternError(f"loudness normalization failed: {p.stderr[-500:]}")
    return measure_loudness(dst)


def check_claims(paths: CoursePaths, course: CourseManifest, plan: dict) -> tuple[list[dict], list[str]]:
    ledger = load_yaml(Path(plan["claims_ledger"]))
    results, broken = [], []
    cast_cache: dict[str, str] = {}
    cited = {c for sc in plan["scenes"] for s in sc["sentences"] for c in s["claims"]}
    for cid in sorted(cited):
        entry = ledger.get(cid) or {}
        kind, src, excerpt = entry.get("kind"), entry.get("source") or {}, entry.get("excerpt", "")
        status, where, url = "ok", "", None
        try:
            if not excerpt.strip():
                raise LecternError("empty excerpt")
            if kind in ("doc", "code") and src.get("file"):
                # A file in the course repo, such as example data a capture ran on.
                rel = src["file"]
                f = paths.root / rel
                where = rel
                if not f.is_file():
                    raise LecternError(f"course file {rel} not found")
                ran = ran_hashes(paths, lesson_captures(plan)).get(rel)
                if ran is not None and sha256_file(f) not in ran:
                    raise LecternError(f"{rel} changed after its capture ran. Re-run the capture")
                if norm_ws(excerpt) not in norm_ws(f.read_text(encoding="utf-8")):
                    raise LecternError(f"excerpt not found in {rel}")
            elif kind in ("doc", "code"):
                name, ref, path = src.get("repo"), src.get("ref"), src.get("path")
                pin = course.sources.get(name)
                if pin and ref and ref != pin.ref:
                    raise LecternError(f"cites {name}@{ref} but the course pins {pin.ref}")
                text = read_source(course, name, path)
                where, url = f"{name}@{pin.ref}:{path}", web_url(course, name, path)
                if norm_ws(excerpt) not in norm_ws(text):
                    raise LecternError(f"excerpt not found in {where}")
            elif kind == "run":
                cap = src.get("capture")
                if cap not in lesson_captures(plan):
                    raise LecternError(f"cites capture {cap}, which this lesson does not list in captures")
                if cap not in cast_cache:
                    text = capture_text(paths, cap)
                    if text is None:
                        raise LecternError(f"capture {cap} has not run. Run `lectern capture {cap}`")
                    cast_cache[cap] = text
                where = f"capture {cap}"
                if norm_ws(excerpt) not in norm_ws(cast_cache[cap]):
                    raise LecternError(f"excerpt not found in the output of {where}")
            else:
                raise LecternError(f"unknown kind {kind!r}")
        except LecternError as e:
            status = "broken"
            broken.append(f"claim {cid}: {e}")
            where = where or str(e)
        results.append({"id": cid, "kind": kind, "status": status, "where": where, "url": url, "excerpt": excerpt})
    return results, broken


def sha256_file(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def lesson_captures(plan: dict) -> set[str]:
    """The captures a lesson may draw on: those its front matter lists, plus any its cast scenes play."""
    listed = set(plan["lesson"]["front"].get("captures") or [])
    played = {sc["cast"]["id"] for sc in plan["scenes"] if sc["layout"] == "cast"}
    return listed | played | {sc["steps"]["id"] for sc in plan["scenes"] if sc["layout"] == "steps"}


def ran_hashes(paths: CoursePaths, captures: set[str] | None = None) -> dict[str, set[str]]:
    """Hashes of every course file the given captures executed, by path. None means every capture in the course."""
    ran: dict[str, set[str]] = {}
    for meta in paths.captures.glob("*/meta.json"):
        if captures is not None and meta.parent.name not in captures:
            continue
        m = json.loads(meta.read_text())
        for f, h in (m.get("shows") or {}).items():
            ran.setdefault(f, set()).add(h)
    return ran


def stacks_ran(paths: CoursePaths, captures: set[str]) -> set[tuple[str, str]]:
    """(source, commit) for every stack checkout these captures ran in."""
    out = set()
    for cap in captures:
        stack = load_meta(paths, cap).get("stack") or {}
        if stack.get("source") and stack.get("commit"):
            out.add((stack["source"], stack["commit"]))
    return out


def check_code_ran(paths: CoursePaths, plan: dict) -> tuple[list[dict], list[str]]:
    """Every file shown in a code scene must be byte-identical to a file one of this lesson's captures executed.

    A course file passes when a capture recorded its hash. A file from a pinned source, such as the stack, passes when
    one of the lesson's captures ran that source at the pinned commit, with no tracked file changed.
    """
    captures = lesson_captures(plan)
    ran = ran_hashes(paths, captures)
    stacks = stacks_ran(paths, captures)
    out, broken = [], []
    for sc in plan["scenes"]:
        if sc["layout"] != "code":
            continue
        code, src = sc["code"], sc["code"]["src"]
        if code.get("source"):
            ok = (code["source"], code["commit"]) in stacks
            out.append({"scene": sc["id"], "file": src, "ran": ok})
            if not ok:
                broken.append(f"code scene {sc['id']}: no capture in this lesson ran {code['source']} at the pinned "
                              f"commit {str(code['commit'])[:12]}. List one in captures, or re-run it")
            continue
        ok = sha256_file(paths.root / src) in ran.get(src, set())
        out.append({"scene": sc["id"], "file": src, "ran": ok})
        if not ok:
            broken.append(f"code scene {sc['id']}: {src} differs from every run this lesson's captures recorded. "
                          "Re-run the capture")
    return out, broken


def on_screen_words(scene: dict, timeline_scene: dict, front: dict, course_title: str) -> int:
    words = 0
    if scene["layout"] == "title":
        words = len(str(front.get("title", "")).split()) + len(course_title.split()) + 4
    if scene["layout"] == "checkpoint":
        asks = " ".join(s.get("shown") or s["text"] for s in timeline_scene["sentences"] if s["kind"] == "ask")
        answers = [s.get("shown") or s["text"] for s in timeline_scene["sentences"] if s["kind"] == "answer"]
        words = len(asks.split()) + len((scene["params"].get("card") or (answers[0] if answers else "")).split())
    for cue in timeline_scene["cues"]:
        if cue["verb"] == "callout":
            words += len(cue["params"]["text"].split())
    return words


def run_checks(paths: CoursePaths, course: CourseManifest, house: House, plan: dict, timeline: dict, eff,
               narration: Path, page_text: Path | None = None, render: dict | None = None) -> dict:
    tokens = house.tokens
    floor = tokens["floor"]
    broken, warnings = [], list(timeline.get("warnings", [])) + list((render or {}).get("warnings", []))
    report: dict = {}

    # Length cap
    minutes = timeline["duration_ms"] / 60000
    cap = float(eff["cap_minutes"])
    report["length"] = {"minutes": round(minutes, 2), "cap": cap, "ok": minutes <= cap}
    if minutes > cap:
        broken.append(f"lesson runs {minutes:.1f} min, over the {cap:.0f} min cap. Cut it, or set cap_minutes and cap_reason")

    # Claims and code
    report["claims"], b = check_claims(paths, course, plan)
    broken += b
    report["code_ran"], b = check_code_ran(paths, plan)
    broken += b

    # Redaction: every cast and every source file this lesson shows, plus the page text
    files = [Path(sc["cast"]["path"]) for sc in plan["scenes"] if sc["layout"] == "cast"]
    files += sorted({paths.root / sc["code"]["src"] for sc in plan["scenes"]
                     if sc["layout"] == "code" and not sc["code"].get("source")})
    shown = paths.build_dir(plan["lesson"]["id"]) / "shown"
    for sc in plan["scenes"]:
        if sc["layout"] == "code" and sc["code"].get("source"):
            # Source files are scanned as shown, from the text the plan carries.
            shown.mkdir(parents=True, exist_ok=True)
            f = shown / f"{sc['id']}.txt"
            f.write_text(sc["code"]["text"], encoding="utf-8")
            files.append(f)
    for sc in plan["scenes"]:
        if sc["layout"] == "steps":
            files += sorted((paths.captures / sc["steps"]["id"] / "steps").glob("*.txt"))
    if page_text and page_text.exists():
        files.append(page_text)
    report["redaction"] = scan_secrets(files)
    if report["redaction"]["findings"]:
        broken.append(f"gitleaks found {report['redaction']['findings']} secret(s): {report['redaction']['details']}")
    elif report["redaction"]["tool"] is None:
        warnings.append("gitleaks is not installed, so the redaction scan did not run")

    # Legibility floors
    sizes = tokens["size"]
    body_min = min(sizes[k] for k in ("body", "label", "node", "chip", "small"))
    from .render import terminal_font_px

    term_px = [terminal_font_px(timeline["width"], tokens, json.loads(Path(sc["cast"]["path"]).read_text(
        encoding="utf-8").split("\n", 1)[0])["width"]) for sc in plan["scenes"] if sc["layout"] == "cast"]
    leg = {"body_px": body_min, "code_px": round(min([sizes["code"], *term_px]), 1), "contrast": {}, "words": {}}
    if body_min < floor["body_px"]:
        broken.append(f"body text {body_min}px is under the {floor['body_px']}px floor")
    if leg["code_px"] < floor["code_px"]:
        broken.append(f"code text {leg['code_px']}px is under the {floor['code_px']}px floor")
    c = tokens["color"]
    for fg in ("ink", "quiet", "accent"):
        for bg in ("bg", "panel", "panel_2", "code_bg"):
            ratio = contrast(c[fg], c[bg])
            leg["contrast"][f"{fg} on {bg}"] = round(ratio, 2)
            if ratio < floor["contrast"]:
                broken.append(f"{fg} on {bg} contrast is {ratio:.2f}, under {floor['contrast']}")
    leg["contrast"]["accent_ink on accent"] = round(contrast(c["accent_ink"], c["accent"]), 2)
    tl_scenes = {s["id"]: s for s in timeline["scenes"]}
    for sc in plan["scenes"]:
        n = on_screen_words(sc, tl_scenes[sc["id"]], plan["lesson"]["front"], plan["course"]["title"])
        leg["words"][sc["id"]] = n
        if n > floor["prose_words"]:
            broken.append(f"scene {sc['id']} puts {n} words of prose on screen, over {floor['prose_words']}")
    report["legibility"] = leg

    # Loudness
    m = measure_loudness(narration)
    # Normalization aims the peak at true_peak_db. The gate allows up to -1 dBTP, the usual delivery ceiling.
    target = float(eff["loudness_lufs"])
    loud = {"integrated": float(m["input_i"]), "true_peak": float(m["input_tp"]), "target": target}
    loud["ok"] = abs(loud["integrated"] - target) <= 1.0 and loud["true_peak"] <= -1.0
    report["loudness"] = loud
    if not loud["ok"]:
        broken.append(f"loudness {loud['integrated']} LUFS, true peak {loud['true_peak']} dBTP. Target {target} within 1 LU, peak under -1")

    # Word timestamps
    missing = [w["word"] for sc in timeline["scenes"] for s in sc["sentences"] for w in s["words"] if w["fallback"]]
    report["timestamps"] = {"words": sum(len(s["words"]) for sc in timeline["scenes"] for s in sc["sentences"]),
                            "fallback": len(missing), "fallback_words": missing}
    if missing:
        warnings.append(f"{len(missing)} words have no Kokoro timestamp: {', '.join(missing[:12])}")

    if plan.get("no_claim_sentences"):
        warnings.append(f"{len(plan['no_claim_sentences'])} sentences marked ^nc need a look at gate one")
    from .package import clone_url, lesson_commands

    for g in lesson_commands(paths, plan, course):
        if g["stack"] and not clone_url(g["stack"]):
            warnings.append(f"the page's Commands block clones {g['stack']['source']} from a placeholder URL. Set "
                            f"sources.{g['stack']['source']}.clone in course.yaml to the address teammates clone from")
            break
    report["broken"], report["warnings"] = broken, warnings
    report["ok"] = not broken
    out = paths.build_dir(plan["lesson"]["id"]) / "check.json"
    out.write_text(json.dumps(report, indent=1, ensure_ascii=False))
    return report
