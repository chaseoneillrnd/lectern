# Lectern

One Markdown lesson script in. A narrated, verified video lesson and a VitePress page out.

Kokoro narrates on CPU. HyperFrames renders HTML and GSAP compositions to frames. Every technical sentence cites an
excerpt that a check finds verbatim in a pinned source or a captured run, and two human gates sign off before a lesson
ships. No paid services, no telemetry, nothing downloads at render time.

## Pipeline

```
capture/<id>.yaml ──capture──► captures/   (terminal casts, browser steps with element boxes)
                                   │
lessons/<id>.md ──compile──► plan.json ──tts──► tts.json ──timeline──► timeline.json ──render──► video.mp4
                     │                                                                    │
                     └─ claims and shown code checked before anything renders             └─ one cached MP4 per scene
                                                                     check ──► package ──► dist/<course>/<id>/
```

`lectern build <id>` runs every stage after capture. Each stage caches by content hash, and every scene carries its own
timing, so editing one sentence re-synthesizes that sentence and re-renders only its scene.

Per lesson, `dist/<course>/<id>/` holds `lesson.mp4` (1080p30, H.264 and AAC, chapters from scenes), `lesson.vtt`
(captions from Kokoro's word timestamps), `transcript.md` (with claim tags), `slides.pdf` (one settled frame per scene),
`poster.jpg`, `page.md` (the VitePress page, with a Commands block of everything the lesson's captures typed, in
order), and `review/`
(contact sheet, QA report, check results, the frame inspector's findings).

## Install

### Container (recommended for builds)

```
docker build -t lectern:0.2.0 .
docker run --rm -it -v "$PWD:/course" -v lectern-home:/root/.lectern lectern:0.2.0 build ragas.faithfulness
```

The image carries Python 3.12, CPU-only torch, Kokoro-82M weights pinned to one commit, Node 22, HyperFrames 0.8.170
with its headless browser, FFmpeg n8.0.1 and gitleaks built from source. Behind a TLS-inspecting proxy, pass its CA as
a build secret (`--secret id=proxy_ca,src=ca.pem`). No layer keeps it. If Docker Hub rate-limits the build, point the
base images at a mirror with `--build-arg GO_IMAGE=mirror.gcr.io/library/golang:1.24.7-bookworm` and the matching
`NODE_IMAGE` and `PYTHON_IMAGE` arguments.

### Native

Python 3.12, Node 22, FFmpeg 6 or newer.

```
uv venv && uv pip install -r requirements.lock.txt && uv pip install -e .
npm ci && npx hyperframes browser ensure
lectern init            # caches Kokoro's weights and voices, then checks the toolchain
lectern profile         # times a probe render and saves the fastest worker count for this machine
```

gitleaks is optional natively. Without it the redaction scan is skipped and the QA report says so.

### Captures

Captures run where the stack runs, natively, because they drive Docker, Tilt and the stack's own tools. Browser
captures need Playwright: `uv pip install -e ".[capture]"`, then either `playwright install chromium` or point
`LECTERN_CAPTURE_BROWSER` at a Chromium you already have, such as the one `npx hyperframes browser path` prints.

## Quick start

```
lectern wizard course              # or /lectern:wizard course in Claude Code
lectern sources                    # caches every pinned source, so claim checks run offline
lectern wizard lesson
lectern capture <id>...            # runs capture scripts in order, against the live stack
lectern compile <id>               # cues, targets, claim tags, unknown words
lectern claims <id>                # every excerpt against its pinned source or captured output
lectern judge-input <id>           # bundle for the claims-judge agent
lectern judge-save <id> --result judge.json
lectern gate packet <id> one       # review page: script and evidence side by side
lectern gate approve <id> one
lectern build <id>
lectern inspect-input <id>         # bundle for the frame-inspector agent
lectern inspect-save <id> --result inspect.json
lectern gate packet <id> two       # review folder: the MP4, a frame after every cue, findings, the QA report
lectern gate approve <id> two
lectern stale                      # pins against upstream. Flags lessons, never blocks
lectern preview                    # local VitePress site with the Lectern theme
lectern status
```

## A course repo

```
course.yaml          id, title, kind, pinned sources (repo, ref, commit), library pins, skeleton, defaults
map.yaml             the course Map: one box per component, pinned to a 12 by 6 grid, and the edges between them
terms.yaml           course terms over the house terms: definitions and pronunciations
lessons/<id>.md      the script
lessons/<id>.claims.yaml   the claims ledger: kind, source, verbatim excerpt
lessons/<id>.gates.yaml    approvals, pinned to the hashes of what was reviewed
diagrams/<name>.yaml boxes on a 12 by 6 grid, and edges
capture/<id>.yaml    what a capture runs: terminal steps, or browser steps found by role and name
captures/            casts (asciicast v2), step screenshots (Git LFS), targets.json and meta.json per capture
examples/            runnable code the lessons show
.gitlab-ci.yml       a scheduled `lectern stale`, and claim checks on merge requests
```

A source's `repo` is a URL or a path relative to the course, so a stack course sits beside its stack as a sibling
repo. When `repo` is a path, `clone` gives the URL that lesson pages tell teammates to clone from. `lectern sources
--repin <name>` moves a pin to the commit its ref points at now. Library pins that `lectern
stale` should watch name their registry: `haystack-ai: {version: "3.4.0", pypi: haystack-ai}` or
`tilt: {version: "0.37.8", github: tilt-dev/tilt}`.

## Script format

```
## setup  layout=code  src=examples/faithfulness.py  show=1-7  title="Build the scorer"
In code, [two lines]{lines=6-7} build the scorer around a [judge model]{chip}. ^faith-08
```

`## <scene> layout=...` opens a scene. Prose is narration. `[span]{verb=target}` fires a cue on the span's first word.
`^claim-id` ends a technical sentence and must resolve in the ledger. `> ask:` and `> answer:` make a checkpoint, voiced
by the Examiner and the Narrator.

| Layout | Shows | Verbs |
| --- | --- | --- |
| title | the lesson's title card | chip |
| map | the course Map from `map.yaml`, the same in every lesson. `component=<id>` opens with it lit | light, pulse, trace, callout, chip |
| diagram | boxes and arrows from `diagrams/` | light, pulse, trace, callout, chip |
| code | a course file, or `src=<source>:<path>` from a pinned source | lines, callout, chip |
| cast | a terminal capture, played one command per `{play=<step>}` | play, mark, chip |
| steps | a browser capture with a synthesized cursor, clicks and crossfades | play, zoom, pan, spotlight, arrow, light, pulse, callout, chip |
| checkpoint | a question, a countdown, the answer | |

`{mark="0.734"}` outlines text the terminal shows, until the next command plays. The newest mark carries the
accent, and older ones fade to a quiet outline, or out entirely with `trail=clear`. `{trace=<edge>}` sends a dot
along one edge. `{trace=browser>app>llm}` follows a path of components, crossing one edge per step in either
direction, and lights it as it goes.

`[0.7]{say="zero point seven"}` gives the voice other words than the screen. The checkpoint card, the page and the
transcript show `0.7`, while the voice and the captions say "zero point seven".

The `/lectern:lesson` skill carries the full writing rules, and `/lectern:capture` the capture rules.

## The course Map

A course draws one Map, from `map.yaml`, in every lesson. Back-to-back map scenes share it with no fade, so only the
highlights move, and a drilldown opens on it with its component lit. `lectern lesson new <id> --type drilldown
--component <id>` starts one, and refuses a component the Map does not have.

- `lectern map draft` lays out the components that have no position yet. Positions already set never move.
- `lectern map still --out map.png` shows the Map as a lesson draws it, without a build.
- `lectern map check` photographs every built map scene as it settles, in the renderer's own browser, and compares each
  one with a still of the Map alone, pixel by pixel. It also compares the packaged MP4s at the same frames.
- Each build records the Map it drew. Edit `map.yaml` and every lesson that draws it shows a rebuild in `lectern status`
  and drops out of gate two until it is rebuilt.
- `lectern site` writes the course page and the glossary page. The course page lists the lessons in skeleton order,
  with length, what to watch first, and status, under the CourseMap. Each component on the CourseMap opens its
  drilldown, or its chapter in the Map lesson until a drilldown exists.

## Captures

A terminal capture runs real commands in a pseudo-terminal: typing is presentation, output is always real, and idle
gaps compress. Each step records where its prompt, typing and output fall, so a cast scene plays one command per cue
and holds still between them. A command that never exits, such as `tilt up`, takes `until:` and stops once that text
prints.

A browser capture drives the UI with Playwright and saves a 2x screenshot per step, a text dump for the secrets scan,
and the box of every element it touched or named, found by role and name and never by pixels. Bursts keep real
in-app motion such as a streaming answer. Masks hide elements in every screenshot, and a click that opens a new tab
carries on in it.

With `stack: <source>`, a capture runs in a checkout of that source at exactly the pinned commit, fresh like a new
clone when it says `fresh: true`, and records the commit and the stack paths it depends on. Only variables named in
`env_pass` reach a capture from your shell, and only their names are recorded. Login state for UIs behind a sign-in
comes from a Playwright `storage_state` file kept outside the repo.

## Checks

A build blocks on: a technical sentence (a glossary term, a digit or a spoken number) without a claim tag, an excerpt
missing from its pinned source or captured output, a source cache not at the pinned commit, code on screen that no
capture of the lesson ran (a course file must match a hash a capture recorded, a stack file needs a capture that ran
the stack at the pinned commit), a gitleaks hit in a cast, a page text dump, a shown file or the transcript, text under
the size floor (terminal text included, at the size the player draws it), contrast under 4.5:1, more than 25 words of
prose on screen, loudness more than 1 LU off -16 LUFS or a true peak above -1 dBTP, and a lesson over its length cap
without a reason. Missing word timestamps, cues closer together than the breathing room, a cue that waits more than
half a second for the step before it, and a chip that covers content are warnings in the QA report.

Gate two only takes an MP4 whose build record matches the current script and ledger, at standard quality and full
fidelity, with every check green. A draft render never reaches it. A published review page carries files up to 15 MB,
so a longer cut plays there from a re-encode the page labels as one. Its frames come from the full render, and the
approval pins the original file.

## Model judges

Two agents advise and never gate, and each is calibrated on planted examples before its first use in a course.

- **claims-judge** scores how well each sentence's excerpts support it, 0 to 3. It must catch every planted bad claim.
- **frame-inspector** looks at the frame after every cue for collisions, overflow, unreadable text and accents that
  miss their target. It must flag every planted defect and pass every clean frame. Its findings sit beside each frame
  in the gate-two packet.

Neither is ever the agent that wrote the lesson.

## Staleness

`lectern stale` compares every pin against upstream and flags a lesson when an excerpt it cites is missing at its
source's HEAD, when a stack path one of its captures depends on changed, when a newer release of a pinned source or
library exists, or when a pinned ref moved. Flags show in `lectern status` and as a banner on the lesson's page, and a
verdict is dropped once the pins or captures it was reached against change. Run it on a schedule in the course repo,
never in the stack's merge requests, so the stack stays clean.

## Measured on 2 CPUs and 8 GB

| | |
| --- | --- |
| Cold render, 1:56 lesson, 7 scenes | 202 to 211 s |
| Edit one sentence, rebuild | about 100 s, one scene re-renders |
| Kokoro, one sentence | about 3.7 s |
| Two cold renders of the same inputs | every frame identical, byte-identical MP4 and narration |
| Cold build in the container, offline: synthesis, render, checks, package | 275 s |
| Container render against a native render | 3,507 of 3,507 frames identical, Kokoro audio byte-identical |
| Stack Quick start captures: fresh clone, 530 MB of models, `tilt up`, dashboard and app tour, `tilt down` | 28 to 50 s, images cached |
| Cold render, 3:55 stack Quick start, 9 scenes | 349 s |
| Two cold renders of the stack Quick start | 7,048 of 7,048 frames identical, byte-identical MP4 and narration |
| The stack Quick start built cold and offline in the container, against native | 7,048 of 7,048 frames identical, audio byte-identical for every sentence synthesized on the same host |
| Cold render, 3:49 stack Map lesson, 12 scenes, 10 of them on the Map | 385 to 408 s |
| Two cold renders of the Map lesson | 6,859 of 6,859 frames identical, byte-identical video and narration, and the same bytes as the incremental build |
| Stack drilldown capture: compose up without Tilt, the health check, one streamed question, compose down | 12 s raw, 24.9 s in the cast |
| Cold build, 5:10 stack drilldown, 13 scenes: synthesis of 59 sentences, then render | 187 s, then 610 s |
| `lectern map check`: 11 map scenes in three lessons against a still of the Map alone | pixel-identical in the browser, packaged MP4s within 52 dB of each other |

## Narration cache

Kokoro's audio is byte-identical on one CPU model. Across CPU models, measured on the stack Quick start, 9 of 46
sentences differed in about 0.2% of their samples, each by one step of 16-bit audio. No one can hear that, but it
changes the MP4's hash, and gate two pins that hash. So every machine that builds a course reads one cache, keyed by
each sentence's text, voice, speed and seed. The first match wins:

1. `LECTERN_TTS_CACHE`
2. `tts_cache` in the machine's `~/.lectern/machine.yaml`
3. `tts_cache` in `course.yaml`, relative to the course
4. `.lectern/cache/tts`

During the pilot the cache lives on the render server: set `tts_cache: /srv/lectern/tts` in that machine's profile.
A machine that must reproduce the same audio copies the folder from there, with rsync for example. After the pilot it
moves into the course repo under Git LFS, which both GitHub and GitLab host: move the folder to `tts/` in the course,
set `tts_cache: tts` in `course.yaml`, and run `git lfs track "tts/**"`. One lesson's narration is about 11 MB.
`lectern status` prints the cache in use.

## Config

Four layers, later wins: house package (`src/lectern/house`), `course.yaml` defaults, lesson front matter, CLI flags.
`lectern config explain <key>` prints the chain and names the winner. Overriding `cap_minutes` needs `cap_reason` in the
same layer. Every value validates against `house/questions.yaml` before it is written, and only the CLI writes config.

## Not in this version

The chapter and split layouts, the diff verb, tutor mode, the self-evolving plugin layer (Slice 4), and media beyond
the academy (after the pilot).
