---
name: course
description: Plan a Lectern course from a repo, a topic, or a technical study guide. Proposes the skeleton, lesson list, Map spec, pins, terms and capture needs, then confirms them through the wizard's course intake.
argument-hint: "[repo path | topic | study guide file]"
---

# Plan a course

Input: $ARGUMENTS. It is a stack checkout, a topic name, or a study guide written by technical-study-guide-architect.

## Steps

1. **Read before proposing.** For a stack: README, Tiltfile, docker-compose, `pyproject.toml`, CI files, and the
   service entry points. For a topic: the library's own docs at a release tag. Clone pinned sources with
   `lectern sources` once course.yaml exists.
2. **Skeleton.** Propose lessons in four slots, using the course's own words for each title:
   - Quick start: one path from nothing to a working result, no detours.
   - Map: every component on one picture, positions pinned so it never moves between lessons.
   - Drilldowns: one component or one concept each, six minutes at most.
   - Recipes: tasks people repeat, one per lesson.
3. **Map.** Write `map.yaml` (and `map: map.yaml` in course.yaml) with a node per component (`id`, `label`) and an
   edge per real call or data flow (`id`, `from`, `to`, an optional short `label`). For a stack, the components come
   from the Tiltfile and the compose file, plus the ways in: the browser, the dev loop, CI. Edges come from code, not
   from guesses: cite the file that makes each call. Leave `at` out, run `lectern map draft` once to lay the
   components out on the 12 by 6 grid, then look with `lectern map still --out map.png` and move components by hand
   until no label sits on a line. From then on positions are frozen: every lesson draws this Map, so a move re-renders
   every lesson that shows it, and `lectern status` marks each one for a rebuild.
4. **Pins.** Every source gets a repo URL, a ref (release tag or branch) and the commit it resolves to. Pin library
   versions in `pins`. For Python examples, resolve dependencies as of the pinned release date
   (`uv pip install --exclude-newer <date>`), because a library's unpinned dependencies drift.
5. **Terms.** List every term a lesson will say that Kokoro does not know, every acronym, and every term a viewer may
   need defined. Mark new pronunciations `status: proposed` so the audition plays them.
6. **Captures.** For each lesson, list the terminal casts and browser steps it needs, where they run, and what demo
   data and throwaway credentials they need. A stack course lives in its own repo beside the stack and pins it by tag
   and commit (`repo` may be a relative path such as `../the-stack`). Never add a file to the stack for the course's
   sake: captures run in a checkout under `.lectern/stacks/`, and `/lectern:capture` covers the rest.
7. **Confirm.** Run `/lectern:wizard course` with every proposal pre-filled, so the person confirms or edits each one.

Write nothing outside course.yaml, map.yaml, terms.yaml and the lesson stubs the wizard creates.

## After lessons build

- `lectern site` writes the course page (lessons in skeleton order with length, what to watch first and status, under
  the CourseMap) and the glossary page into `dist/<course>/`. `lectern preview` runs it for you.
- `lectern map check` photographs every built map scene as it settles and compares it with a still of the Map alone,
  pixel by pixel. Run it after any build that touches a map scene, and before asking for gate two.
