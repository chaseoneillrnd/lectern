---
name: lesson
description: Write one Lectern lesson script with its claims ledger and exact source excerpts, run the claims judge, and assemble the gate-one packet for human review before anything renders.
argument-hint: "<lesson id>"
---

# Write a lesson

Lesson: $ARGUMENTS. Its stub (front matter) comes from `/lectern:wizard lesson`. Read course.yaml, terms.yaml, the
stub, and every capture the stub lists before writing a word.

## Facts first

- Run `lectern sources` so every pinned source is cached locally.
- Every technical sentence cites a claim. A claim's excerpt is copied **verbatim** from a file in the source cache
  (`~/.lectern/sources/<repo>@<ref>/...`) or from a capture's output. Never write an excerpt from memory.
- Kinds: `doc` is a docs page at the pinned ref, `code` is a source file at the pinned ref, `run` is captured output.
- Claims about LLM output cite the captured run, never a general truth, because scores vary between runs.
- If a capture you need does not exist yet, stop and say which one. Do not describe output that was never captured.
- If the source contradicts what you expected, the source wins, and the surprise usually belongs in the lesson.

## Script rules

Format: `## <scene> layout=<template> key=value title="..."` opens a scene. Prose is narration.
`[span]{verb=target}` fires a cue on the span's first word. `^claim-id` ends a technical sentence.
`> ask:` and `> answer:` make a checkpoint. Layouts: title, map, diagram, code, cast, steps, checkpoint. Verbs:
light, pulse, trace, lines, play, mark, chip, callout, zoom, pan, spotlight, arrow. Anything else fails compile.

- `map` draws the course Map from `map.yaml`, the same in every lesson. Prefer it to a diagram whenever the scene is
  about the system's parts: the viewer learns one picture. `component=<id>` opens the scene with that component lit,
  and in the Map lesson it makes the scene that component's chapter, which the CourseMap links to. Back-to-back map
  scenes share one Map with no fade between them, so only the highlights move.
- A drilldown names its component in front matter (`component: <id>`) and opens with a `map` scene, which lights that
  component for it. `lectern lesson new <id> --type drilldown --component <id>` writes the component into the stub.
  A drilldown's terminal capture usually starts where the Quick start left the stack, not from a fresh clone: leave
  `fresh` off its spec, and its page tells the viewer to start in the folder the Quick start set up.
- `{trace=<edge>}` sends a dot along one edge, in its direction. `{trace=a>b>c}` follows a path of components, each
  step crossing one edge in either direction, so `{trace=llm>app>browser}` shows an answer coming back. Each step takes
  1.2 seconds and the path stays lit until the next light or trace. Give a trace that much narration: a cue that lands
  while the dot is still moving gets a warning.
- `diagram diagram=<name>` draws `diagrams/<name>.yaml` for an idea the Map does not hold, such as how a metric works.

- `code src=examples/x.py` shows a course file. `code src=stack:app/rag/server.py` shows a file from a pinned source
  at its pinned commit, and passes the code-ran check only when one of the lesson's captures ran that source there.
- `cast capture=<id>`: `{play=<step id>}` plays one command, a bare `{play}` the next one, `{play=<a>..<b>}` a run,
  and `{play=<capture id>}` the whole cast. The terminal holds still between plays. One capture can span several
  cast scenes, with a code scene between them: a later scene opens on the terminal as it stood at its first
  command's prompt.
- `{mark="0.734"}` outlines that text in the terminal where it last appears, from the cue's word until the next
  command plays. Marks add up, so two marks compare two numbers: the newest carries the accent and older ones fade
  to a quiet outline, and marks cued within half a second of each other light as one. When that trail would group
  things the narration does not, `{mark="TOP_K is 3" trail=clear}` fades the older marks out instead. The text must
  be in the capture's output, and on screen at the word: mark after the play that prints it.
- `steps capture=<id> from=<step id>`: `{play=<step>}` performs a step with a synthesized cursor and click.
  `{spotlight=<target>}`, `{arrow=<target>}`, `{pulse}`, `{callout=<target> text="..."}` and `{light}` mark a target
  from the capture's targets.json, one at a time. `{zoom=<target>}` frames it, `{pan=<target>}` moves a zoomed view,
  and `{zoom=page}` steps back out. A cue that fires while a step is still running waits for it, and the build warns
  when that wait is longer than half a second: give the step more narration.
- Claims of kind `run` quote a capture's output: a cast's text, or a browser capture's page text at each step.

- The voice carries meaning, the screen carries detail. Never read code, paths, or on-screen text aloud.
- A cue lands on the word that names the thing it shows.
- Leave about one second after each visual change before the next new idea. One or two cues per sentence.
- Write to be heard: short sentences of varied length, spoken phrasing, numbers as words ("zero point five"),
  abbreviations spelled out on first use.
- Where a reader expects the written form, give the voice its words inline: `[0.7]{say="zero point seven"}` or
  `[hit@1]{say="hit at one"}`. The checkpoint card, the page and the transcript show `0.7`, while the voice and the
  captions say "zero point seven". Use it where text stays on screen, such as a checkpoint question, and keep plain
  narration in words.
- At most 15 code lines and 25 words of prose on screen at once. Split a long file across two code scenes with `show=a-b`.
  A line wider than the panel wraps after a space, comma or bracket, with a hanging indent, and every wrapped row
  counts toward the 15.
- Six minutes at most unless front matter sets `cap_minutes` and `cap_reason`.
- End with a checkpoint built from the lesson's `checkpoint_seed`: the Examiner asks, the Narrator answers with claims.

## Loop until clean

1. `lectern compile <id>`: fixes cues, targets, claim tags and unknown words. Add unknown words to terms.yaml with
   `status: proposed`, never by respelling the script.
2. `lectern claims <id>`: every excerpt must match its pinned source, and every file a code scene shows must match a
   file a capture ran. Fix the ledger or re-run the capture, never the check.
3. Calibrate the judge once per course, before its first real use: `lectern judge-input --calibration`, run the
   **claims-judge** agent on `.lectern/judge/calibration-input.json`, save its reply to a file, then
   `lectern judge-save --calibration --result <file>`. It must catch every planted bad claim. If it misses one, stop
   and report which.
4. `lectern judge-input <id>` writes `.lectern/build/<id>/judge-input.json`: one item per cited sentence, with all of
   its evidence and the text on screen while it plays.
5. Spawn the **claims-judge** agent with only that file. It must be a fresh agent, never you, the writer, and never a
   fork of this conversation. Save its reply to a file and run `lectern judge-save <id> --result <file>`, which
   validates it against the bundle. Rewrite or re-source every sentence it scores below 2, then repeat from step 1.
   One fresh judge decides. Judges disagree at the margins from run to run, so the run that scores every sentence
   2 or more stands, and a passing bundle is never judged again in search of a different answer.
6. `lectern gate packet <id> one` writes `.lectern/gates/<id>-gate-one.html`: script and evidence side by side,
   judge scores, where each cue fires, and each new term as the lesson says it. Publish that file as an artifact and
   ask the person to review it.
7. Only on an explicit yes from the person: `lectern gate approve <id> one`. Editing the script or the ledger later
   reopens the gate.
