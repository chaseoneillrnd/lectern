---
name: capture
description: Write a Lectern lesson's terminal and browser capture scripts, run them against the live stack or demo environment, and check what they recorded before any lesson uses them. Use when a lesson needs a cast or browser steps, or when a pinned stack moved.
argument-hint: "<lesson id> | <capture id>"
---

# Capture

Target: $ARGUMENTS. A lesson ID means every capture its front matter lists. Read course.yaml, the lesson stub and its
objective first, and the stack's README, Tiltfile, compose file and CI file when the course is a stack course.

Captures are data, not footage. A terminal capture is an asciicast of real commands. A browser capture is one 2x
screenshot per step plus the box of every element a step touched, found by role and name. Typing is presentation and
output is always real: never fake output, never edit a cast or a screenshot by hand. If a command fails, fix the
environment or the command, and run the capture again.

## Where captures run

- **Course files**: without `stack:`, commands run in the course repo, against `examples/` and their pinned
  environment. `shows:` lists the course files a capture executes, so code scenes can prove those files ran.
- **The stack**: `stack: <source>` runs every command in a checkout of that pinned source under
  `.lectern/stacks/<repo>`, at exactly the pinned commit. `fresh: true` resets it first and deletes untracked and
  ignored files, like a new clone on a new laptop. Use it on the first capture of a Quick start. Later captures reuse
  the checkout, so models and settings the first one fetched are still there.
- Captures of one lesson often depend on each other. Run them in order in one command:
  `lectern capture quickstart tour stop`. Say the order in each spec's `requires`.
- Re-pin before re-capturing when the stack moved: `lectern sources --repin <source>`, then run every capture of
  every lesson that uses it. Claims that quoted the old output break on purpose: fix them from the new output.

## Terminal captures: capture/<id>.yaml

```yaml
id: quickstart
kind: terminal
stack: stack             # optional
fresh: true              # optional, with stack
cols: 84                 # up to 97 columns keep terminal text at the 28 px floor or above
rows: 12                 # the window shows at most this many rows. Raise it so a short run fits whole
env_pass: [PROXY_CA]     # names only: values come from your shell and are never written anywhere
before: [tilt down]      # hidden setup, recorded in meta.json
steps:
  - id: env              # every step gets an id, so a cast scene can play it on its own
    run: cp .env.example .env
    note: Behind a TLS-inspecting proxy, set PROXY_CA in .env now.   # a comment line on the lesson page
  - id: up
    run: tilt up
    until: "(ctrl-c) to exit"   # for a command that never exits: stop it once this text prints. Last step only
stack_paths: [.env.example, Tiltfile]   # what `lectern stale` watches upstream
requires: what must exist before this runs
```

- `cd <dir>` as a step changes the folder for the steps after it, as in a real shell.
- Keep each typed line, prompt included, within `cols`. A longer one wraps mid-word on screen, and `lectern
  capture` warns before it runs. Shorten the command, or carry it onto a second line with a backslash: the cast
  types the second line under bash's `>` prompt, and the page's Commands block copies as one command.
- The lesson page's Commands block lists every step's command in order, after `git clone` and `cd` for a stack
  capture. The clone URL comes from `sources.<name>.clone` in course.yaml when `repo` is a local path, and the QA
  report warns while it is missing. `note:` adds a whole comment line after a command, for something a reader must do
  that the capture didn't need, such as a proxy setting. A command that `until:` stops gets
  `# keeps running until you press Ctrl-C`. Never write a trailing comment into `run`: zsh passes it to the command as
  arguments.
- Proxy and CA variables pass through when set. Anything else a command needs from your shell goes in `env_pass`.
  Never put a secret in `env`: the spec is committed.
- With `stack`, output that prints the checkout's absolute path shows it as `~/<repo>`, the way a teammate's clone
  reads. meta.json records the substitution.
- Long downloads and builds compress: idle gaps longer than `idle_limit` shrink to it. If a command prints progress
  continuously, the cast runs as long as the command. Prefer quiet output, one line per milestone.

## Browser captures: capture/<id>.yaml

```yaml
id: tour
kind: browser
stack: stack
start: tilt up                       # a background process for the capture's lifetime, stopped with Ctrl-C after
ready: {run: "tilt wait --for=condition=Ready uiresource --all --timeout=600s", timeout: 660}
url: http://localhost:10350/
viewport: [1440, 810]                # the narrowest window that fits the page. Smaller shows text larger
mask: [{label: API key}]             # hidden in every screenshot
storage_state: ~/.config/lectern/gitlab.json   # optional login state, kept outside the repo, never read by Lectern
targets:                             # boxes measured on the page as it first loads
  summary: {role: tooltip, name: "healthy count / Out of total resource count", nth: 0}
steps:
  - id: logs
    click: {role: button, name: app}
    as: app                          # the clicked element becomes target `app`
    targets:                         # measured after the step
      indexed: {text: chunks from /docs, exact: false, fit: text}
  - id: app
    goto: http://localhost:5000/
  - id: ask
    click: {role: button, name: Ask}
    burst: {seconds: 3, fps: 8}      # real in-app motion, such as a streaming answer
stack_paths: [Tiltfile, app/rag/templates/index.html]
```

- Locators: `role` and `name` first, then `label`, `text`, `placeholder`, `alt`, `title`, `test_id`. CSS and XPath
  are refused. Add `exact: false` for a substring, `nth` when several match, and `fit: text` so a wide element (a log
  line, a table row) gets a box as wide as its words, which zoom and spotlight then frame tightly.
- Find names with Playwright's ARIA snapshot of the live page (`page.locator("body").aria_snapshot()`), not by
  guessing from the screen.
- Pick the viewport from the page, not by habit: open each page the capture visits at a few widths and take the
  narrowest where `document.documentElement.scrollWidth` equals the window width. A table wider than the window gets
  cut off at the right edge, and zoom and spotlight can't show what isn't in the screenshot.
- Actions: `click`, `type` (with `text`, typed at a steady pace as presentation frames), `fill`, `press` (with `key`),
  `hover`, `scroll`, `wait`, `goto`. Step id `start` is reserved for the page as it loads. A click on a link that
  opens a new tab takes `popup: true`. A step whose page keeps changing after the click, such as a streamed answer,
  takes `wait_for: <locator>` so its settled screenshot waits for the finished state. Without it, a slow run captures
  half an answer, and the claims that quote the answer break.
- Turn off anything that varies or phones home before capturing, such as a first-run telemetry prompt, in the stack
  itself when it belongs there (Tilt: `analytics_settings(enable=False)`).

## Check what was recorded, every time

1. Read the cast's text (`lectern claims` quotes from it) or open every `captures/<id>/steps/*.png`. Look at them.
2. `captures/<id>/meta.json`: the stack commit, the commands and exit codes, the redaction report, `env_passed`.
   A gitleaks finding blocks every build that uses the capture: mask the element or use demo data, then re-capture.
3. `captures/<id>/targets.json`: every target the lesson will point at, with a sensible box. A box as wide as the
   page usually wants `fit: text`.
4. Then write or fix the lesson's cues against those target IDs and step IDs, and `lectern compile <id>`.

## Credentials and money

- Capture against the demo environment with seeded data. Logins come from `storage_state` or the stack's own config
  (an AWS profile, a `.env` the stack reads). Lectern never reads, stores or prints them, and nothing about them goes
  in a capture spec.
- A capture that calls a paid service (Bedrock, Titan, a hosted LLM) costs money every run. Say so in `requires`,
  and ask the person before running it.
