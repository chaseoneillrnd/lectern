---
name: render
description: Build a Lectern lesson end to end, inspect its frames, and assemble the gate-two packet. Use after gate one is approved, or to preview a draft render.
argument-hint: "<lesson id> [--quality draft]"
---

# Render a lesson

Lesson: $ARGUMENTS.

1. `lectern status` must show gate one approved for this lesson and its current script. If it is open, stop and point
   to `/lectern:lesson`. A draft render (`--quality draft`) is allowed before gate one, but never goes to gate two.
2. `lectern build <id>`. It runs compile, tts, timeline, render, check and package, and blocks on any broken gate:
   a missing excerpt, code on screen that never ran, a redaction hit, a legibility floor, or loudness off target.
   Fix the cause and rebuild. Only changed scenes re-render.
3. Look at the frames yourself first. Open `dist/<course>/<id>/review/contact-sheet.pdf` (a frame at every cue) and
   look for text that collides or overflows, a cue that lit the wrong thing, a callout off its target, and anything
   unreadable. Fix the script, the diagram spec or the capture targets, and rebuild.
4. Then the **frame-inspector** agent, which must be a fresh agent, never you and never a fork of this conversation.
   Once per course, calibrate it: `lectern inspect-input --calibration`, run the agent on
   `.lectern/inspect/calibration-input.json`, save its reply, `lectern inspect-save --calibration --result <file>`.
   It must flag every planted frame and no clean one. Then `lectern inspect-input <id>`, run the agent on
   `.lectern/build/<id>/inspect-input.json`, and `lectern inspect-save <id> --result <file>`. Fix every major
   finding you agree with and rebuild. Its findings appear beside each frame in the gate-two packet. It advises and
   never gates.
5. Read `review/qa-report.md`. Every warning gets a fix or a one-line reason to accept it. If the lesson draws the
   course Map, run `lectern map check`: every map scene must match the still of the Map alone, pixel for pixel, in
   every lesson that draws it.
6. `lectern gate packet <id> two` writes the folder `.lectern/gates/<id>-gate-two/`: `index.html` beside
   `lesson.mp4`, `lesson.vtt` and the contact-sheet frames it shows. Publish `index.html` as an artifact with every
   other file in the folder passed as `files` at the same relative path, and ask the person to watch the lesson.
   If gate one is still open the page says so, and gate two cannot be approved until it is.
7. Only on an explicit yes from the person: `lectern gate approve <id> two`. Then `lectern preview` shows the page as
   it will ship.
