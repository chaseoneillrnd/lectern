"""Build the frame inspector's calibration set: real Lectern frames, some left clean and some with one planted defect.

Run from the tool repo after building the RAGAS drilldown and the stack Quick start:
    python tools/make_inspect_calibration.py <ragas frames dir> <stack frames dir>
Writes src/lectern/house/inspect-calibration/: JPEG frames plus frames.yaml with each frame's expectation and defect.
"""
import sys
from pathlib import Path

import yaml
from PIL import Image, ImageDraw, ImageFont

OUT = Path(__file__).resolve().parents[1] / "src/lectern/house/inspect-calibration"
FONTS = Path(__file__).resolve().parents[1] / "node_modules/@fontsource/inter/files"
ACCENT, INK, PANEL = "#4cc2ff", "#0b0f14", "#141b24"


def font(size, weight="600"):
    return ImageFont.truetype(str(FONTS / f"inter-latin-{weight}-normal.woff2"), size)


def callout(img, x, y, text, size=40):
    d = ImageDraw.Draw(img)
    f = font(size, "700")
    w = d.textlength(text, font=f)
    d.rounded_rectangle([x, y, x + w + 40, y + size + 28], radius=12, fill=ACCENT)
    d.text((x + 20, y + 12), text, font=f, fill=INK)


def main(ragas: Path, stack: Path) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    frames = []

    def save(name, img, expect, defect=None, layout=""):
        img.convert("RGB").save(OUT / name, quality=86)
        frames.append({"file": name, "layout": layout, "expect": expect, **({"defect": defect} if defect else {})})

    diagram = Image.open(ragas / "cue-002.png")
    code = Image.open(ragas / "cue-014.png")
    cast = Image.open(ragas / "cue-016.png")
    spot = Image.open(stack / "cue-015.png")
    arrow = Image.open(stack / "cue-016.png")
    answer = Image.open(ragas / "cue-003.png")

    save("clean-diagram.jpg", diagram, "In the diagram, 'judge' is lit with the accent and the rest is dimmed.", layout="diagram")
    save("clean-code.jpg", code, "Code lines 12-14 are highlighted and the other lines dimmed.", layout="code")
    save("clean-cast.jpg", cast, "A terminal shows the command being run and its output.", layout="cast")
    save("clean-spotlight.jpg", spot, "A spotlight frames summary (role 'tooltip' name 'healthy count / Out of total "
         "resource count'), and the rest of the page is dimmed.", layout="steps")
    save("clean-arrow.jpg", arrow, "An arrow points at smoke (role 'button' name 'smoke').", layout="steps")

    img = code.copy()
    callout(img, 520, 520, "Each call scores one answer")  # lands on top of the highlighted code
    save("planted-collision.jpg", img, "Code lines 12-14 are highlighted and the other lines dimmed.", "collision", "code")

    img = diagram.copy()
    callout(img, 1460, 470, "Scores each claim against its context")  # runs off the right edge
    save("planted-overflow.jpg", img, 'A callout reading "Scores each claim against its context" points at judge.',
         "overflow", "diagram")

    img = answer.copy()
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([1180, 860, 1800, 960], radius=12, fill=PANEL)
    d.text((1204, 874), "judge model", font=font(14, "700"), fill="#2f3a46")
    d.text((1204, 900), "The LLM that Ragas asks to split an answer into statements and to check each one.",
           font=font(11, "400"), fill="#262d36")
    save("planted-unreadable.jpg", img, "A glossary chip for 'judge model' with its definition, not covering anything "
         "important.", "unreadable", "diagram")

    save("planted-wrong-target.jpg", arrow, "An arrow points at app (role 'button' name 'app').", "wrong-target", "steps")

    (OUT / "frames.yaml").write_text(
        "# Frame inspector calibration: real frames, some clean, some with one planted defect each.\n"
        "# A run passes when every planted frame gets a major issue and no clean frame does.\n"
        + yaml.safe_dump({"frames": frames}, sort_keys=False, allow_unicode=True, width=120))
    print(f"wrote {len(frames)} frames to {OUT}")


if __name__ == "__main__":
    main(Path(sys.argv[1]), Path(sys.argv[2]))
